import json

import pandas as pd

from debate_tree import PrepareTree

from .llm_schemas import (
    BattlefieldResponse,
    QueryResponse,
    SelectionClaimsOnlyResponse,
    SelectionFrameworkResponse,
    StatementsResponse,
)
from .prompts import *
from .time_estimator import LengthEstimator
from .timing_log import log_llm_io
from .tool import get_response_with_retry, identify_number_in_text, logger, sort_by_action

##################### Evidence #####################


def select_query(llm, motion, stance, claim, action, candidate_queries):
    """
    Select the retrieval query for the claim
    return: query, a list of queries, ["query1", "query2", ...]
    """
    prompt = select_query_prompt.format(
        claim=claim, motion=motion, stance=stance, action=action, candidate_queries=candidate_queries
    )
    log_llm_io(logger, phase="helper", title="Query-Helper-Prompt", body=prompt.strip())
    query, response = get_response_with_retry(llm, prompt, "query", response_model=QueryResponse)
    log_llm_io(logger, phase="helper", title="Query-Helper-Response", body=response.strip())
    return query


def rank_evidence(candidate_evidence, selected_queries=None):
    if selected_queries is not None:
        selected_evidence = [x for x in candidate_evidence if x["query"] in selected_queries]
    else:
        selected_evidence = candidate_evidence

    titles, uniq_evidence = [], []
    for e in selected_evidence:
        # DO NOT use author name if author_info is empty
        if "author" in e and "author_info" in e:
            if e["author_info"] == "":
                e["author"] = ""
        e["numbers"] = identify_number_in_text(e.get("raw_content", e["content"]))
        e["n_numbers"] = len(e["numbers"])
        if e["title"] not in titles:
            uniq_evidence.append(e)
            titles.append(e["title"])

    # NOTE: the database can have some evidences
    for e in uniq_evidence:
        if "arxiv" in e.get("source", "").lower() or "arxiv" in e.get("publication", "").lower():
            e["reliability"] = -1

    sorted_evidence = [
        x
        for _, _, x in sorted(
            zip(
                [x.get("n_numbers", 0) for x in uniq_evidence],
                [x.get("reliability", 0) for x in uniq_evidence],
                uniq_evidence,
            ),
            key=lambda pair: (pair[0], pair[1]),
            reverse=True,
        )
    ]

    return sorted_evidence


##################### Opening #####################


def build_cot_claims(llm, motion, side, claim_pool):
    # if "perspective" in claim_pool[0][0]:
    #     claims = [{"claim": x[0]["claim"], "perspective": x[0]["perspective"], "concept": x[0]["concept"], "explanation": x[0]["explanation"]} for x in claim_pool]
    # else:
    claims = [x[0]["claim"] for x in claim_pool]

    prompt = (
        "You are a debate assistant. You are given a motion and a side. You need to rank the following claims based on their relevance to the motion and side.\n\n"
        f"**Motion:** {motion}\n"
        f"**Side:** {side}\n"
        f"**Claims:** \n{claims}\n\n"
        "Please the best 3 claims that can be used in this debate from the list of claims. The selected claims should be exactly the same as the given list.\n"
        "These claims should be relevant to the motion and side, and should be from different perspectives. "
        "Use Json format with one key of **selection**. The value is a list of selected claims (string) that can be used in this debate.\n"
    )

    log_llm_io(logger, phase="helper", title="CoT-Claims-Prompt", body=prompt.strip(), side=side)
    selected_claims, response = get_response_with_retry(
        llm,
        prompt,
        "selection",
        response_model=SelectionClaimsOnlyResponse,
    )
    log_llm_io(logger, phase="helper", title="CoT-Claims-Response", body=response.strip(), side=side)

    # selected_claims = [x if x.endswith(".") else x + '.' for x in selected_claims]
    claim_content = [x[0]["claim"] for x in claim_pool]
    print(claim_content)
    selected_idx = [claim_content.index(x) for x in selected_claims]

    thoughts = {
        "stage": "preparation",
        "side": side,
        "mode": "choose_main_claims",
        "all_claims": claims,
        "selected_claims": selected_claims,
        "selected_idx": selected_idx,
    }

    return selected_claims, selected_idx, thoughts


def build_logic_claims(llm, motion, side, claim_pool, context="", definition="", use_rehearsal_tree=True, top_k=None):
    """
    Choose the main claims from the sorted claims based on the logic chain
    #"""

    # Step 1. Sort claim groups by their highest minimax_search_score
    sorted_idx = sorted(
        range(len(claim_pool)), key=lambda i: claim_pool[i][0]["minimax_search_score"], reverse=True
    )  # sort the groups by the highest value

    # Step 2. Keep only top-k if specified
    if top_k is not None:
        sorted_idx = sorted_idx[:top_k]

    ranked_claims = [claim_pool[i][0]["claim"] for i in sorted_idx]

    # Step 3. Gather original claims & tree info
    tree_info = ""
    ori_claims = []
    if use_rehearsal_tree:
        for i in sorted_idx:
            data = claim_pool[i][0]["tree_structure"]
            tree = PrepareTree.from_json(data)
            tree_info += tree.print_tree(include_status=True) + "\n\n\n"
            ori_claims.append(claim_pool[i][0]["claim"])
    else:
        for i in sorted_idx:
            ori_claims.append(claim_pool[i][0]["claim"])
        tree_info = ""

    # Step 4. Construct prompt
    prompt = main_claim_selection.format(
        motion=motion, side=side, tree=tree_info, claims="\n".join(ori_claims), context=context, definition=definition
    )
    log_llm_io(logger, phase="helper", title="Logic-Claims-Prompt", body=prompt.strip(), side=side)
    content, response = get_response_with_retry(
        llm,
        prompt,
        "selection",
        response_model=SelectionFrameworkResponse,
    )
    log_llm_io(logger, phase="helper", title="Logic-Claims-Response", body=response.strip(), side=side)

    # Step 5. Parse model outputs
    selected_claims = content["claims"]
    framework = content["framework"]
    explanation = content["explanation"]

    selected_claims = [x if x.endswith(".") else x + "." for x in selected_claims]
    selected_idx = []
    for sc in selected_claims:
        try:
            selected_idx.append(ori_claims.index(sc))
        except ValueError:
            # Fuzzy match: strip punctuation and compare lowercase
            sc_norm = sc.rstrip(".。").strip().lower()
            best_j, best_overlap = 0, 0
            for j, oc in enumerate(ori_claims):
                oc_norm = oc.rstrip(".。").strip().lower()
                if sc_norm == oc_norm:
                    best_j = j
                    break
                overlap = len(set(sc_norm.split()) & set(oc_norm.split()))
                if overlap > best_overlap:
                    best_j, best_overlap = j, overlap
            selected_idx.append(best_j)
            logger.warning(f"[Logic-Claims] Fuzzy matched '{sc}' -> '{ori_claims[best_j]}'")

    # Step 6. Record reasoning info
    thoughts = {
        "stage": "preparation",
        "mode": "choose_main_claims",
        "ranked_claims": ranked_claims,
        "framework": framework,
        "explanation": explanation,
        "selected_claims": selected_claims,
        "selected_idx": selected_idx,
        "top_k": top_k,
    }

    return selected_claims, selected_idx, thoughts


##################### Debate Flow Tree #####################


def get_actions_from_tree(claims, tree, oppo_tree):
    actions = []

    if tree.max_level == 0:
        for claim in claims:
            actions.append(
                {
                    "idx": len(actions),
                    "action": "propose",
                    "target_claim": claim,
                    "target_argument": "",
                    "claim_owner": "us",
                    "desired_direction": "support",
                    "unclassified_arguments": [],
                    "counterarguments": [],
                    "importance": "high",
                    "targeted_debate_tree": "you",
                }
            )
    else:
        for level in range(tree.max_level):
            nodes = tree.get_nodes_by_level(level + 1)
            if len(nodes) == 0:
                break
            else:
                action = "reinforce" if (level + 1) % 2 == 1 else "rebut"
                for node in nodes:
                    actions.append(
                        {
                            "idx": len(actions),
                            "action": action,
                            "target_claim": node.claim,
                            "target_node_id": getattr(node, "node_id", None),
                            "target_argument": " ".join(node.argument),
                            "claim_owner": "us" if action == "reinforce" else "opponent",
                            "desired_direction": "support" if action == "reinforce" else "challenge",
                            "unclassified_arguments": list(node.argument),
                            "counterarguments": [
                                {"claim": child.claim, "arguments": list(child.argument)}
                                for child in node.children
                            ],
                            "targeted_debate_tree": "you",
                        }
                    )

    if oppo_tree.max_level != 0:
        for level in range(oppo_tree.max_level):
            nodes = oppo_tree.get_nodes_by_level(level + 1)
            if len(nodes) == 0:
                break
            else:
                action = "attack" if (level + 1) % 2 == 1 else "reinforce"
                for node in nodes:
                    actions.append(
                        {
                            "idx": len(actions),
                            "action": action,
                            "target_claim": node.claim,
                            "target_node_id": getattr(node, "node_id", None),
                            "target_argument": " ".join(node.argument),
                            "claim_owner": "us" if action == "reinforce" else "opponent",
                            "desired_direction": "support" if action == "reinforce" else "challenge",
                            "unclassified_arguments": list(node.argument),
                            "counterarguments": [
                                {"claim": child.claim, "arguments": list(child.argument)}
                                for child in node.children
                            ],
                            "targeted_debate_tree": "opponent",
                        }
                    )

    log_llm_io(logger, phase="helper", title="Debate-Flow-Tree-Action", body=json.dumps(actions, indent=2))

    if not actions:
        return []
    df = pd.DataFrame(actions)
    df = df.drop_duplicates(subset=["target_claim"])
    actions = df.to_dict(orient="records")

    return actions


def get_battlefields_from_actions(llm, motion, side, claims, actions, tree, oppo_tree):
    prompt = debate_flow_tree_action_eval_prompt.format(
        motion=motion,
        side=side,
        act="SUPPORT" if side == "for" else "OPPOSE",
        claims=claims,
        actions=json.dumps(actions, indent=2),
        tree=tree.print_tree(include_status=True),
        oppo_tree=oppo_tree.print_tree(include_status=True, reverse=True),
    )
    log_llm_io(logger, phase="helper", title="Debate-Flow-Tree-Action-Eval-Prompt", body=prompt.strip(), side=side)
    eval_results, response = get_response_with_retry(
        llm,
        prompt,
        "response",
        response_model=BattlefieldResponse,
    )
    log_llm_io(logger, phase="helper", title="Debate-Flow-Tree-Action-Eval-Response", body=response.strip(), side=side)

    battlefields = []
    for eval_result in eval_results:
        actions_in_battlefield = []
        for action in actions:
            if action["idx"] in eval_result["idx_list"]:
                actions_in_battlefield.append(action)
        actions_in_battlefield = sorted(actions_in_battlefield, key=lambda x: sort_by_action(x["action"]), reverse=True)
        battlefield = {
            "battlefield": eval_result["battlefield"],
            "battlefield_importance": eval_result["importance"],
            "battlefield_argument": eval_result["unified_argument"],
            "supporting_arguments": eval_result.get("supporting_arguments", []),
            "counterarguments": eval_result.get("counterarguments", []),
            "actions": actions_in_battlefield,
        }
        battlefields.append(battlefield)

    return battlefields


def get_retrieval_from_rehearsal_tree(
    action_type, target_claim, side, oppo_side, prepared_tree_list,
    prepared_oppo_tree_list, look_ahead_num, query_embedding, **kwargs,
):
    from .rehearsal_retrieval import retrieve
    return retrieve(action_type, target_claim, side, oppo_side, prepared_tree_list,
                    prepared_oppo_tree_list, look_ahead_num, query_embedding, **kwargs)


##################### Time-Adjuster #####################


class TimeAdjuster:
    def __init__(self):
        self.L = None
        self.R = None

    def revise_helper(self, statement, n_words, budget, threshold=5, ratio=0.46, estimator=None):
        current_cost = estimator.query_time(statement)
        words_count = LengthEstimator(mode="words").query_time(statement)
        logger.debug(
            "[Efficient-Fit-Length] "
            + f"use {n_words} words in the prompt, real words: {words_count}, real cost: {current_cost:0.2f}, target interval: [{budget-threshold}, {budget}]"
        )

        if budget <= 0 or current_cost >= budget - threshold and current_cost <= budget + 1:
            return current_cost, n_words, True

        # step1. determine the first endpoint
        if self.L is None and self.R is None:
            if current_cost < budget - threshold:
                self.L = n_words
                return current_cost, n_words + int((budget - current_cost) / ratio), False
            else:
                self.R = n_words
                return current_cost, n_words - int((current_cost - (budget - threshold)) / ratio), False

        # step2. determine the second endpoint
        if self.L is None:
            if current_cost < budget - threshold:
                self.L = n_words
                return current_cost, (self.L + self.R) // 2, False
            else:
                return current_cost, n_words - int((current_cost - (budget - threshold)) / ratio), False
        if self.R is None:
            if current_cost > budget:
                self.R = n_words
                return current_cost, (self.L + self.R) // 2, False
            else:
                return current_cost, n_words + int((budget - current_cost) / ratio), False

        # step3. binary search in [L, R], always terminate and w.h.p. can terminate when R-L > 1
        if current_cost < budget - threshold:
            self.L = n_words
        else:
            self.R = n_words
        return current_cost, (self.L + self.R) // 2, False


##################### Anaylsis #####################


def extract_statement(llm, motion, statement, claims=None, tree=None, side=None, stage=None, planned_actions=None,
                      allow_corrections=False, correction_targets=None, relation_targets=None):
    if claims is not None:
        prompt = extract_statment_by_claim_prompt.format(motion=motion, statement=statement, claim=json.dumps(claims))
    elif tree is not None:
        prompt = extract_statment_with_tree_prompt.format(
            motion=motion,
            statement=statement,
            claim=json.dumps(claims),
            tree=tree[0],
            oppo_tree=tree[1],
            side=side,
            stage=stage,
        )
    else:
        prompt = extract_statment_prompt.format(motion=motion, statement=statement)

    if tree is not None and allow_corrections:
        from streaming.argument_revisions import CORRECTION_INSTRUCTIONS
        prompt += CORRECTION_INSTRUCTIONS
        if correction_targets:
            prompt += ("\nCorrection targets owned by the current speaker. For revise/retract, copy the "
                       "node_id into purpose.target_id (do not invent an ID); keep the target claim text too.\n"
                       + json.dumps(correction_targets))

    if relation_targets is not None:
        from streaming.tree_updates import RELATION_INSTRUCTIONS
        from streaming.claim_constraints import CONSTRAINT_EXTRACTION
        prompt += RELATION_INSTRUCTIONS + CONSTRAINT_EXTRACTION + "\n" + json.dumps(relation_targets)
        if not allow_corrections:
            prompt += "\nFor this extraction revise/retract are disabled. Use propose for a new position; do not retire existing nodes.\n"

    if tree is not None and planned_actions:
        prompt += (
            "\n## Speaker's plan before generation and revision\n"
            + json.dumps([dict(action, id=i) for i, action in enumerate(planned_actions)])
            + "\nThe plan describes intentions, NOT evidence of what was said. Compare it with the final Statement. "
            "For each extracted claim, return planned_action_ids containing only IDs whose substantive claim "
            "is actually expressed by that item's verbatim content excerpt. Paraphrases are allowed; mere "
            "topic overlap or mentioning an opponent's claim is not a match. Use [] for unmatched claims. "
            "Exclude omitted planned claims entirely; do not invent quotations or add details from the plan. "
            "When a spoken claim implements a planned propose action, preserve its role on the speaker's own "
            "tree: propose a new main claim, or reinforce its existing main-claim node. Keep any applicable "
            "attack/rebut links as additional purposes rather than replacing the proposal role. "
            "Extract only what the final speech says, even when it is narrower than the planned claim.\n"
        )

    log_llm_io(
        logger,
        phase="helper",
        title="Analyze-Helper-Prompt",
        body=prompt.strip(),
        side=side,
        stage=stage,
    )
    extraction_schema = StatementsResponse
    if relation_targets is not None:
        from utils.llm_schemas import LinkedStatementsResponse
        extraction_schema = LinkedStatementsResponse
    claims, response = get_response_with_retry(
        llm,
        prompt,
        "statements",
        response_model=extraction_schema,
    )
    log_llm_io(
        logger,
        phase="helper",
        title="Analyze-Helper-Response",
        body=response.strip(),
        side=side,
        stage=stage,
    )
    if tree is not None:
        # Structured JSON alone does not establish that an extraction is grounded
        # in the audio transcript. Reject invented/missing source quotations.
        source = " ".join(statement.split())
        motion_key = " ".join(motion.split()).casefold().rstrip(".!?")
        grounded = []
        for item in claims:
            excerpt = " ".join((item.get("content") or "").split())
            claim_key = " ".join(item["claim"].split()).casefold().rstrip(".!?")
            if not excerpt or excerpt not in source or claim_key == motion_key:
                logger.warning("Skipping ungrounded or motion-only extraction: %s", item["claim"])
                continue
            # The extractor supplies semantic matches; only verified source spans
            # with valid plan IDs can recover a lost proposal role. Never insert
            # the planned wording itself: it may contain details omitted in speech.
            if planned_actions:
                matched_ids = [
                    i for i in item.get("planned_action_ids", [])
                    if type(i) is int and 0 <= i < len(planned_actions)
                ]
                item["planned_action_ids"] = matched_ids
                purposes = item.get("purpose") or []
                if isinstance(purposes, dict):
                    purposes = [purposes]
                spoken_proposal = any(
                    planned_actions[i]["action"] == "propose"
                    and planned_actions[i].get("targeted_debate_tree", "you") == "you"
                    for i in matched_ids
                )
                has_own_claim = any(
                    p["targeted_debate_tree"] == "you" and p["action"] in ("propose", "reinforce")
                    for p in purposes
                )
                if spoken_proposal and not has_own_claim:
                    purposes.append({"action": "propose", "targeted_debate_tree": "you", "target": item["claim"]})
                item["purpose"] = purposes
            grounded.append(item)
        claims = grounded
    return claims
