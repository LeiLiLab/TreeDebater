"""Offline audit of exact whole-body requests and responses."""
import json
import sqlite3
from pathlib import Path
D = Path('experiments/incremental_planning')
RUN = 'listening-motion-live-v52-refactor-streamed-motion02-v68'
O = D / 'run' / RUN

def main():
    db = sqlite3.connect(f'file:{D}/run/cost.sqlite?mode=ro', uri=True)
    rows = []
    for id, label, state in db.execute('select id,label,state from calls where instr(label,?)=1 order by id', (RUN,)):
        if not label.endswith('whole_revision_stream'):
            continue
        artifact = json.loads((D / f'run/call_{id:06d}.json').read_text())
        request = artifact['request']
        prompt = request['messages'][-1]['content']
        payload = json.loads(prompt.splitlines()[-1])
        choices = (artifact.get('response') or {}).get('choices', [])
        response = choices[0]['message']['content'] if choices else ''
        target = payload['remaining_word_target']
        draft_words = len(payload['unpublished_draft'].split())
        words = len(response.split())
        rows.append(dict(call_id=id, state=state, side=payload['side'], stage=payload['stage'],
            target_words=target, draft_words=draft_words, revision_words=words,
            revision_to_target_ratio=words/target, word_change=words-draft_words,
            finish_reason=choices[0].get('finish_reason') if choices else None,
            max_tokens=request.get('max_tokens'),
            old_paragraph_limit_present='80–120' in prompt or '80-120' in prompt,
            prompt=prompt, response=response))
    result = dict(run=RUN, counting_method='Whitespace-delimited words, before duration fitting.', turns=rows)
    (O / 'revision_length_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps([{k:v for k,v in r.items() if k not in ('prompt','response')} for r in rows], indent=2))

if __name__ == '__main__':
    main()
