"""Export stage-level observations; no confidence or generalization claim."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statistics
D=Path(__file__).resolve().parent

def main():
    summary=json.loads((D/'flat-motion-overlap-v2_summary.json').read_text())
    assert summary['status']=='completed' and summary['recorded']==36
    rows=list(csv.DictReader((D/'flat-motion-overlap-v2_turns.csv').open()))
    arms=['natural_prefix','short_prefix'];labels=['Natural opening','Short opening'];colors=['#2678a6','#d97836']
    stages=['opening','rebuttal','closing']
    fig,axes=plt.subplots(1,3,figsize=(13.5,4.5))
    for ax,metric,title in zip(axes,['first_audio_s','duration_fraction','quality'],['First playable audio (seconds)','Delivered / target duration (%)','Speech quality (1–5, model judge)']):
        for a,(arm,label,color) in enumerate(zip(arms,labels,colors)):
            for i,stage in enumerate(stages):
                subset=[r for r in rows if r['arm']==arm and r['stage']==stage]
                values=[100*float(r['audio_seconds'])/float(r['budget']) if metric=='duration_fraction' else float(r[metric]) for r in subset if r['status']=='returned' and (metric=='duration_fraction' or r[metric])]
                x=i+(-.18 if a==0 else .18)
                ax.bar(x,statistics.mean(values),width=.28,color=color,alpha=.25,label=label if i==0 else None)
                ax.scatter([x+(j-(len(values)-1)/2)*.018 for j in range(len(values))],values,s=22,color=color,edgecolor='white',linewidth=.4,zorder=3)
                ax.plot([x-.12,x+.12],[statistics.mean(values)]*2,color=color,linewidth=2)
        ax.set_xticks(range(3),['Opening\n240s','Rebuttal\n240s','Closing\n120s'])
        ax.set_title(title,fontsize=11);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
        ax.spines[['top','right']].set_visible(False)
        if metric=='duration_fraction':ax.axhline(100,color='#555',linestyle='--',linewidth=1)
        if metric=='quality':ax.set_ylim(0,5.4);ax.set_yticks(range(1,6))
        else:ax.set_ylim(bottom=0)
    axes[0].legend(frameon=False,fontsize=9)
    fig.suptitle('Flat Tree: natural versus short opening, with overlapping tail revision',fontsize=13)
    fig.text(.5,.015,'First 3 motions; shared historical contexts; 6 turns per stage/arm. Dots: turns; bars: means. No local tempo or TTS text rewriting.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,.05,1,.94])
    for ext in ['png','pdf']:fig.savefig(D/f'flat-motion-overlap-v2_comparison.{ext}',dpi=180)
    plt.close(fig)

if __name__=='__main__':main()
