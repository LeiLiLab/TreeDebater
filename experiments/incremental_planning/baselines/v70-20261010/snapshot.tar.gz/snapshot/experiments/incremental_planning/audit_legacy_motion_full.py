"""Offline audit of complete Legacy deliveries and retained interrupted attempts."""
import hashlib
import json
from pathlib import Path
import sqlite3
from pydub import AudioSegment
ROOT = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def audit_source(manifest):
    base=D/'run'/manifest['run_id']; snap=base/'source_snapshot'
    files=json.loads((snap/'files.json').read_text()); source=hashlib.sha256(); changed=[]
    for rel,digest in sorted(files.items()):
        path=snap/rel; assert sha(path)==digest
        source.update(rel.encode()); source.update(path.read_bytes())
        if not (ROOT/rel).exists() or sha(ROOT/rel)!=digest: changed.append(rel)
    assert source.hexdigest()==manifest['source_digest']
    assert sha(snap/'harness.py')==manifest['harness_sha256']
    assert sha(D/'cases_motion_overlap_v1.json')==manifest['cases_sha256']
    for rel,digest in manifest['input_sources'].items():
        archived=snap/'dependencies'/Path(rel).name
        path=archived if archived.exists() and Path(rel).suffix=='.py' else ROOT/rel
        assert sha(path)==digest, rel
    return dict(run=manifest['run_id'],frozen_source_verified=True,inputs_and_harness_verified=True,
        live_source_changed=changed,live_source_added=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'src').rglob('*.py') if str(p.relative_to(ROOT)) not in files))

def main():
    v2=json.loads((D/'manifest_legacy_motion_full_v2.json').read_text())
    v3=json.loads((D/'manifest_legacy_motion_full_v3.json').read_text())
    assert v2['status']=='stopped' and v3['status']=='completed'
    old=[(p,json.loads(p.read_text())) for p in (D/'run'/v2['run_id']).glob('*/*/*/result.json')]
    new=[(p,json.loads(p.read_text())) for p in (D/'run'/v3['run_id']).glob('*/*/*/result.json')]
    complete=[item for item in old if item[1]['status']=='returned']+new
    failed=[item for item in old if item[1]['status']!='returned']
    assert len(complete)==18 and len(new)==15 and len(failed)==1
    planned=json.loads((D/'cases_motion_overlap_v1.json').read_text())
    assert {r['case'] for _,r in complete}=={c['id'] for c in planned}
    chunks=failed_chunks=0;combined_deltas=[];rewrite_chunks=0;empty_reference_suffix=[]
    for path,r in complete+failed:
        assert r['answer']=='\n\n'.join(e['text'] for e in r['events'])
        assert len(r['events'])==r['chunks']
        assert abs(r['audio_seconds']-sum(e['audio_seconds'] for e in r['events']))<.001
        config=r['output_config'];assert config['max_refinements']==10 and config['early_max_refinements']==3
        assert config['allow_expansion'] and not config['first_chunk_local_tempo']
        assert config['speed_adjust_min']==config['speed_adjust_max']==1
        assert r['planning_mode']=='legacy'
        for i,event in enumerate(r['events']):
            assert event['index']==i
            chunk=ROOT/event['path'];assert chunk.with_suffix('.txt').read_text().strip()==event['text'].strip()
            assert abs(len(AudioSegment.from_file(chunk))/1000-event['audio_seconds'])<.001
        if r['status']=='returned':
            assert not r['error']
            if r['returned_text'] != r['answer']:
                assert r['returned_text']==r['answer']+'\n\n**Reference**\n'
                empty_reference_suffix.append(r['case'])
            assert not r.get('audio_blocked_dispatches', [])
            combined=list(path.parent.glob('*.mp3'));assert len(combined)==1
            delta=len(AudioSegment.from_file(combined[0]))/1000-r['audio_seconds']
            assert abs(delta)<.15;combined_deltas.append(delta);chunks+=r['chunks']
            for profile in r['chunk_profiles']:
                assert float(profile['local_tempo_speed'])==1 and profile['local_tempo_status']=='disabled'
                rewrite_chunks+=int(profile['chosen_intra_iter'])>0
        else:
            assert r['status']=='failed_partial' and r['case']=='motion_01_rebuttal_against'
            failed_chunks+=r['chunks']
        assert all(c['state']=='ok' for c in r['audio_calls'])
    sources=[audit_source(m) for m in [v2,v3]]
    snapshots=[json.loads((D/'run'/m['run_id']/'source_snapshot/files.json').read_text()) for m in [v2,v3]]
    behavior_files=['src/ouragents.py','src/agents.py','src/tts_streaming.py','src/streaming/config.py']
    assert all(snapshots[0][name]==snapshots[1][name] for name in behavior_files)
    db=sqlite3.connect(f'file:{D/"run/cost.sqlite"}?mode=ro',uri=True)
    states=dict(db.execute('select state,count(*) from calls where instr(label,?)=1 group by state',('legacy-motion-',)))
    assert not states.get('pending',0)
    truncated=[]
    for (call_id,) in db.execute('select id from calls where instr(label,?)=1',('legacy-motion-',)):
        a=json.loads((D/'run'/f'call_{call_id:06}.json').read_text())
        if a.get('truncated'):truncated.append(call_id)
    result=dict(complete_speeches=18,unique_complete_contexts=18,decoded_complete_chunks=chunks,
        preserved_partial_failures=1,decoded_partial_chunks=failed_chunks,
        exact_published_transcripts=True,audio_sidecars_and_durations_match=True,
        returned_text_empty_reference_suffix_cases=empty_reference_suffix,
        returned_text_note='Legacy appends an empty Reference section on opening/rebuttal returns; speech body exactly matches published audio inputs. Original return values are preserved.',
        no_local_or_provider_speed_change=True,adopted_rewrite_chunks=rewrite_chunks,
        combined_duration_max_abs_difference_s=max(map(abs,combined_deltas)),
        frozen_source_audits=sources,speech_and_tts_source_identical_between_batches=True,
        study_cost_states=states,truncated_call_ids=truncated,
        limitations=['No ASR/listening audit; transcripts are provider inputs.','First audio is server readiness; playback gaps are queue estimates.','One explicitly retried harness-limited failure, preserved separately.'])
    (D/'legacy_motion_full_artifact_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
