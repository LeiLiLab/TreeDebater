"""Read-only, failure-inclusive report for matched 4+4+2 speech comparison."""
from collections import Counter
import csv
import json
import math
from pathlib import Path
import sqlite3
import statistics
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from streaming.experiment_accounting import exposure_query
D=Path(__file__).resolve().parent
RUN='flat-motion-overlap-v2'


def stats(values):
    x=sorted(v for v in values if v is not None)
    if not x:return dict(n=0,mean=None,median=None,min=None,max=None,p90=None)
    pos=(len(x)-1)*.9;i=int(pos)
    return dict(n=len(x),mean=statistics.mean(x),median=statistics.median(x),min=x[0],max=x[-1],p90=x[i]+(x[min(i+1,len(x)-1)]-x[i])*(pos-i))


def summarize(rows,planned):
    audible=[r for r in rows if r['events']]
    judged=[r for r in rows if r['judge']]
    traces=[r['fixed_prefix_trace'] for r in rows if 'fixed_prefix_trace' in r]
    overlap=[t for t in traces if 'tail_revision_end_seconds' in t and t['chunks']]
    return dict(planned=planned,recorded=len(rows),statuses=dict(Counter(r['status'] for r in rows)),
        first_audio_s=stats(r['generation_to_first_audio_seconds'] for r in audible),
        first_chunk_s=stats(r['events'][0]['audio_seconds'] for r in audible),
        duration_s=stats(r['audio_seconds'] for r in rows),
        duration_fraction=stats(r['audio_seconds']/r['budget'] for r in rows),
        signed_duration_error_s=stats(r['audio_seconds']-r['budget'] for r in rows),
        absolute_duration_error_s=stats(abs(r['audio_seconds']-r['budget']) for r in rows),
        within_5s=sum(r['status']=='returned' and abs(r['audio_seconds']-r['budget'])<=5 for r in rows),
        within_10pct=sum(r['status']=='returned' and abs(r['audio_seconds']-r['budget'])<=.1*r['budget'] for r in rows),
        words=stats(r['answer_words'] for r in rows),
        configured_words=stats(r['configured_word_count'] for r in rows),
        words_within_upper_bound=sum(r['status']=='returned' and r['configured_word_count']<=math.ceil(r['budget']/.46) for r in rows),
        word_budget_note='words is whitespace count; configured_words filters standalone punctuation, matching LengthEstimator.count_words. Upper bound ceil(seconds/0.46).',
        estimated_gap_s=stats(r['estimated_total_gap_seconds'] for r in audible),
        turns_with_estimated_gap=sum(r['estimated_total_gap_seconds']>.05 for r in audible),
        worker_return_s=stats(r['worker_return_seconds'] for r in rows),
        judged=len(judged),missing_judgments=len(audible)-len(judged),
        quality=stats(r['judge']['quality'] for r in judged),
        rebuttal_strength=stats(r['judge']['rebuttal_strength'] for r in judged),
        stance_wrong=sum(not r['judge']['stance_correct'] for r in judged),
        strawman=sum(r['judge']['strawman'] for r in judged),
        lost_conditions=sum(r['judge']['lost_conditions'] for r in judged),
        unsupported_facts=sum(r['judge']['unsupported_facts'] for r in judged),
        fallback_count=sum('fallback_reason' in t for t in traces),
        fallback_reasons=[t['fallback_reason'] for t in traces if 'fallback_reason' in t],
        phase_seconds={
            'whole_draft':stats(t['draft_ready_seconds'] for t in overlap),
            'whole_feedback_and_revision':stats(t['feedback_ready_seconds']-t['draft_ready_seconds'] for t in overlap),
            'prefix_finalization':stats(t['prefix_ready_seconds']-t['feedback_ready_seconds'] for t in overlap),
            'prefix_to_first_callback':stats(t['chunks'][0]['ready_seconds']-t['prefix_ready_seconds'] for t in overlap),
            'tail_revision':stats(t['tail_revision_end_seconds']-t['tail_revision_start_seconds'] for t in overlap)},
        tail_finished_after_first_audio=sum(t['tail_revision_end_seconds']>t['chunks'][0]['ready_seconds'] for t in overlap),
        measured_overlap_s=stats(max(0,min(t['tail_revision_end_seconds'],t['chunks'][0]['ready_seconds'])-max(t['tail_revision_start_seconds'],t['prefix_ready_seconds'])) for t in overlap),
        audio_requests=sum(len(r['audio_calls']) for r in rows),chunks=sum(r['chunks'] for r in rows),
        errors=[dict(case=r['case'],error=r['error']) for r in rows if r['error']])


def main():
    manifest=json.loads((D/'manifest_motion_overlap_v2.json').read_text())
    records=[]
    for path in sorted((D/'run'/RUN).glob('*/*/*/result.json')):
        row=json.loads(path.read_text());j=path.with_name('judgment.json')
        row['judge']=json.loads(j.read_text()) if j.exists() else None
        row['configured_word_count']=sum(any(c.isalnum() for c in token) for token in row['answer'].split())
        row['path']=str(path.relative_to(ROOT));records.append(row)
    result=dict(run=RUN,status=manifest['status'],planned=36,recorded=len(records),
        methodology=manifest['methodology'],limitations=manifest['limitations'],
        arms={a:summarize([r for r in records if r['arm']==a],18) for a in manifest['arms']},
        stages={stage:{a:summarize([r for r in records if r['arm']==a and r['stage']==stage],6) for a in manifest['arms']} for stage in ['opening','rebuttal','closing']},
        motions={f'motion_{i:02}':{a:summarize([r for r in records if r['arm']==a and r['case'].startswith(f'motion_{i:02}_')],6) for a in manifest['arms']} for i in range(1,4)})
    pairs=[]
    bykey={(r['case'],r['arm']):r for r in records}
    for case in json.loads((D/'cases_motion_overlap_v1.json').read_text()):
        a=bykey.get((case['id'],'natural_prefix'));b=bykey.get((case['id'],'short_prefix'))
        if not a or not b:continue
        row=dict(case=case['id'],stage=case['stage'],side=case['side'],status_natural=a['status'],status_short=b['status'])
        for metric in ['generation_to_first_audio_seconds','audio_seconds','answer_words','estimated_total_gap_seconds']:
            row[metric+'_delta_short_minus_natural']=b[metric]-a[metric] if a[metric] is not None and b[metric] is not None else None
        if a['judge'] and b['judge']:
            row['quality_delta']=b['judge']['quality']-a['judge']['quality']
            if a['judge']['rebuttal_strength'] is not None and b['judge']['rebuttal_strength'] is not None:
                row['rebuttal_strength_delta']=b['judge']['rebuttal_strength']-a['judge']['rebuttal_strength']
        pairs.append(row)
    result['pairs']=pairs
    result['paired_first_audio_delta_s']=stats(p['generation_to_first_audio_seconds_delta_short_minus_natural'] for p in pairs)
    deltas=[p['generation_to_first_audio_seconds_delta_short_minus_natural'] for p in pairs if p['generation_to_first_audio_seconds_delta_short_minus_natural'] is not None]
    result['short_prefix_faster_pairs']=sum(d<0 for d in deltas)
    result['natural_prefix_faster_pairs']=sum(d>0 for d in deltas)
    db=sqlite3.connect(f'file:{D/"run/cost.sqlite"}?mode=ro',uri=True);db.execute('BEGIN')
    costs={}
    for prefix in ['flat-motion-overlap-v1/','flat-motion-overlap-v2/','flat-motion-overlap-','']:
        rows=list(db.execute('select label,estimated_usd,state from calls where instr(label,?)=1',(prefix,))) if prefix else list(db.execute('select label,estimated_usd,state from calls'))
        exposure=db.execute(exposure_query(' WHERE instr(c.label,?)=1'),(prefix,)).fetchone()[0] if prefix else db.execute(exposure_query()).fetchone()[0]
        costs[prefix or 'global']=dict(known_usage_estimate_usd=sum(c or 0 for _,c,_ in rows),accounted_exposure_usd=exposure,
            states=dict(Counter(s for _,_,s in rows)),unknown_usage_calls=sum(c is None for _,c,_ in rows),calls=len(rows))
    result['costs']=costs
    result['first_run_failure_diagnosis']=json.loads((D/'run/flat-motion-overlap-v1/diagnosis.json').read_text())
    # Prompt/token truncation is reported even if a returned answer looks fluent.
    truncated=[]
    for (callid,) in db.execute('select id from calls where instr(label,?)=1',(RUN+'/',)):
        p=D/'run'/f'call_{callid:06}.json'
        if p.exists():
            d=json.loads(p.read_text())
            if d.get('truncated'):truncated.append(dict(call_id=callid,label=d['label']))
    result['truncated_model_calls']=truncated
    db.close()
    output=D/f'{RUN}_summary.json';output.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    fields=['case','stage','side','arm','status','budget','first_audio_s','first_chunk_s','audio_seconds','answer_words','configured_word_count','estimated_gap_s','quality','rebuttal_strength','strawman','lost_conditions','unsupported_facts','path']
    with (D/f'{RUN}_turns.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for r in records:
            row={k:r[k] for k in ['case','stage','side','arm','status','budget','audio_seconds','answer_words','configured_word_count','path']}
            row.update(first_audio_s=r['generation_to_first_audio_seconds'],first_chunk_s=r['events'][0]['audio_seconds'] if r['events'] else None,estimated_gap_s=r['estimated_total_gap_seconds'])
            row.update({k:r['judge'].get(k) if r['judge'] else None for k in ['quality','rebuttal_strength','strawman','lost_conditions','unsupported_facts']});writer.writerow(row)
    print(json.dumps({k:result[k] for k in ['status','recorded','arms','costs']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
