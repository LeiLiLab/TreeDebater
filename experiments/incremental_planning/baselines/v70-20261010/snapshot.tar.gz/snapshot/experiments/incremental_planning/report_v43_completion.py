"""Offline validation and quality report for the one v43 continuation."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'src'))
from pydub import AudioSegment
from streaming.experiment_accounting import exposure_query

D = ROOT/'experiments/incremental_planning'
P = D/'run/listening-motion-live-v43-completion-v1'
S = D/'run/listening-motion-live-v43'
manifest = json.loads((P/'manifest.json').read_text())
speeches = json.loads((P/'speeches.json').read_text())
original = json.loads((S/'generated_speeches.json').read_text())
assert manifest['status'] == 'completed' and len(speeches) == 6
assert [s['content'] for s in speeches[:4]] == [s['content'] for s in original]
for path, sha in manifest['sources'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha
for path, sha in json.loads((P/'source_snapshot/files.json').read_text()).items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == sha
traces = []
for i in (4,5):
    speech = speeches[i]
    folder = P/f"{i:02}_closing_{speech['side']}"
    trace = json.loads(next(folder.glob('*_chunks/listening_prefix.json')).read_text())
    traces.append(trace)
    assert trace['status'] == 'completed'
    assert trace['committed_text'] == speech['content']
    data = json.loads((folder/'input.json').read_text())
    assert data['our_side'] == speech['side']
    assert [h['content'] for h in data['debate_history']] == [h['content'] for h in speeches[:i]]
    assert abs(len(AudioSegment.from_file(speech['audio']))/1000-speech['audio_seconds']) < .05
assert all(Path(s['audio']).is_file() for s in speeches)
assert traces[0]['chunks'][0]['text'] == traces[1]['chunks'][0]['text']
assert abs(len(AudioSegment.from_file(P/'complete_motion.mp3'))/1000-manifest['total_audio_seconds']) < .05

db = sqlite3.connect(D/'run/cost.sqlite')
db.row_factory = sqlite3.Row
rows = [dict(r) for r in db.execute('select * from calls where instr(label,?)=1 order by id', (P.name+'/',))]
assert rows and all(r['state'] == 'ok' for r in rows)
assert db.execute("select count(*) from calls where state='pending'").fetchone()[0] == 0
bundles, text_calls = [], []
for row in rows:
    artifact = json.loads((D/'run'/f"call_{row['id']:06}.json").read_text())
    if artifact['request']['model'] == 'bounded-audio-bundle':
        bundles += artifact['external_calls']
    else:
        text_calls.append(artifact)
assert all(c['model'] == 'tts-1' and c['state'] == 'ok' for c in bundles)
for side in ('for', 'against'):
    prefix = next(c for c in text_calls if c['label'].endswith(f'{side}/closing/listening_prefix_draft'))
    payload = json.loads(prefix['request']['messages'][-1]['content'].rsplit('\n',1)[-1])
    assert payload['context']['our_side'] == side
    assert prefix['request']['temperature'] == .3
exposure = db.execute(exposure_query(' WHERE instr(c.label,?)=1'), (P.name+'/',)).fetchone()[0]
global_used = db.execute(exposure_query()).fetchone()[0]
known = sum(r['estimated_usd'] for r in rows)

findings = [
    dict(severity='major', turns=[4], kind='reversed_stance', quote='Therefore, we must oppose this motion.',
         finding='FOR closing takes the AGAINST position throughout. The first-paragraph framework already says position=against despite input our_side=for. Compact Audience feedback flags this reversal; one body revision retains it. Final advisory review also flags stance, but its empty source_quote fails local quote validation.'),
    dict(severity='major', turns=[4,5], kind='identical_first_paragraphs', quote=traces[0]['chunks'][0]['text'],
         finding='Both new closings use exactly the same first paragraph and substantially overlapping argument order.'),
    dict(severity='major', turns=[4,5], kind='unqualified_policy_inference', quote='get out of jail free',
         finding='The claim that a labeling obligation excuses responsibility for unlabeled misinformation is not established; this should be a conditional implementation risk.'),
    dict(severity='major', turns=[4,5], kind='unqualified_privacy_claim', quote='encryption itself',
         finding='Both closings assert encryption must be broken to inspect provenance, treating an unspecified implementation and inspection location as necessary.'),
    dict(severity='moderate', turns=[5], kind='unqualified_behavior_claim', quote="blindly trust a machine's judgment",
         finding='Automated labels are asserted to replace media literacy without supplied evidence or conditional framing.'),
]
for finding in findings:
    assert all(finding['quote'] in speeches[i]['content'] for i in finding['turns'])
reconciliation = json.loads((P/'reconciliation.json').read_text())
assert reconciliation['applied'] and not reconciliation['issues'] and reconciliation['pending'] == 0
report = dict(status='completed_with_quality_failures', motion=manifest['motion'], scope=manifest['scope'],
    restoration=manifest['restoration'], artifact_checks='passed', quality_pass=False,
    live_asr_benchmark_completed=False, reused_speeches=4, new_speeches=2,
    total_audio_seconds=manifest['total_audio_seconds'],
    closing_durations=[s['audio_seconds'] for s in speeches[4:]],
    closing_duration_within_3_percent=all(abs(s['audio_seconds']-120)<=3.6 for s in speeches[4:]),
    text_calls=len(text_calls), tts_requests=len(bundles), asr_requests=0, pending_calls=0,
    all_continuation_requests_successful=True,
    cost=dict(known_usage_estimate_usd=known, conservative_incremental_usd=exposure,
        continuation_cap_usd=5, cumulative_accounted_exposure_usd=global_used,
        cumulative_cap_usd=320, remaining_usd=320-global_used,
        original_v43_known_usage_usd=.67465404, combined_v43_known_usage_usd=.67465404+known,
        invoice_settled=False), findings=findings,
    checks=dict(reused_text_exact=True, reused_audio_hashes_unchanged=True, prior_history_exact=True,
        for_closing_in_against_history=True, tts_text_equals_saved_transcript=True,
        production_sources_unchanged=True, audio_decodable=True, budget_audit_pass=True),
    diagnosis='Wrong stance originates in FOR prefix authoring despite correct side/context. Endpoint review accepts it. Audience feedback detects it, but revision preserves the immutable wrong opening. Final review is advisory. This is observed behavior, not a controlled causal comparison.',
    outputs=dict(conversation=str(P/'conversation.txt'), audio=str(P/'complete_motion.mp3'), speeches=str(P/'speeches.json')),
    limitations=['Full generated text, not ASR-recognized history, seeds the two new closings.',
        'Original real-time run remains interrupted during AGAINST rebuttal. This does not measure restored streaming timing.',
        'Usage estimates and conservative ledger allowances are not settled provider invoices.',
        'No corrective rerun or production prompt change was performed.'])
(P/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(P/'manual_quality_review.json').write_text(json.dumps(dict(
    scope='New closings only; earlier concerns remain in the source run report', passed=False, findings=findings),
    ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','total_audio_seconds','text_calls','tts_requests','cost')},indent=2))
