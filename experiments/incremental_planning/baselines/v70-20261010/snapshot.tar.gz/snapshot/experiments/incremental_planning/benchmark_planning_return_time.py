"""Replay three v36 closing planning requests, optionally using readable projection.

No billable calls without --execute. Uses existing global/study ledgers plus a
USD1 local guard and an atomic three-dispatch limit. No automatic retries.
"""
import argparse
import copy
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from streaming import experiment_client as transport
from streaming.experiment_accounting import exposure_query

RUN = 'listening-motion-live-v36-planning-latency-v1'
LEDGER = D / 'run'
OUT = LEDGER / RUN
ORIGINALS = (19375, 19377, 19380)
CAP, LOCAL_CAP, TIMEOUT = 300., 1., 60.


def save(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def main():
    global RUN, OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--readable', action='store_true', help='Use the audited readable planning context')
    args = parser.parse_args()
    if args.readable:
        RUN = 'listening-motion-live-v36-planning-readable-latency-v1'
        OUT = LEDGER / RUN
    requests = [json.loads((LEDGER / f'call_{i:06}.json').read_text()) for i in ORIGINALS]
    original_hashes = [sha(x['request']) for x in requests]
    if args.readable:
        from streaming.branch_planning import branch_prompt
        from audit_readable_planning import audit
        from streaming.planning_view import readable_planning_context
        for source in requests:
            original = copy.deepcopy(source['request'])
            message = next(m for m in source['request']['messages'] if '{"context":' in m['content'])
            text = message['content']
            offset = text.index('{"context":')
            payload, length = json.JSONDecoder().raw_decode(text[offset:])
            frozen = copy.deepcopy(payload)
            audit(payload['context'], readable_planning_context(payload['context']))
            message['content'] = branch_prompt(payload['context'], payload['heard_prefix'],
                                               payload['previous_state']) + text[offset + length:]
            assert payload == frozen
            assert {k:v for k,v in original.items() if k != 'messages'} == {
                k:v for k,v in source['request'].items() if k != 'messages'}
    client = transport.BudgetedClient(LEDGER, cap=CAP)
    manifest = dict(run=RUN, status='prepared',
        authorization='User approved an additional USD30 for this study (global300/study210), '
            'then explicitly requested ' + ('重新发给模型看看时间 for the three deduplicated requests. '
            if args.readable else '单独测这个返回时间 for these failed planning requests. ') +
            'This bounded follow-up consumes existing approved headroom; no cap increase.',
        readable_projection=args.readable, original_request_hashes=original_hashes,
        source_call_ids=ORIGINALS, request_hashes=[sha(x['request']) for x in requests],
        calls=3, repetitions_per_request=1, sequential=True, retries=0,
        request_timeout_seconds=TIMEOUT, original_timeout_seconds=3,
        expected_known_usage_usd=[.005, .02], conservative_reservations_usd=sum(x['reservation_usd'] for x in requests),
        local_cap_usd=LOCAL_CAP, global_cap_usd=CAP, study_cap_usd=210,
        prices={'input_per_million_usd': .13, 'output_per_million_usd': .40},
        prices_checked_utc='2026-10-07', price_source='https://aws.amazon.com/jp/bedrock/pricing/',
        starting_ledger=client.summary(), harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        measurement='Non-streaming HTTP return time through the same local proxy. Header receipt '
            'is not model first-token time. No ASR, TTS, or other model jobs dispatched by this probe.',
        limitations='One fresh sample per original request, under later service load. '
            'This does not recover the original timed-out requests or establish a tail-latency distribution.')
    if not args.execute:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        client.db.close()
        return
    assert client.db.execute("select count(*) from calls where state='pending'").fetchone()[0] == 0
    study = client.db.execute("select sql from sqlite_master where name='study_guard_88d859c62308e091'").fetchone()[0]
    assert '> 210.0 ' in study
    assert manifest['conservative_reservations_usd'] < LOCAL_CAP
    OUT.mkdir(exist_ok=False)
    (OUT / 'harness.py').write_bytes(Path(__file__).read_bytes())
    if args.readable:
        for name in ('planning_view.py', 'branch_planning.py'):
            (OUT / name).write_bytes((ROOT / 'src' / 'streaming' / name).read_bytes())
        (OUT / 'audit_readable_planning.py').write_bytes((D / 'audit_readable_planning.py').read_bytes())
    prefix = "'" + RUN + "/'"
    where = f' WHERE instr(c.label,{prefix})=1'
    exposure = exposure_query(where)
    count = f'SELECT count(*) FROM calls c{where}'
    trigger = 'probe_guard_' + hashlib.sha256(RUN.encode()).hexdigest()[:16]
    client.db.execute(f'CREATE TRIGGER {trigger} BEFORE INSERT ON calls '
        f'WHEN instr(NEW.label,{prefix})=1 AND '
        f'(NEW.reserved + ({exposure}) > {LOCAL_CAP} OR ({count}) >= 3) '
        "BEGIN SELECT RAISE(ABORT, 'Planning return-time probe budget/count exceeded'); END")
    client.db.commit()
    before = client.db.execute('select count(*) from calls').fetchone()[0]
    try:
        client.db.execute("insert into calls(label,created,reserved,state) values(?,?,?,'pending')",
                          (RUN + '/guard-check', 'offline', 2.))
        raise AssertionError('Local guard failed')
    except transport.sqlite3.IntegrityError as exc:
        assert 'probe budget/count exceeded' in str(exc)
    client.db.rollback()
    assert client.db.execute('select count(*) from calls').fetchone()[0] == before
    manifest.update(status='running', launched_utc=datetime.now(timezone.utc).isoformat(),
                    local_trigger=trigger, guard_rejection_verified=True)
    save(OUT / 'manifest.json', manifest)
    original_open = transport.urlopen
    results = []
    try:
        for source_id, source in zip(ORIGINALS, requests):
            expected = source['request']
            row = dict(source_call_id=source_id, request_sha256=sha(expected),
                       input_characters=sum(len(m['content']) for m in expected['messages']))
            @contextmanager
            def measured_open(request, *, timeout):
                assert json.loads(request.data) == expected, 'Replay payload differs from original'
                assert timeout == TIMEOUT
                started = time.perf_counter()
                try:
                    with original_open(request, timeout=timeout) as response:
                        row['headers_received_seconds'] = time.perf_counter() - started
                        row['http_status'] = response.status
                        row['proxy_timing_headers'] = {k: v for k, v in response.headers.items()
                            if k.lower() in ('x-litellm-response-duration-ms', 'x-litellm-overhead-duration-ms')}
                        yield response
                finally:
                    row['http_return_seconds'] = time.perf_counter() - started
            transport.urlopen = measured_open
            client.label = f'{RUN}/source_{source_id}'
            try:
                client.complete(expected['messages'], max_tokens=expected['max_tokens'],
                    temperature=expected['temperature'], json_mode=expected.get('response_format') == {'type':'json_object'},
                    model=expected['model'], request_timeout=TIMEOUT)
            except Exception as exc:
                row['error'] = f'{type(exc).__name__}: {exc}'
                results.append(row)
                raise
            call_id, seconds, estimated = client.db.execute(
                'select id,seconds,estimated_usd from calls where label=?', (client.label,)).fetchone()
            actual = json.loads((LEDGER / f'call_{call_id:06}.json').read_text())
            assert actual['request'] == expected
            response = actual['response']
            content = response['choices'][0]['message']['content']
            try:
                parsed = json.loads(content)
            except ValueError:
                parsed = None
            row.update(call_id=call_id, client_seconds=seconds, estimated_usage_usd=estimated,
                usage=response.get('usage'), finish_reason=response['choices'][0]['finish_reason'],
                exceeded_original_timeout=row['http_return_seconds'] > 3,
                valid_json=isinstance(parsed, dict),
                overview_ready=parsed.get('overview', {}).get('ready') if isinstance(parsed, dict) else None,
                output=content)
            results.append(row)
            save(OUT / 'results.json', results)
            print(json.dumps({k:v for k,v in row.items() if k not in ('output','usage')}, ensure_ascii=False), flush=True)
        manifest['status'] = 'completed'
    except BaseException as exc:
        manifest.update(status='stopped', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        transport.urlopen = original_open
        ending = client.summary()
        manifest.update(finished_utc=datetime.now(timezone.utc).isoformat(), ending_ledger=ending,
            completed_samples=sum('call_id' in x for x in results),
            pending_calls=client.db.execute("select count(*) from calls where state='pending'").fetchone()[0],
            known_usage_usd=sum(x.get('estimated_usage_usd') or 0 for x in results),
            conservative_exposure_usd=client.db.execute(exposure).fetchone()[0])
        save(OUT / 'results.json', results)
        save(OUT / 'manifest.json', manifest)
        client.db.close()


if __name__ == '__main__':
    main()
