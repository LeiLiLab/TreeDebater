"""Publish the interrupted live trial and its separately completed audio artifacts."""
import json,shutil
from pathlib import Path
from pydub import AudioSegment

ROOT=Path(__file__).resolve().parents[2]
D=ROOT/'experiments/incremental_planning'
OUT=D/'run/listening-motion-live-v46'
r=json.loads((OUT/'report.json').read_text())
completion=json.loads((OUT/'completion-v1/manifest.json').read_text())
assert completion['status']=='completed'
last=json.loads((OUT/'completion-v1/05_closing_against/result.json').read_text())
speeches=[]
for path in sorted(OUT.glob('[0-9][0-9]_*/result.json')):
    row=json.loads(path.read_text())
    text=row.get('answer') or '\n\n'.join(c['text'] for c in row['chunks'])
    audio=next(path.parent.glob('*.mp3'))
    speeches.append(dict(index=row['index'],stage=row['stage'],side=row['side'],content=text,
        audio=str(audio),origin='original live trial',live_status=row['status']))
speeches.append(dict(index=5,stage='closing',side='against',content=last['content'],
    audio=last['audio'],origin='separate artifact completion',live_status='not measured'))
assert len(speeches)==6
combined=AudioSegment.empty()
for s in speeches:
    segment=AudioSegment.from_file(s['audio'])
    s['audio_seconds']=len(segment)/1000
    combined+=segment
combined.export(OUT/'complete_motion.mp3',format='mp3',bitrate='128k')
assert abs(len(AudioSegment.from_file(OUT/'complete_motion.mp3'))/1000-sum(s['audio_seconds'] for s in speeches))<.3
(OUT/'speeches.json').write_text(json.dumps(speeches,ensure_ascii=False,indent=2)+'\n')
(OUT/'conversation.txt').write_text('Six generated speeches. Original live trial interrupted during speech5; speech6 completed separately.\n\n'+
    '\n\n'.join(f"{s['index']+1}. {s['side'].upper()} {s['stage'].upper()} ({s['live_status']})\n\n{s['content']}" for s in speeches)+'\n')
quality=json.loads((OUT/'quality_review.json').read_text());assert quality['status']=='completed'
r.update(generated_speeches=6,completed_live_turns=4,quality_review=quality,quality_pass=False,
    acceptance_pass=False,completion=dict(status='completed',scope=completion['scope'],
        restoration=completion['restoration'],audio_seconds=last['audio_seconds'],live_timing_comparable=False),
    combined_audio=dict(path='complete_motion.mp3',audio_seconds=len(combined)/1000,
        note='Six generated speech MP3s concatenated. Runtime pauses and ASR interruption are not inserted; not a continuous live recording.'))
r['final_offline_tests_passed']=320
r['overlap_audit']['reused_audience_feedback_requests']=3
(OUT/'report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
labels=['正方开篇','反方开篇','正方驳论','反方驳论','正方结辩']
lines=['v46 简化流程验证：未通过',
    'Motion: Learning to be a good writer still matters in the age of AI',
    '',
    '六段文字和音频已齐全。原始实时实验仅完整完成前四段，第五段因Whisper请求超时中断；第六段使用补齐的真实ASR另行生成，不能算整场实时通过。',
    '回退快照：'+r['rollback_snapshot'],
    '',
    '已删除的额外模型调用：首段语义/变更/终点评审、准备期正文反馈、最终正文检查/修复/复查、TTS改写语义评审。实际对应调用数均为0。',
    '正文复用原有起草/修改模板；closing跳过Audience；保留原有段落切分、FastSpeech、并行TTS、版本一致性和首段不可改写检查。',
    '320项离线流程测试通过。补全期间修复了本地格式修复提示的输出schema和首段长度约束，没有恢复额外语义评审。',
    '',
    '内容回归：反方驳论首段明确支持正方，几乎复述正方上一段开头。framework虽然标记against，实际文本立场却相反；后续正文又回到反方。标签和格式检查不能验证实际文本立场。',
    '补全的反方结辩初稿也曾给出for标签，被本地检查拦住；先修复输出格式，再缩短过长候选，最后生成正确反方首段。先前失败调用和费用全部保留。',
    '其他内容问题：双方仍将“写作仍然重要”争论成“亲自写作是否唯一/必要”，并提出缺乏证据的认知退化/效率断言；扩写存在修辞重复。',
    '',
    '发言 | 首音(s) | 完整生成音频/目标(s) | 已完成播放块最大间隙(s) | 实时状态',
]
for label,t in zip(labels,r['turns']):
    lines.append(f"{label} | {t['first_audio_seconds']:.3f} | {t['audio_seconds']:.3f}/{t['target_seconds']} | {t['max_gap_seconds']:.3f} | {t['status']}")
lines += [f"反方结辩 | 不可与实时交接比较 | {last['audio_seconds']:.3f}/120 | 未做实时播放测量 | 单独补全",
    '首场从生成开始计时，其余原始场次从对方播放结束计时。第五段120.125秒是完整生成音频，不代表完整播放/转写成功。',
    '正方开篇约5.79秒、反方驳论约4.10秒间隙超过2秒目标。完整实时验证失败，无法报告六段实时通过率。',
    '',
    f"文字请求总计{sum(r['text_call_counts_by_phase'].values())}次（含补全与失败尝试）；各阶段计数见report.json。原始实验中断，不能与v45完整实时场次作受控性能比较。",
    f"新增用量估算${r['estimated_new_usage_usd']:.6f}；保守预算占用${r['new_conservative_exposure_usd']:.6f}/$10。",
    f"全局保守累计${r['ledger']['accounted_exposure_usd']:.6f}/$320，剩余${320-r['ledger']['accounted_exposure_usd']:.6f}；pending=0。金额为用量估算/保守记账，不是最终账单。",
    '',
    '建议：保留精简后的正文和TTS路径，单独恢复首段实际文本的立场检查。当前版本保留失败证据和回退快照；未将内容错误掩盖为通过。',
    '文件：complete_motion.mp3（六段生成音频，不插入等待）、conversation.txt（六段全文）、prefix_stance_regression.json（立场错误证据）、report.json（详细计时和费用）。']
(OUT/'report.txt').write_text('\n'.join(lines)+'\n')
for src,name in [('/tmp/listening-motion-live-v46.log','run.log'),('/tmp/v46-final-offline-tests.log','offline_tests.log'),
    ('/tmp/listening-motion-live-v46-completion.log','completion_attempt1.log'),
    ('/tmp/listening-motion-live-v46-completion-resume.log','completion_attempt2.log'),
    ('/tmp/listening-motion-live-v46-completion-final.log','completion_final.log')]:shutil.copy2(src,OUT/name)
print(json.dumps(dict(generated_speeches=6,completed_live_turns=4,acceptance_pass=False,
    usage_usd=r['estimated_new_usage_usd'],exposure_usd=r['new_conservative_exposure_usd'],
    text_calls=sum(r['text_call_counts_by_phase'].values()),report=str(OUT/'report.txt')),indent=2))
