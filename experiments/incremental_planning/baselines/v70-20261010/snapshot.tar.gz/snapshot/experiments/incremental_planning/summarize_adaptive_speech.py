"""Read-only four-arm speech report; retain silent/partial attempts and costs."""
from collections import Counter
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.experiment_accounting import exposure_query
from summarize_flat_speech import stats, boot

DIRECTORY = Path(__file__).resolve().parent
RUN = 'flat-full-adaptive-v1'


def main():
    manifest = json.loads((DIRECTORY / 'manifest_adaptive_speech_v1.json').read_text())
    records = []
    for path in sorted((DIRECTORY / 'run' / RUN).glob('*/*/*/result.json')):
        row = json.loads(path.read_text())
        judge = path.with_name('judgment.json')
        row['judge'] = json.loads(judge.read_text()) if judge.exists() else None
        row['path'] = str(path.relative_to(ROOT))
        records.append(row)
    database = sqlite3.connect(f'file:{DIRECTORY / "run/cost.sqlite"}?mode=ro', uri=True)
    database.execute('BEGIN')  # One consistent cost snapshot while a run is active.
    entries = list(database.execute('SELECT label,estimated_usd,state FROM calls WHERE instr(label,?)=1', (RUN+'/',)))
    categories = Counter()
    for label, cost, _ in entries:
        categories[label.rsplit('/', 1)[-1]] += cost or 0
    arms = {}
    for arm in manifest['arms']:
        rows = [row for row in records if row['arm'] == arm]
        audible = [row for row in rows if row['chunks']]
        judged = [row for row in rows if row['judge'] is not None]
        passed = sum(sum(check['passed'] for check in row['judge']['checks']) for row in judged)
        profiles = [profile for row in rows for profile in row.get('chunk_profiles', [])]
        traces = [row['fixed_prefix_trace'] for row in rows if 'fixed_prefix_trace' in row]
        fixed = [trace for trace in traces if 'tail_revision_end_seconds' in trace and trace['chunks']]
        arms[arm] = {
            'attempts_recorded': len(rows), 'attempts_planned': len(manifest['case_ids']),
            'audible_turns': len(audible), 'returned_without_error': sum(row['status']=='returned' for row in rows),
            'silent_failures': sum(row['status']=='failed_silent' for row in rows),
            'partial_failures': sum(row['status']=='failed_partial' for row in rows),
            'errors': dict(Counter(row['error']['type']+': '+row['error']['message'] for row in rows if row['error'])),
            'first_audio_seconds_conditional_on_output': stats(row['generation_to_first_audio_seconds'] for row in audible),
            'estimated_endpoint_first_audio_seconds': stats(row['estimated_endpoint_to_first_audio_seconds'] for row in audible),
            'first_chunk_audio_seconds': stats(row['events'][0]['audio_seconds'] for row in audible),
            'first_chunk_words': stats(len(row['events'][0]['text'].split()) for row in audible),
            'first_audio_by_seconds_all_attempts': {str(t): sum(row['generation_to_first_audio_seconds'] <= t
                for row in audible) for t in (5, 8, 10, 12, 15, 20, 30)},
            'estimated_queue_gap_seconds': stats(row['estimated_total_gap_seconds'] for row in audible),
            'turns_with_estimated_gap': sum(row['estimated_total_gap_seconds'] > .05 for row in audible),
            'audio_seconds_all_attempts': stats(row['audio_seconds'] for row in rows),
            'audio_above_60_seconds': sum(row['audio_seconds'] > 60 for row in rows),
            'words_all_attempts': stats(row['answer_words'] for row in rows),
            'worker_return_seconds_all_attempts': stats(row['worker_return_seconds'] for row in rows),
            'judged_turns': len(judged), 'missing_judgments_on_audio': len(audible)-len(judged),
            'condition_checks_passed': passed, 'condition_checks_judged': len(judged)*3,
            'condition_coverage_percent_judged': 100*passed/(3*len(judged)) if judged else None,
            'delivered_check_coverage_percent_all_attempts': 100*passed/(3*len(rows))
                if rows and len(audible)==len(judged) else None,
            'strength': stats(row['judge']['rebuttal_strength'] for row in judged),
            'relevance': stats(row['judge']['relevance'] for row in judged),
            'strawman_flags': sum(row['judge']['strawman'] for row in judged),
            'unsupported_flags': sum(row['judge']['unsupported_facts'] for row in judged),
            'delivered_chunks': sum(row['chunks'] for row in rows),
            'delivered_rewritten_chunks': sum(int(profile['chosen_intra_iter']) > 0 for profile in profiles),
            'refinement_requests': sum(row['refinement_usage']['calls'] for row in rows),
            'audio_http_calls': sum(len(row['audio_calls']) for row in rows),
            'generation_usage_usd': sum(row['generation_usage']['reported_usage_estimate_usd'] for row in rows),
            'refinement_usage_usd': sum(row['refinement_usage']['reported_usage_estimate_usd'] for row in rows),
            'audio_usage_usd': sum(row['audio_usage']['reported_usage_estimate_usd'] for row in rows),
            'fixed_prefix_fallbacks': sum('fallback_reason' in trace for trace in traces),
            'fixed_prefix_fallback_reasons': [trace['fallback_reason'] for trace in traces if 'fallback_reason' in trace],
            'fixed_prefix_tail_finished_after_first_audio': sum(trace['tail_revision_end_seconds'] > trace['chunks'][0]['ready_seconds'] for trace in fixed),
            'fixed_prefix_timing_samples': [{key: trace[key] for key in ('draft_ready_seconds', 'feedback_ready_seconds',
                'prefix_ready_seconds', 'tail_revision_start_seconds', 'tail_revision_end_seconds')} for trace in fixed],
        }
        arms[arm]['operating_usage_including_quarter_preparation_usd'] = (
            arms[arm]['generation_usage_usd']+arms[arm]['refinement_usage_usd']+arms[arm]['audio_usage_usd']
            + categories['preparation']/4)
    lookup = {(row['case'], row['arm']): row for row in records}
    comparisons = {}
    for name, candidate, control in [
            ('adaptive_vs_locked12', 'full_adaptive12', 'full_locked12'),
            ('short8_vs_adaptive12', 'full_adaptive8', 'full_adaptive12'),
            ('fixed_vs_full8', 'fixed_prefix8', 'full_adaptive8'),
            ('fixed_vs_locked12', 'fixed_prefix8', 'full_locked12')]:
        metrics = {}
        for metric in ('first_audio', 'delivered_coverage', 'judged_coverage', 'strength', 'queue_gap'):
            values, included = [], []
            for case in manifest['case_ids']:
                a, b = lookup.get((case, candidate)), lookup.get((case, control))
                if a is None or b is None:
                    continue
                if metric in ('first_audio', 'queue_gap'):
                    if not a['chunks'] or not b['chunks']:
                        continue
                    key = 'generation_to_first_audio_seconds' if metric=='first_audio' else 'estimated_total_gap_seconds'
                    x, y = a[key], b[key]
                else:
                    if any(row['judge'] is None and (row['chunks'] or metric!='delivered_coverage') for row in (a, b)):
                        continue
                    if metric == 'strength':
                        x, y = a['judge']['rebuttal_strength'], b['judge']['rebuttal_strength']
                    else:
                        x, y = [100*sum(c['passed'] for c in row['judge']['checks'])/3 if row['judge'] else 0 for row in (a, b)]
                values.append(x-y)
                included.append(case)
            metrics[metric] = dict(boot(values), cases=included, direction=candidate+' minus '+control)
        comparisons[name] = metrics
    result = {
        'run_id': RUN, 'status': manifest['status'], 'completed_turns': len(records), 'arms': arms,
        'comparisons': comparisons, 'cost': {
            'known_usage_estimate_usd': sum(cost or 0 for _, cost, _ in entries),
            'ledger_entries': len(entries), 'pending': sum(state=='pending' for _, _, state in entries),
            'categories_usd': dict(categories),
            'run_exposure_usd': database.execute(exposure_query(' WHERE instr(c.label,?)=1'), (RUN+'/',)).fetchone()[0],
            'run_limit': manifest['estimate_usd']['run_exposure_stop'], 'cumulative_limit': 200,
            'global_usage_estimate_usd': database.execute('SELECT sum(estimated_usd) FROM calls').fetchone()[0],
            'global_exposure_usd': database.execute(exposure_query()).fetchone()[0],
            'note': 'Provisional usage estimates, not invoices. Full audio bundles retain their reservations.'},
        'per_turn': [dict({key: row[key] for key in ('case', 'arm', 'status', 'chunks', 'answer_words', 'audio_seconds',
            'generation_to_first_audio_seconds', 'estimated_total_gap_seconds', 'judge', 'error', 'path')},
            fallback=row.get('fixed_prefix_trace', {}).get('fallback_reason')) for row in records],
        'limitations': manifest['limitations'] + ['Silent turns are zero delivered checks, not invented quality verdicts.',
            'Case bootstrap intervals are unadjusted, with only eight authored known cases and one draw per arm.']}
    database.close()
    path = DIRECTORY / (RUN+'_summary.json')
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({key: result[key] for key in ('run_id', 'status', 'completed_turns', 'arms', 'cost')}, indent=2))


if __name__ == '__main__':
    main()
