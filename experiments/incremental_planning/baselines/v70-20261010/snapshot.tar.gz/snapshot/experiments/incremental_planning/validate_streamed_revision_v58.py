"""Retest scheme 1 with append-only native delivery; all requests are metered."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timezone
import argparse
import copy
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import threading
import time
from types import SimpleNamespace

import compare_revision_pipelines_v56 as base
import compare_native_revision_v57 as prior
from audio_probe import AudioGuard
from streaming.experiment_client import BudgetedClient, BudgetExceeded
from streaming.experiment_accounting import reconcile_success
from streaming.revision_stream import RevisionStream
from utils.prompts.speech_revision import REVISION_TASK, STREAMING_DELIVERY

ROOT,D,LEDGER=base.ROOT,base.D,base.LEDGER
RUN=base.PARENT+'-streamed-revision-v58'
OUT=LEDGER/RUN
RECORD=D/'prepared_streamed_revision_v58.json'
SOURCES=[Path(__file__),ROOT/'src/tts_streaming.py',ROOT/'src/streaming/revision_stream.py',
         ROOT/'src/utils/prompts/speech_revision.py',D/'audio_probe.py']
RESUME_RECORD=D/'prepared_streamed_revision_v58_resume.json'


def digests():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCES}


def run_one(case,repeat,attempt=1):
    import httpx
    from openai import OpenAI
    from pydub import AudioSegment
    import tts_streaming as tts
    cfg=prior.config()
    name=f'streamed_native_case{case["original_call_id"]}_r{repeat}'
    if attempt>1:name+=f'_attempt{attempt}'
    path=OUT/name
    path.mkdir(exist_ok=False)
    label=RUN+'/'+name
    guard=AudioGuard(LEDGER,label+'/tts',allowance=2.,approved_cap=base.GLOBAL_CAP,max_requests=64)
    clients,requests=[],[]
    lock=threading.Lock()
    stopped,prefix_ready=threading.Event(),threading.Event()
    prefix_at=[None]
    result=dict(status='running',case=case['original_call_id'],repeat=repeat,attempt=attempt,policy='streamed_native',
                output_config=asdict(cfg),chunks=[],text_requests=requests)
    stream=RevisionStream(prefix=case['material']['already_spoken_prefix'],
        draft=case['material']['unpublished_draft'],n_words=case['material']['remaining_word_target'],config=cfg)
    original=(tts.OpenAI,tts._text_request,tts._query_time_profiled,tts._tts_with_retry)
    pool=ThreadPoolExecutor(max_workers=1)
    t0=time.perf_counter()

    def fail(exc):
        stopped.set();stream.fail(exc)
        with guard.lock:guard.failed=True

    def factory(*args,**kwargs):
        client=OpenAI(http_client=httpx.Client(transport=guard,timeout=60),max_retries=0,
            base_url='https://api.openai.com/v1',timeout=60)
        with lock:clients.append(client)
        return client

    def text_request(client,model,messages,max_tokens,**kwargs):
        if stopped.is_set():raise BudgetExceeded('Stopped; no further request')
        with lock:
            if len(requests)>=48:
                exc=BudgetExceeded('Text request count cap');fail(exc);raise exc
            index=len(requests)
            event=dict(kind='native_length',start_seconds=time.perf_counter()-t0)
            requests.append(event)
        meter=BudgetedClient(LEDGER,cap=base.GLOBAL_CAP,label=label+f'/text_{index}')
        try:
            text=meter.complete(messages,model=base.MODEL,temperature=.3,max_tokens=max_tokens,request_timeout=60)
            event.update(done_seconds=time.perf_counter()-t0,
                ledger_id=meter.db.execute('select max(id) from calls where label=?',(meter.label,)).fetchone()[0])
            artifact=json.loads((LEDGER/f'call_{event["ledger_id"]:06}.json').read_text())
            if artifact.get('truncated'):raise ValueError('Truncated native length edit')
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=text))])
        except BaseException as exc:
            fail(exc);raise
        finally:meter.db.close()

    def query(client,text,voice='echo',speed=1.,model='tts-1'):
        if stopped.is_set():raise BudgetExceeded('Stopped; no further TTS')
        try:return original[2](client,text,voice=voice,speed=speed,model=model)
        except BaseException as exc:
            fail(exc);raise

    def no_retry(client,text,voice='echo',speed=1.,max_attempts=1,model='tts-1'):
        return query(client,text,voice,speed,model)

    def produce():
        meter=None
        try:
            if not prefix_ready.wait(10):raise TimeoutError('Prefix missing')
            if stopped.wait(max(0,prefix_at[0]+case['feedback_delay_seconds']-time.perf_counter())):
                raise RuntimeError('Stopped before revision')
            meter=BudgetedClient(LEDGER,cap=base.GLOBAL_CAP,label=label+'/whole_stream')
            req=copy.deepcopy(case['request'])
            req['messages'][-1]['content']=REVISION_TASK+STREAMING_DELIVERY+'\nContext and material (data):\n'+json.dumps(case['material'],ensure_ascii=False)
            base.save(path/'request.json',req)
            event=dict(kind='whole_stream',start_seconds=time.perf_counter()-t0)
            with lock:requests.append(event)
            text,ident,ttft=base.stream_complete(meter,req['messages'],stream.feed,max_tokens=4096,temperature=.3)
            stream.finish(text)
            event.update(done_seconds=time.perf_counter()-t0,ledger_id=ident,first_token_seconds=ttft)
            result['whole_revised_body']=text
        except BaseException as exc:
            fail(exc);raise
        finally:
            if meter is not None:meter.db.close()

    def publish(index,audio_path,text,duration):
        now=time.perf_counter()
        result['chunks'].append(dict(index=index,path=str(audio_path),text=text,audio_seconds=duration,
                                    ready_seconds=now-t0,revision_finished=stream.snapshot()['finished']))
        if index==0:
            prefix_at[0]=now;prefix_ready.set()

    try:
        tts.OpenAI=factory;tts._text_request=text_request;tts._query_time_profiled=query;tts._tts_with_retry=no_retry
        producer=pool.submit(produce)
        raw=Path(case['prefix_audio']).read_bytes()
        prepared=dict(text=case['material']['already_spoken_prefix'],voice=cfg.voice,model=cfg.model,
            tts_out=dict(audio_seconds=case['prefix_seconds'],tts_api_s=0.,mp3_parse_s=0.,mp3_bytes=raw))
        text,_,_=tts.convert_text_to_speech_streaming(case['material']['already_spoken_prefix'],
            str(path/'speech.mp3'),case['speech_budget_seconds'],config=cfg,on_chunk=publish,
            motion=case['material']['motion'],side=case['side'],tail_supplier=lambda:stream,prepared_first_audio=prepared)
        producer.result()
        if stopped.is_set():raise RuntimeError('Guard stopped this speech')
        cursor=result['chunks'][0]['ready_seconds'];gaps=[]
        audio=AudioSegment.empty()
        for row in result['chunks']:
            gap=max(0,row['ready_seconds']-cursor);gaps.append(gap)
            row['gap_seconds']=gap
            row['playback_start_seconds']=max(cursor,row['ready_seconds'])
            cursor=row['playback_start_seconds']+row['audio_seconds']
            audio+=AudioSegment.silent(duration=round(gap*1000))+AudioSegment.from_file(row['path'])
        seconds=sum(c['audio_seconds'] for c in result['chunks'])
        result.update(status='completed',text=text,metrics=dict(
            first_body_audio_seconds=result['chunks'][1]['ready_seconds']-result['chunks'][0]['ready_seconds'],
            first_body_after_feedback_seconds=result['chunks'][1]['ready_seconds']-result['chunks'][0]['ready_seconds']-case['feedback_delay_seconds'],
            final_audio_ready_seconds=result['chunks'][-1]['ready_seconds']-result['chunks'][0]['ready_seconds'],
            first_body_before_revision_complete=not result['chunks'][1]['revision_finished'],
            max_playback_gap_seconds=max(gaps),total_playback_gap_seconds=sum(gaps),audio_seconds=seconds,
            signed_duration_error_seconds=seconds-case['speech_budget_seconds'],
            duration_error_pct=100*(seconds-case['speech_budget_seconds'])/case['speech_budget_seconds'],
            chunks=len(result['chunks'])-1,text_calls=len(requests)))
        (path/'speech.txt').write_text(text+'\n');audio.export(path/'playback.wav',format='wav')
    except BaseException as exc:
        fail(exc);result.update(status='stopped',error=f'{type(exc).__name__}: {exc}');raise
    finally:
        pool.shutdown(wait=True,cancel_futures=True)
        tts.OpenAI,tts._text_request,tts._query_time_profiled,tts._tts_with_retry=original
        for client in clients:client.close()
        guard.finish();reconcile_success(guard.db,guard.request_id,guard.path);guard.db.close()
        result.update(wall_seconds=time.perf_counter()-t0,stream=stream.snapshot())
        base.save(path/'result.json',result)
    print(json.dumps(dict(run=name,**result['metrics'])),flush=True)


def prepare():
    if RECORD.exists():raise ValueError('Preparation already exists')
    cases=json.loads(prior.RECORD.read_text())['cases']
    record=dict(status='approved',run_id=RUN,created_utc=datetime.now(timezone.utc).isoformat(),
        authorization='User approved USD50 cumulative for both schemes and now requests improvement of scheme 1; continuation within that cap.',
        parent_cap_usd=50,run_cap_usd=8,estimate_new_usd=[1,2],
        rates_per_million=dict(text_input=.13,text_output=.4,tts_characters=15),
        rates_basis='Same-session AWS Gemma and OpenAI TTS official prices verified for v56; identical models.',
        configuration=asdict(prior.config()),cases=cases,source_digests=digests(),
        schedule=[dict(case=c['original_call_id'],repeat=r) for r in (1,2) for c in cases],
        boundaries='Frozen v57 cases/feedback/prefix/model. Updated evidence prompt and stable paragraph stream into original native length/candidate/deadline loop. First chunk target uses expected remaining text until EOF; later targets use actual remainder. Real requests and decoded audio, simulated playback. Historical v57 comparator, not contemporaneous randomized ablation.',
        automatic_retries=False,max_audio_requests_per_speech=64,audio_reservation_per_speech=2,max_text_requests_per_speech=48)
    meter=BudgetedClient(LEDGER,cap=base.GLOBAL_CAP)
    base.arm(meter.db,base.PARENT,50);base.arm(meter.db,RUN+'/',8);meter.db.close()
    base.save(RECORD,record)
    print('Prepared six speeches; USD8 run cap, USD50 cumulative cap.')


def prepare_resume():
    if RESUME_RECORD.exists():raise ValueError('Manual resume already prepared')
    old=json.loads(RECORD.read_text())
    results=[json.loads(p.read_text()) for p in OUT.glob('*/result.json')]
    if len(results)!=1 or results[0]['status']!='stopped':raise ValueError('Expected exactly the diagnosed first failed attempt')
    record=dict(old,source_digests=digests(),manual_resume=True,
        resume_reason='First TTS request failed with status omitted by old logging; add status-only diagnostics, one manual reattempt, no automatic retries or cap increase.',
        original_attempts_preserved=True,created_utc=datetime.now(timezone.utc).isoformat())
    record['schedule']=[dict(row,attempt=2 if i==0 else 1) for i,row in enumerate(old['schedule'])]
    base.save(RESUME_RECORD,record)
    print('One manual reattempt plus five unstarted speeches, within existing USD8/USD50 caps; prior failed reservations retained.')


def execute(resume=False):
    record=json.loads((RESUME_RECORD if resume else RECORD).read_text())
    if record['status']!='approved' or record['source_digests']!=digests():raise ValueError('Prepared sources changed')
    if not os.environ.get('OPENAI_API_KEY'):
        os.environ['OPENAI_API_KEY']=json.loads((ROOT/'src/configs/api_key.json').read_text())['OPENAI_API_KEY']
    import tts_streaming as tts
    tts.duration_estimator(prior.config()).query_time('Warm local speech estimator.')
    if not resume:OUT.mkdir(exist_ok=False)
    base.save(OUT/('resume_manifest.json' if resume else 'manifest.json'),record)
    for p in SOURCES:(OUT/(('resume_' if resume else '')+p.name)).write_bytes(p.read_bytes())
    completed=0
    try:
        for entry in record['schedule']:
            case=next(c for c in record['cases'] if c['original_call_id']==entry['case'])
            run_one(case,entry['repeat'],entry.get('attempt',1));completed+=1
            base.save(OUT/'progress.json',dict(status='running',completed=completed,total=6))
        base.save(OUT/'progress.json',dict(status='completed',completed=completed,total=6))
    except BaseException as exc:
        base.save(OUT/'progress.json',dict(status='stopped',completed=completed,total=6,error=str(exc)));raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true')
    parser.add_argument('--resume',action='store_true');parser.add_argument('--prepare-resume',action='store_true');args=parser.parse_args()
    if args.prepare_resume:prepare_resume()
    elif args.execute:execute(args.resume)
    else:prepare()
