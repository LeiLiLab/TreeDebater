"""Offline timing/duration comparison; no inference or audio provider calls."""
from collections import Counter
import csv
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'src'))
from streaming.experiment_accounting import exposure_query
from summarize_motion_overlap import stats

D = Path(__file__).resolve().parent
RUN = 'legacy-motion-full-v3'


def summarize(rows):
    complete = [r for r in rows if r['status'] == 'returned']
    audible = [r for r in rows if r['events']]
    return dict(recorded=len(rows), statuses=dict(Counter(r['status'] for r in rows)),
        first_audio_s=stats(r['generation_to_first_audio_seconds'] for r in audible),
        first_chunk_s=stats(r['events'][0]['audio_seconds'] for r in audible),
        duration_s=stats(r['audio_seconds'] for r in complete),
        signed_error_s=stats(r['audio_seconds']-r['budget'] for r in complete),
        absolute_error_s=stats(abs(r['audio_seconds']-r['budget']) for r in complete),
        duration_fraction=stats(r['audio_seconds']/r['budget'] for r in complete),
        within_5s=sum(abs(r['audio_seconds']-r['budget'])<=5 for r in complete),
        within_10pct=sum(abs(r['audio_seconds']-r['budget'])<=.1*r['budget'] for r in complete),
        over_budget=sum(r['audio_seconds']>r['budget'] for r in complete),
        queue_gap_s=stats(r['estimated_total_gap_seconds'] for r in audible),
        estimated_playback_span_s=stats(r['audio_seconds']+r['estimated_total_gap_seconds'] for r in complete),
        generation_to_estimated_playback_end_s=stats(r['events'][-1]['estimated_playback_end_seconds'] for r in complete if r['events']),
        turns_with_gap=sum(r['estimated_total_gap_seconds']>.05 for r in audible),
        worker_return_s=stats(r['worker_return_seconds'] for r in rows),
        all_audio_ready_s=stats(r['events'][-1]['playable_seconds'] for r in complete if r['events']),
        final_chunk_prestarted=sum(bool(r.get('chunk_profiles')) and r['chunk_profiles'][-1]['chosen_worker_label']=='prestart' for r in complete),
        final_chunk_out_of_range=sum(bool(r.get('chunk_profiles')) and r['chunk_profiles'][-1]['target_reached']=='False' for r in complete),
        timeout_turns=sum(any(c['timed_out']=='True' for c in r.get('chunk_profiles', [])) for r in rows),
        adopted_rewrite_chunks=sum(int(c['chosen_intra_iter'])>0 for r in rows for c in r.get('chunk_profiles', [])),
        rewrite_requests=sum(len(r.get('tts_rewrite_calls', [])) for r in rows),
        rewrite_requests_started_before_first=sum(c['start_seconds']<r['generation_to_first_audio_seconds']
            for r in audible for c in r.get('tts_rewrite_calls', [])),
        audio_http_requests=sum(len(r['audio_calls']) for r in rows),
        chunks=sum(r['chunks'] for r in rows),
        phase_seconds={name:stats(r['phases'].get(name) for r in rows)
            for name in ['whole_draft', 'feedback_total', 'whole_revision_total', 'final_revision_to_first_audio']}
            if rows and 'phases' in rows[0] else {})


def load_rows(run):
    rows=[]
    for path in sorted((D/'run'/run).glob('*/*/*/result.json')):
        r=json.loads(path.read_text()); r['path']=str(path.relative_to(ROOT))
        if run.startswith('legacy-motion-full-'):
            methods=r['method_phases']
            byname=lambda n: sorted([m for m in methods if m['method']==n], key=lambda m:m['start_seconds'])
            drafts=byname('_get_response'); revisions=byname('_length_adjust')
            r['phases']=dict(whole_draft=(drafts[0]['end_seconds']-drafts[0]['start_seconds']) if drafts else None,
                feedback_total=sum(m['end_seconds']-m['start_seconds'] for m in byname('_get_revision_suggestion')),
                whole_revision_total=sum(m['end_seconds']-m['start_seconds'] for m in revisions),
                final_revision_to_first_audio=(r['generation_to_first_audio_seconds']-revisions[-1]['end_seconds'])
                    if revisions and r['events'] else None)
        rows.append(r)
    return rows


def main():
    previous=load_rows('legacy-motion-full-v2')
    current=load_rows(RUN)
    rows=[r for r in previous if r['status']=='returned']+current
    case_order={c['id']:i for i,c in enumerate(json.loads((D/'cases_motion_overlap_v1.json').read_text()))}
    rows.sort(key=lambda r:case_order[r['case']])
    attempts=previous+current
    old=load_rows('flat-motion-overlap-v2')
    manifest=json.loads((D/'manifest_legacy_motion_full_v3.json').read_text())
    groups={'legacy':rows, **{arm:[r for r in old if r['arm']==arm]
                            for arm in ['natural_prefix','short_prefix']}}
    result=dict(run=RUN,status=manifest['status'],planned=18,recorded=len(rows),
        all_attempt_count=len(attempts),all_attempt_statuses=dict(Counter(r['status'] for r in attempts)),
        retained_prior_failures=[dict(case=r['case'],error=r['error'],first_audio_s=r['generation_to_first_audio_seconds'],partial_audio_s=r['audio_seconds'],path=r['path']) for r in previous if r['status']!='returned'],
        recovery_note='First3 completed v2 speeches retained. One request-limited partial v2 speech explicitly retried in v3; all original evidence preserved. V3 completes remaining15 contexts with larger request capacity; complete comparison includes one diagnosed retry.',
        comparison_note='Same motions, prior histories, claim plans and stage budgets; different current pipelines and separate measurement times. Legacy enables TTS rewrite; earlier overlap arms disabled it.',
        overall={arm:summarize(records) for arm,records in groups.items()},
        stages={stage:{arm:summarize([r for r in records if r['stage']==stage]) for arm,records in groups.items()}
            for stage in ['opening','rebuttal','closing']},
        motions={f'motion_{i:02}':summarize([r for r in rows if r['case'].startswith(f'motion_{i:02}_')]) for i in range(1,4)},
        errors=[dict(case=r['case'],error=r['error']) for r in rows if r['error']],
        limitations=manifest['limitations'])
    paired={}
    for arm in ['natural_prefix','short_prefix']:
        previous={r['case']:r for r in groups[arm]}
        pairs=[(r,previous[r['case']]) for r in rows if r['events'] and previous[r['case']]['events']]
        paired[arm]=dict(n=len(pairs),legacy_minus_previous_first_s=stats(a['generation_to_first_audio_seconds']-b['generation_to_first_audio_seconds'] for a,b in pairs),
            legacy_faster=sum(a['generation_to_first_audio_seconds']<b['generation_to_first_audio_seconds'] for a,b in pairs))
    result['paired']=paired
    db=sqlite3.connect(f'file:{D/"run/cost.sqlite"}?mode=ro',uri=True)
    db.execute('BEGIN')
    result['costs']={}
    for label,where,args in [('study', ' WHERE instr(c.label,?)=1', ('legacy-motion-',)), ('cumulative','',())]:
        result['costs'][label]=dict(known_usage_estimate_usd=db.execute('select coalesce(sum(c.estimated_usd),0) from calls c'+where,args).fetchone()[0],
            conservative_exposure_usd=db.execute(exposure_query(where),args).fetchone()[0],
            states=dict(db.execute('select c.state,count(*) from calls c'+where+' group by c.state',args)))
    result['costs']['cumulative']['cap_usd']=db.execute('select cap from budget where id=1').fetchone()[0]
    db.close()
    (D/f'{RUN}_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    fields=['case','stage','side','budget','status','first_audio_s','audio_s','signed_error_s','absolute_error_s','first_chunk_s','queue_gap_s','estimated_playback_span_s','rewrite_calls','path']
    with (D/f'{RUN}_turns.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        for r in rows:
            writer.writerow(dict(case=r['case'],stage=r['stage'],side=r['side'],budget=r['budget'],status=r['status'],
                first_audio_s=r['generation_to_first_audio_seconds'],audio_s=r['audio_seconds'],signed_error_s=r['audio_seconds']-r['budget'],
                absolute_error_s=abs(r['audio_seconds']-r['budget']),first_chunk_s=r['events'][0]['audio_seconds'] if r['events'] else None,
                queue_gap_s=r['estimated_total_gap_seconds'],estimated_playback_span_s=r['audio_seconds']+r['estimated_total_gap_seconds'],
                rewrite_calls=len(r['tts_rewrite_calls']),path=r['path']))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
