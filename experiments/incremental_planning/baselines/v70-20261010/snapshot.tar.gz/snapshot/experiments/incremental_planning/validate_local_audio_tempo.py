"""Offline replay of saved speech: no model, TTS, HTTP or paid compute calls."""
from dataclasses import asdict
import hashlib
from io import BytesIO
import json
from pathlib import Path
import statistics
import sys
import time

from pydub import AudioSegment

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.audio_tempo import fit_audio_tempo

DIRECTORY = Path(__file__).resolve().parent
OUTPUT = DIRECTORY / 'run/local-tempo-offline-v1'


def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    groups = []
    records = []
    for source_arm, target in [('fixed_safe8', 8), ('full_safe8', 12)]:
        rows = []
        for result_path in sorted((DIRECTORY / 'run/flat-full-adaptive-v2').glob(f'*/*/{source_arm}/result.json')):
            record = json.loads(result_path.read_text())
            event = record['events'][0]
            path = ROOT / event['path']
            source_bytes = path.read_bytes()
            source = AudioSegment.from_file(path)
            assert abs(len(source)/1000-event['audio_seconds']) < .001
            start = time.perf_counter()
            adjusted, tempo = fit_audio_tempo(source, target)
            encoded = BytesIO()
            adjusted.export(encoded, format='mp3')
            decoded = AudioSegment.from_file(BytesIO(encoded.getvalue()), format='mp3')
            processing = time.perf_counter()-start
            output = OUTPUT / f'{record["case"]}_{target}s.mp3'
            output.write_bytes(encoded.getvalue())
            output.with_suffix('.txt').write_text(event['text'])
            assert path.read_bytes() == source_bytes
            rows.append({'case': record['case'], 'source_arm': source_arm, 'target_seconds': target,
                'source_path': str(path.relative_to(ROOT)), 'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
                'output_path': str(output.relative_to(ROOT)), 'original_seconds': len(source)/1000,
                'adjusted_seconds': len(decoded)/1000, 'tempo': asdict(tempo),
                'processing_including_mp3_encode_decode_seconds': processing, 'text_unchanged': True})
        assert len(rows) == 8
        groups.append({'target_seconds': target, 'source_arm': source_arm, 'n': len(rows),
            'original_mean_seconds': statistics.mean(r['original_seconds'] for r in rows),
            'adjusted_mean_seconds': statistics.mean(r['adjusted_seconds'] for r in rows),
            'original_within_one_second': sum(abs(r['original_seconds']-target) <= 1 for r in rows),
            'adjusted_within_one_second': sum(abs(r['adjusted_seconds']-target) <= 1 for r in rows),
            'adjusted_min_seconds': min(r['adjusted_seconds'] for r in rows),
            'adjusted_max_seconds': max(r['adjusted_seconds'] for r in rows),
            'clamped': sum(r['tempo']['clamped'] for r in rows),
            'mean_processing_seconds': statistics.mean(r['processing_including_mp3_encode_decode_seconds'] for r in rows),
            'max_processing_seconds': max(r['processing_including_mp3_encode_decode_seconds'] for r in rows)})
        records.extend(rows)
    result = {'run_id': 'local-tempo-offline-v1', 'api_calls': 0, 'api_cost_usd': 0,
        'source_hashes': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [ROOT/'src/streaming/audio_tempo.py', ROOT/'src/streaming/config.py',
                                    ROOT/'src/tts_streaming.py', Path(__file__)]},
        'config': {'min_speed': .85, 'max_speed': 1.15, 'deadband_seconds': .1},
        'groups': groups, 'samples': records,
        'limitations': ['Reprocesses 16 saved first chunks; no new full-speech or first-audio latency test.',
                        '12s group uses saved longer ordinary first chunks; no new 12s draft generation.',
                        'Synthetic tone tests check pitch and the ending marker; no ASR or human listening assessment.',
                        'Clamped speed intentionally leaves residual duration error. Original audio and old experiment results are preserved.',
                        'Local timings include filtering, MP3 encode and decode on this host; no network or paid compute.']}
    (DIRECTORY / 'local-tempo-offline-v1_summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(groups, indent=2))


if __name__ == '__main__':
    main()
