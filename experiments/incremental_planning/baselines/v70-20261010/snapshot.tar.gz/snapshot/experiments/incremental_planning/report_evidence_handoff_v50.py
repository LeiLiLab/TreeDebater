import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.experiment_accounting import exposure_query

D = ROOT / 'experiments/incremental_planning'
RUN = 'listening-motion-live-v50-retrieval'
R = D / 'run' / RUN
RUNS = ['listening-motion-live-v48', 'listening-motion-live-v48-retrieval', 'listening-motion-live-v49-retrieval', RUN]

def read(p, default=None):
    return json.loads(p.read_text()) if p.exists() else default

m = read(D / f'manifest_{RUN}.json', {})
c = sqlite3.connect('file:' + str(D / 'run/cost.sqlite') + '?mode=ro', uri=True)
c.row_factory = sqlite3.Row
where = ' WHERE (' + ' OR '.join("instr(c.label,'" + r + "/')=1" for r in RUNS) + ')'
rows = [dict(r) for r in c.execute('SELECT * FROM calls c' + where)]
known = sum(r['estimated_usd'] or 0 for r in rows)
for r in rows:
    if r['state'] == 'pending' and r['estimated_usd'] is None:
        artifact = read(D / 'run' / f"call_{r['id']:06}.json", {})
        known += sum(x['estimated_usd'] for x in artifact.get('external_calls', []) if x['state'] == 'ok')
cost = dict(approved_usd=60, known_usage_estimate_usd=known,
    conservative_exposure_usd=c.execute(exposure_query(where)).fetchone()[0],
    unsettled_requests=[r for r in rows if r['state'] != 'ok'],
    invoice_status='Provisional rate-based estimate; unknown failures retain full reservations.')
turns = []
for p in sorted(R.glob('[0-9]*/result.json')):
    d = read(p)
    traces = list(p.parent.glob('*_chunks/listening_prefix.json'))
    t = read(traces[0], {}) if traces else {}
    played = read(p.parent / 'playback.json', [])
    events = read(p.parent / 'events.json', [])
    first = d.get('endpoint_to_first_audio_seconds') if d['index'] else d.get('generation_to_first_audio_seconds')
    if first is None and events:
        origin = d.get('previous_opponent_endpoint_monotonic') or d['generation_started_monotonic']
        first = events[0]['ready_monotonic'] - origin
    audio = d.get('audio_seconds')
    if audio is None and events:
        audio = sum(e['duration_seconds'] for e in events)
    error = abs(audio - d['target_seconds']) / d['target_seconds'] if audio else None
    gap = max((x['gap_seconds'] for x in played), default=None)
    gate = t.get('gate_ready_seconds')
    publication = events[0]['ready_monotonic'] - t['generation_started_monotonic'] if events and 'generation_started_monotonic' in t else None
    checks = dict(gate_before_first_audio=(gate <= publication if gate is not None and publication is not None else None),
        published_prefix_matches=(events[0]['text'] == t.get('fixed_prefix') if events else None),
        prepared_audio_matches=(t['prepared_audio']['text'] == t.get('fixed_prefix') if t.get('prepared_audio') else None),
        last_review_accepted=(t['endpoint_reviews'][-1].get('accepted') if t.get('endpoint_reviews') else None))
    turns.append(dict(turn=p.parent.name, status=d['status'], first_audio_seconds=first,
        audio_seconds=audio, target_seconds=d['target_seconds'], max_gap_seconds=gap,
        duration_error_ratio=error, timing_pass=all((first is not None and first <= 10,
            gap is not None and gap <= 2, error is not None and error <= .15)),
        error=d.get('error'), prefix=t.get('fixed_prefix'), cold_prefix=t.get('cold_prefix'),
        review_count=len(t.get('endpoint_reviews', [])), publication_checks=checks,
        full_asr_ready_monotonic=d.get('full_asr_ready_monotonic'),
        first_audio_monotonic=events[0]['ready_monotonic'] if events else None,
        body_task_source=t.get('body_task_binding', {}).get('source'),
        generation_to_first_audio_seconds=d.get('generation_to_first_audio_seconds'),
        listener_backlog_seconds=d.get('listener_backlog_seconds')))
for previous, current in zip(turns, turns[1:]):
    ready, published = previous['full_asr_ready_monotonic'], current['first_audio_monotonic']
    current['publication_checks']['complete_opponent_asr_before_audio'] = ready <= published if ready and published else None
preparation = {side: {k: v for k, v in read(R / f'preparation_{side}.json', {}).items()
    if k in ('use_retrieval', 'use_rehearsal_tree', 'evidence_pool_count', 'selected_evidence_count', 'selected_evidence_ids', 'selected_claims')} for side in ('for','against')}
calls = []
for r in rows:
    if not r['label'].startswith(RUN + '/'):
        continue
    a = read(D / 'run' / f"call_{r['id']:06}.json", {})
    req = a.get('request', {})
    calls.append(dict(id=r['id'], label=r['label'], state=r['state'], seconds=r['seconds'],
        estimated_usd=r['estimated_usd'], input_tokens=r['input_tokens'], model=req.get('model'),
        temperature=req.get('temperature'), max_tokens=req.get('max_tokens'),
        request_timeout_seconds=a.get('request_timeout_seconds'), error=a.get('error')))
report = dict(generated_utc=datetime.now(timezone.utc).isoformat(), run_id=RUN,
    status=m.get('status'), completed_turns=m.get('completed_turns'), motion=m.get('motion'),
    budget=cost, preparation=preparation, turns=turns, calls=calls,
    source_digest=m.get('source_digest'), stop_error=m.get('stop_error'),
    limitations=['One motion with six speeches; no paired ablation or independent quality grader.',
        'Saved evidence retrieval; no new web retrieval calls.', 'Server-paced audio; not browser timing.'])
baseline_run = 'listening-motion-live-v49-retrieval'
comparison = []
for turn in turns:
    name = turn['turn']
    old_root = D / 'run' / baseline_run / name
    old = read(old_root / 'result.json', {})
    old_play = read(old_root / 'playback.json', [])
    row = dict(turn=name)
    for label, folder in [('before', old_root), ('after', R / name)]:
        paths = list(folder.glob('*_chunks/listening_prefix.json'))
        trace = read(paths[0], {}) if paths else {}
        row[label] = {key: trace.get(key) for key in ('gate_ready_seconds', 'tail_work',
            'parallel_evidence_selection', 'parallel_body_revision', 'final_input_ready_seconds')}
        row[label]['chunks'] = [{k: x.get(k) for k in ('index', 'ready_seconds', 'audio_seconds')}
                                for x in trace.get('chunks', [])]
        row[label]['bibliography_in_audio'] = any('References' in x['text'] or '**Reference**' in x['text']
                                               for x in trace.get('chunks', []))
    row['before_first_audio_seconds'] = old.get('generation_to_first_audio_seconds') if name.startswith('00') else old.get('endpoint_to_first_audio_seconds')
    row['before_max_gap_seconds'] = max((x['gap_seconds'] for x in old_play), default=None)
    row['after_first_audio_seconds'] = turn['first_audio_seconds']
    row['after_max_gap_seconds'] = turn['max_gap_seconds']
    comparison.append(row)
report['comparison'] = comparison
report['offline_tests_passed'] = 269
report['offline_test_records'] = dict(full_suite='v50_final_offline.xml',
    resolved_signature_fixture_recheck='v50_speech_length_recheck.xml',
    note='The full run passed 268; one stale private-helper call in a test was updated, then all 18 speech-length tests passed. 269 unique tests pass across the final checks.')
report['offline_payload_preflight'] = read(D / 'v50_offline_preflight.json')
report['completion'] = read(R / 'completion-v1/manifest.json')
report['planning_index_audit'] = read(D / 'v50_closing_planning_replay.json')
report['validation_pass'] = False
report['remaining_findings'] = [
    dict(severity='high', issue='Against closing reversed stance and semantic prefix review falsely accepted it',
         evidence='completion-v1/05_closing_against/result.json', status='Unresolved semantic quality failure; generation success is not validation success.'),
    dict(severity='medium', issue='Cold opening and two warm turns still exceed the two-second gap criterion',
         cause='Native feedback, supplemental evidence selection, revision and TTS remain a sequential dependency chain.'),
    dict(severity='medium', issue='Closing planner selected target38 from an eight-target list',
         evidence='v50_closing_planning_replay.json', consequence='Local validation rejected the state; first preparatory event waited for a framework.'),
    dict(severity='medium', issue='Speculative body length uses listening_body_words rather than the upcoming native speech time budget',
         location='src/streaming/listening_prefix.py:115', status='Not changed in this experiment; can increase later length adjustment work.')]
report['post_live_corrections'] = [
    'Malformed JSON now uses the existing one-repair allowance before semantic review; validated with recorded failure and real closing replay.',
    'Completed feedback is published before evidence selection so obsolete selection cannot block final body audio; offline ordering regression passes.',
    'Speculative revision reuse checks writer sampling options as well as prompt and system; changed-temperature regression passes.']
report['limitations'].append('Several related fixes changed together; timing comparison is observational, not an isolated causal ablation.')
out = D / f'{RUN}_validation.json' 
out.write_text(json.dumps(report, ensure_ascii=False, indent=2))
print(json.dumps(dict(path=str(out), status=report['status'], completed_turns=report['completed_turns'], known_usd=known, conservative_exposure_usd=cost['conservative_exposure_usd'], turns=[{k:t[k] for k in ('turn','status','first_audio_seconds','max_gap_seconds','audio_seconds','timing_pass')} for t in turns]), ensure_ascii=False, indent=2))
