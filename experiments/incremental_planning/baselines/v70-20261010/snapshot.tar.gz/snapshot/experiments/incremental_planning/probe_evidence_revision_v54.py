"""Prepare/execute three isolated revision replays; no TTS, ASR or automatic retries."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

import benchmark_listening_motion_live as live
from utils.evidence_material import EvidenceSelection
from utils.prompts.speech_revision import revision_prompt
from streaming.experiment_client import BudgetedClient

RUN = 'listening-motion-live-v52-refactor-evidence-v54-revision-probe'
OUT = live.LEDGER / RUN
RECORD = live.D / 'prepared_evidence_revision_v54.json'
CASES = [(22936, [22921,22927,22931], 'opening', 'against'),
         (22963, [22946,22953,22957], 'rebuttal', 'for'),
         (22990, [22974,22980,22985], 'rebuttal', 'against')]


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def prepare():
    if RECORD.exists():
        raise ValueError('Prepared record already exists; do not overwrite approval or requests')
    cases=[]
    for ident, selections, stage, side in CASES:
        old=json.loads((live.LEDGER/f'call_{ident:06}.json').read_text())
        request=copy.deepcopy(old['request'])
        prompt=request['messages'][-1]['content']
        material=json.JSONDecoder().raw_decode(prompt.split('Revision material (data):\n',1)[1])[0]
        prefix=json.JSONDecoder().raw_decode(prompt.split('IMMUTABLE SPOKEN PREFIX (data):\n',1)[1])[0]
        n_words=int(re.search(r'roughly (\d+) words',prompt).group(1))
        analysis={}
        for source in selections:
            raw=json.loads((live.LEDGER/f'call_{source:06}.json').read_text())['response']['choices'][0]['message']['content']
            analysis.update(json.JSONDecoder().raw_decode(raw[raw.index('{'):])[0].get('analysis',{}))
        request['messages'][-1]['content']=revision_prompt(
            motion='Learning to be a good writer still matters in the age of AI',side=side,stage=stage,
            statement=material['statement'],feedback=material['feedback'],allocation_plan=material['allocation_plan'],
            evidence=EvidenceSelection(material['evidence'],analysis),prefix=prefix,n_words=n_words)
        reservation=4*(len(json.dumps(request,ensure_ascii=False).encode())+8192+request['max_tokens'])/1e6
        cases.append(dict(original_call_id=ident,stage=stage,side=side,request=request,
            request_sha256=digest(request),conservative_reservation_usd=reservation,
            original_output=old['response']['choices'][0]['message']['content']))
    record=dict(status='pending_approval',created_utc=datetime.now(timezone.utc).isoformat(),run_id=RUN,
        cases=cases,model=live.MODEL,temperature=.3,max_tokens=4096,
        expected_incremental_usd=[.005,.02],probe_cap_usd=1,cumulative_cap_usd=20,
        budget_group_prefix='listening-motion-live-v52-refactor',currency='USD',
        pricing=dict(input_per_million=.13,output_per_million=.4,source='https://aws.amazon.com/bedrock/pricing/'),
        assumptions='Three sequential text-only requests; same original draft, feedback, allocation, prefix, system and history. Only new revision instructions and evidence projection differ. Baseline outputs reused, no selection/TTS/ASR/judge calls, no new rented compute.',
        guard='Durable SQLite reservation before dispatch; USD1 probe and existing USD20 cumulative, USD370 global, USD280 study and USD60 combined guards. Retain unknown charges; no retries/restarts.',
        source_digest=live.code_digest())
    RECORD.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k!='cases'},indent=2))
    print('request_reservations', [c['conservative_reservation_usd'] for c in cases])


def execute():
    record=json.loads(RECORD.read_text())
    if record['status']!='approved' or not record.get('authorization'):
        raise ValueError('Recorded approval is required')
    if record['probe_cap_usd']!=1 or record['cumulative_cap_usd']!=20:
        raise ValueError('Unexpected budget configuration')
    if len(record['cases'])!=3 or any(digest(c['request'])!=c['request_sha256'] for c in record['cases']):
        raise ValueError('Prepared requests changed')
    OUT.mkdir(exist_ok=False)
    client=BudgetedClient(live.LEDGER,cap=live.CAP,label=RUN)
    try:
        live.arm_study_guard(client.db, RUN+'/',1)
        live.arm_study_guard(client.db,record['budget_group_prefix'],20)
        live.arm_study_guard(client.db)
        live.VALIDATION_RUNS=tuple(dict.fromkeys((*live.VALIDATION_RUNS,
            'listening-motion-live-v52-refactor','listening-motion-live-v52-refactor-recovery1',
            'listening-motion-live-v52-refactor-evidence-v53',RUN)))
        exposure=live.exposure_query(' WHERE '+live.combined_filter('c.label'))
        client.db.execute(f"CREATE TRIGGER validation_v54_revision BEFORE INSERT ON calls WHEN {live.combined_filter('NEW.label')} AND NEW.reserved + ({exposure}) > 60.0 BEGIN SELECT RAISE(ABORT,'Combined validation cap exceeded'); END")
        client.db.commit()
        results=[]
        for case in record['cases']:
            client.label=RUN+'/'+str(case['original_call_id'])
            req=case['request']
            new=client.complete(req['messages'],model=req['model'],temperature=req['temperature'],max_tokens=req['max_tokens'])
            results.append(dict(original_call_id=case['original_call_id'],stage=case['stage'],side=case['side'],old=case['original_output'],new=new))
            (OUT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps(dict(completed=case['original_call_id'],new_words=len(new.split()))),flush=True)
        record['status']='completed'
    except BaseException as exc:
        record.update(status='stopped',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        (OUT/'manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
        client.db.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    if parser.parse_args().execute:
        execute()
    else:
        prepare()
