"""User-authorized continuation of the v54 text-only probe under its SAME USD1 cap."""
import argparse
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import re

import probe_evidence_revision_v54 as probe
from streaming.experiment_client import BudgetedClient

OUT = probe.OUT / 'iteration_v55'
RECORD = probe.live.D / 'prepared_evidence_iteration_v55.json'
TASK = '''Write the unpublished body of our debate speech again, using the supplied evidence as part of the reasoning. This is substantive argument writing, not a minimal wording edit.
Keep our assigned position and the actual debate history. Only the already spoken prefix is immutable. Do not output that prefix or any introduction; continue directly into the body.
For factual claims supported by relevant material, state what that material actually found or argues, name its source aloud using the supplied title/source metadata, and explain its relevance to the specific reasoning step. Preserve the material's qualifications. A finding need not prove the whole motion. Do not invent empirical results, dates or credentials. Selection reasons are fallible writing hints, never evidence themselves.
Feedback identifies problems to solve. Its suggested sentences are optional and must not replace available concrete support with vague references to theory or another analogy. Do not merely copy the old body and insert the feedback's proposed wording. If a source is irrelevant or too weak for a claim, do not force it into the argument.
Use the remaining word budget to replace repetition and unsupported generalities with relevant sourced reasoning. Return only natural spoken body text, no headings, bibliography, explanation or separate plan.
'''


def unpack(case):
    request = copy.deepcopy(case['request'])
    prompt = request['messages'][-1]['content']
    material = json.JSONDecoder().raw_decode(prompt.split('Revision material (data):\n',1)[1])[0]
    prefix = json.JSONDecoder().raw_decode(prompt.split('IMMUTABLE SPOKEN PREFIX (data):\n',1)[1])[0]
    words = int(re.search(r'roughly (\d+) words',prompt).group(1))
    return request, material, prefix, words


def prepare():
    if RECORD.exists():
        raise ValueError('Do not overwrite existing experiment preparation')
    original = json.loads(probe.RECORD.read_text())
    assert original['status']=='approved' and original['probe_cap_usd']==1 and original['cumulative_cap_usd']==20
    cases=[]
    for variant in ('A_final_instruction','B_evidence_rewrite','C_outline_rebuild'):
        for case in original['cases']:
            req, material, prefix, words = unpack(case)
            context=dict(motion='Learning to be a good writer still matters in the age of AI',side=case['side'],
                         stage=case['stage'],remaining_word_target=words,already_spoken_prefix=prefix)
            if variant=='A_final_instruction':
                req['messages'][-1]['content'] += '\nFINAL WRITING TASK:\n'+TASK
            elif variant=='B_evidence_rewrite':
                req['messages'][-1]['content'] = TASK+'\nContext and material (data):\n'+json.dumps(
                    dict(context,unpublished_draft=material['statement'],feedback=material['feedback'],
                         allocation_plan=material['allocation_plan'],evidence=material['evidence']),ensure_ascii=False)
            else:
                outline=[re.split(r'(?<=[.!?])\s+',p.strip(),maxsplit=1)[0]
                         for p in re.split(r'\n\s*\n',material['statement']) if p.strip()]
                evidence=copy.deepcopy(material['evidence'])
                for e in evidence:
                    if e.get('supports'):
                        e['supports']=re.split(r'(?<=[.!?])\s+',e['supports'],maxsplit=1)[0]
                req['messages'][-1]['content']=TASK+'\nReconstruct our case from the outline and sources rather than reproduce earlier prose. The outline is revisable; distinguish descriptions of the opponent from our own position.\nContext and material (data):\n'+json.dumps(
                    dict(context,draft_outline=outline,feedback=material['feedback'],
                         allocation_plan=material['allocation_plan'],evidence=evidence),ensure_ascii=False)
            cases.append(dict(variant=variant,original_call_id=case['original_call_id'],stage=case['stage'],
                side=case['side'],request=req,request_sha256=probe.digest(req)))
    record=dict(status='approved',created_utc=datetime.now(timezone.utc).isoformat(),
        authorization='User: 你自己按照这个方式迭代试一试，看哪个结果好。 Continue the already approved v54 text-only probe autonomously, without increasing its USD1 cumulative subcap or USD20 parent cap.',
        parent_approval=str(probe.RECORD),shared_probe_prefix=probe.RUN+'/',probe_cap_usd=1,cumulative_cap_usd=20,
        expected_new_usd=[.015,.08],max_requests=12,automatic_retries=False,
        phases='Nine prepared requests (three variants × three cases), then at most three repeated requests using one chosen variant.',
        rates_per_million=dict(input=.13,output=.4),price_source='https://aws.amazon.com/bedrock/pricing/',
        limitations='Single motion, fixed historical drafts; initial variants change instruction/format together, not independent causal ablations. Repeated winner used to check sampling variability. No TTS, ASR, paid judge or new retrieval.',cases=cases)
    RECORD.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status=record['status'],prepared_requests=len(cases),max_requests=12,shared_probe_cap_usd=1),indent=2))


def execute(variant,repeat=False):
    record=json.loads(RECORD.read_text())
    if record['status']!='approved': raise ValueError('Approval missing')
    cases=[c for c in record['cases'] if c['variant']==variant]
    if len(cases)!=3: raise ValueError('Unknown variant')
    if any(probe.digest(c['request'])!=c['request_sha256'] for c in cases): raise ValueError('Request changed')
    OUT.mkdir(exist_ok=True)
    if repeat:
        prior=list(OUT.glob('repeat_*.json'))
        if prior: raise ValueError('Only one winner repeat is allowed')
        if len(list(OUT.glob('initial_*.json')))!=3: raise ValueError('Finish initial comparison before repeat')
    name=('repeat_' if repeat else 'initial_')+variant
    path=OUT/(name+'.json')
    if path.exists(): raise ValueError('No automatic retries or overwrites')
    result=dict(status='running',variant=variant,repeat=repeat,results=[])
    path.write_text(json.dumps(result,indent=2))
    client=BudgetedClient(probe.live.LEDGER,cap=probe.live.CAP,label=probe.RUN+'/iteration_v55/'+name)
    try:
        # Existing v54 guards already cover this label, including all earlier
        # usage and errors. Check their presence before any network dispatch.
        for prefix,cap in [(probe.RUN+'/',1),('listening-motion-live-v52-refactor',20), (probe.live.STUDY,probe.live.STUDY_CAP)]:
            probe.live.arm_study_guard(client.db,prefix,cap)
        if not client.db.execute("select 1 from sqlite_master where type='trigger' and name='validation_v54_revision'").fetchone():
            raise ValueError('Existing combined validation guard missing')
        for c in cases:
            client.label=probe.RUN+'/iteration_v55/'+name+'/'+str(c['original_call_id'])
            req=c['request']
            text=client.complete(req['messages'],model=req['model'],temperature=req['temperature'],max_tokens=req['max_tokens'])
            result['results'].append(dict(original_call_id=c['original_call_id'],stage=c['stage'],side=c['side'],text=text))
            path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps(dict(variant=variant,repeat=repeat,completed=c['original_call_id'],words=len(text.split()))),flush=True)
        result['status']='completed'
    except BaseException as exc:
        result.update(status='stopped',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        client.db.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant',choices=['A_final_instruction','B_evidence_rewrite','C_outline_rebuild'])
    parser.add_argument('--repeat',action='store_true')
    args=parser.parse_args()
    if args.variant: execute(args.variant,args.repeat)
    else: prepare()
