"""Offline audit of v67 saved initial reviews and audio handoffs."""
import hashlib
import json
from pathlib import Path
import sqlite3

D = Path('experiments/incremental_planning')
RUN = 'listening-motion-live-v52-refactor-streamed-motion02-v67'
O = D / 'run' / RUN

def main():
    db = sqlite3.connect(f'file:{D}/run/cost.sqlite?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    reviews = []
    for row in db.execute('select id,label,state,seconds from calls where instr(label,?)=1', (RUN,)):
        artifact = json.loads((D / f'run/call_{row["id"]:06d}.json').read_text())
        messages = artifact['request'].get('messages', [])
        prompts = [m.get('content', '') for m in messages]
        review = next((s for s in prompts if isinstance(s, str) and s.startswith('LISTENING PREFIX REVIEW:')), None)
        if review:
            payload = json.loads(review.splitlines()[-1])
            reviews.append(dict(row) | {'side': payload['context']['our_side'], 'stage': payload['context']['stage']})
    rows, handoffs = [], []
    previous = None
    for folder in sorted(O.glob('[0-9]*')):
        if not (folder / 'result.json').exists():
            continue
        result = json.loads((folder / 'result.json').read_text())
        events = json.loads((folder / 'events.json').read_text())
        trace = json.loads(next(folder.glob('*_chunks/listening_prefix.json')).read_text())
        review = trace.get('initial_prefix_review', {})
        verdict = review.get('verdict') or {}
        requests = [r for r in reviews if r['stage'] == result['stage'] and r['side'] == result['side']]
        rows.append(dict(turn=folder.name, status=result['status'], initial_review_attempted=review.get('attempted'),
            initial_review_completed=review.get('completed'), initial_accepted=verdict.get('accepted'),
            format_attempts=len(verdict.get('format_attempts', [])), review_requests=requests,
            checked_text=review.get('checked_text'), published_text=events[0]['text'],
            checked_text_matches_published=review.get('checked_text') == events[0]['text'],
            semantic_rewrites=trace.get('semantic_rewrites'), prefix_input_scope=trace.get('prefix_input_scope')))
        if previous and events:
            endpoint = result['previous_opponent_endpoint_monotonic']
            full_asr = previous.get('full_asr_ready_monotonic')
            audio = events[0]['ready_monotonic']
            handoffs.append(dict(turn=folder.name, endpoint_to_first_audio_seconds=audio-endpoint,
                endpoint_to_full_asr_seconds=full_asr-endpoint if full_asr else None,
                first_audio_before_full_asr=audio < full_asr if full_asr else None,
                first_audio_minus_full_asr_seconds=audio-full_asr if full_asr else None))
        previous = result
    hashes = json.loads((O / 'source_snapshot/files.json').read_text())
    changed = [path for path, digest in hashes.items() if not Path(path).exists() or hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest]
    initial = dict(turns=rows, review_request_count=len(reviews),
        exactly_one_review_per_turn=len(rows)==6 and all(len(r['review_requests'])==1 for r in rows),
        all_initial_reviews_completed=all(r['initial_review_completed'] for r in rows), source_changed=changed)
    (O / 'initial_review_audit.json').write_text(json.dumps(initial, ensure_ascii=False, indent=2)+'\n')
    (O / 'handoff_latency_audit.json').write_text(json.dumps(dict(handoffs=handoffs), indent=2)+'\n')
    print(json.dumps(dict(review_count=len(reviews), turns=len(rows), changed_sources=changed, handoffs=handoffs), indent=2))

if __name__ == '__main__':
    main()
