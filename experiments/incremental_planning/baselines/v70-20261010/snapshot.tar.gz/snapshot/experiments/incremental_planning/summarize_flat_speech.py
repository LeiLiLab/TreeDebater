"""Read-only, failure-inclusive summary of the frozen real speech experiment."""
import argparse
import json
import random
import statistics
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.experiment_client import BudgetedClient
from streaming.experiment_accounting import exposure_query

DIRECTORY = ROOT / 'experiments/incremental_planning'
RUN = 'flat-speech-real-v1'


def stats(values):
    values = sorted(v for v in values if v is not None)
    def quantile(q):
        pos = (len(values)-1)*q
        lo = int(pos)
        hi = min(lo+1, len(values)-1)
        return values[lo] + (values[hi]-values[lo])*(pos-lo)
    return {'n': len(values), 'mean': statistics.mean(values) if values else None,
            'median': statistics.median(values) if values else None,
            'p90': quantile(.9) if values else None,
            'min': min(values) if values else None, 'max': max(values) if values else None}


def boot(values):
    if not values:
        return {'n_cases': 0, 'mean': None, 'ci95': None}
    rng = random.Random(20261004)
    draws = sorted(statistics.mean(rng.choices(values, k=len(values))) for _ in range(10000))
    return {'n_cases': len(values), 'mean': statistics.mean(values),
            'ci95': [draws[249], draws[9749]], 'note': 'Unadjusted case bootstrap; small authored sample.'}


def main():
    global RUN
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', choices=('flat-speech-real-v1', 'flat-speech-real-v2'), default=RUN)
    RUN = parser.parse_args().run_id
    version = RUN.rsplit('-', 1)[-1]
    manifest = json.loads((DIRECTORY / f'manifest_flat_speech_{version}.json').read_text())
    records = []
    for path in sorted((DIRECTORY / 'run' / RUN).glob('*/*/*/result.json')):
        row = json.loads(path.read_text())
        judge_path = path.with_name('judgment.json')
        if judge_path.exists():
            row['judge'] = json.loads(judge_path.read_text())
        row['path'] = str(path.relative_to(ROOT))
        records.append(row)
    by_arm = {}
    for arm in manifest['arms']:
        rows = [r for r in records if r['arm'] == arm]
        emitted = [r for r in rows if r['chunks'] > 0]
        judged = [r for r in rows if 'judge' in r]
        passes = sum(sum(c['passed'] for c in r['judge']['checks']) for r in judged)
        checks = sum(len(r['judge']['checks']) for r in judged)
        errors = {}
        for r in rows:
            if r['error']:
                key = r['error']['type']+': '+r['error']['message']
                errors[key] = errors.get(key, 0)+1
        by_arm[arm] = {
            'attempts_recorded': len(rows),
            'attempts_planned': len(manifest['case_ids'])*manifest['repeats'],
            'audible_turns': len(emitted), 'returned_without_error': sum(r['status']=='returned' for r in rows),
            'silent_failures': sum(r['status']=='failed_silent' for r in rows),
            'partial_failures': sum(r['status']=='failed_partial' for r in rows),
            'first_playable_audio_seconds_conditional_on_output': stats(r['generation_to_first_audio_seconds'] for r in rows),
            'estimated_endpoint_to_first_audio_seconds_conditional_on_output':
                stats(r['estimated_endpoint_to_first_audio_seconds'] for r in rows),
            'worker_return_seconds_all_attempts': stats(r['worker_return_seconds'] for r in rows),
            'audio_seconds_all_attempts': stats(r['audio_seconds'] for r in rows),
            'words_all_attempts': stats(r['answer_words'] for r in rows),
            'chunks_all_attempts': stats(r['chunks'] for r in rows),
            'first_chunk_audio_seconds_conditional_on_output': stats(r['events'][0]['audio_seconds'] for r in emitted),
            'first_chunk_words_conditional_on_output': stats(len(r['events'][0]['text'].split()) for r in emitted),
            'estimated_gap_seconds_audible_turns': stats(r['estimated_total_gap_seconds'] for r in emitted),
            'first_audio_by_seconds_all_attempts': {str(t): sum(
                r['generation_to_first_audio_seconds'] is not None and r['generation_to_first_audio_seconds'] <= t
                for r in rows) for t in (5, 10, 15, 20, 30, 60)},
            'judged_turns': len(judged), 'missing_judgments_on_emitted': len(emitted)-len(judged),
            'condition_checks_passed': passes, 'condition_checks_total_judged': checks,
            'coverage_percent_conditional_on_judged_output': 100*passes/checks if checks else None,
            'delivered_check_coverage_percent_all_attempts':
                100*passes/(3*len(rows)) if rows and len(judged)==len(emitted) else None,
            'coverage_note': 'Operational delivered coverage treats silent turns as zero delivered checks, '
                             'not as a fabricated judge verdict. Missing judgments are not imputed.',
            'strength_conditional_on_judged_output': stats(r['judge']['rebuttal_strength'] for r in judged),
            'strawman_flag_count': sum(r['judge']['strawman'] for r in judged),
            'unsupported_flag_count': sum(r['judge']['unsupported_facts'] for r in judged),
            'generation_usage_usd': sum(r['generation_usage']['reported_usage_estimate_usd'] for r in rows),
            'audio_usage_usd': sum(r['audio_usage']['reported_usage_estimate_usd'] for r in rows),
            'audio_http_calls': sum(len(r['audio_calls']) for r in rows), 'errors': errors}
    lookup = {(r['case'], r['repeat'], r['arm']): r for r in records}
    paired = {}
    for metric in ['first_audio', 'judged_coverage', 'delivered_coverage', 'audio_availability']:
        differences, included = [], []
        for case in manifest['case_ids']:
            values = []
            for repeat in range(manifest['repeats']):
                a, b = (lookup.get((case, repeat, arm)) for arm in ['incremental', 'full_script'])
                if not a or not b:
                    break
                if metric == 'first_audio':
                    x, y = a['generation_to_first_audio_seconds'], b['generation_to_first_audio_seconds']
                    if x is None or y is None:
                        break
                elif metric in ('judged_coverage', 'delivered_coverage'):
                    if any('judge' not in r and (r['chunks'] or metric == 'judged_coverage') for r in (a, b)):
                        break
                    x, y = [100*sum(c['passed'] for c in r['judge']['checks'])/3 if 'judge' in r else 0 for r in (a, b)]
                else:
                    x, y = int(a['chunks'] > 0), int(b['chunks'] > 0)
                values.append(x-y)
            if len(values) == manifest['repeats']:
                differences.append(statistics.mean(values))
                included.append(case)
        paired[metric] = dict(boot(differences), cases=included, direction='incremental minus full_script')
    client = BudgetedClient(DIRECTORY / 'run')
    run_cost = client.db.execute('SELECT count(*),coalesce(sum(estimated_usd),0) FROM calls WHERE instr(label,?)=1',
                                 (RUN+'/',)).fetchone()
    exposure = client.db.execute(exposure_query(' WHERE instr(c.label,?)=1'), (RUN+'/',)).fetchone()[0]
    categories = {}
    for label, cost in client.db.execute('SELECT label,estimated_usd FROM calls WHERE instr(label,?)=1', (RUN+'/',)):
        stage = label.rsplit('/', 1)[-1]
        categories[stage] = categories.get(stage, 0) + (cost or 0)
    for arm, data in by_arm.items():
        data['cost_including_half_shared_preparation_usd'] = (
            data['generation_usage_usd'] + data['audio_usage_usd'] + categories.get('preparation', 0)/2)
    summary = {'run_id': RUN, 'status': manifest['status'], 'completed_turns': len(records),
               'arms': by_arm, 'case_paired': paired,
               'cost': {'ledger_entries': run_cost[0], 'known_usage_estimate_usd': run_cost[1],
                        'accounted_exposure_usd': exposure, 'categories_usd': categories,
                        'global': client.summary(),
                        'run_exposure_limit': manifest['estimate_usd']['run_exposure_stop'], 'cumulative_cap': 200,
                        'note': 'Provisional usage estimates, not invoices; audio bundles retain full reservation.'},
               'per_turn': [dict({k: r[k] for k in ('case', 'repeat', 'arm', 'status', 'chunks', 'audio_seconds',
                           'answer_words', 'generation_to_first_audio_seconds', 'error', 'path')},
                           judge=r.get('judge')) for r in records],
               'limitations': manifest['limitations']}
    path = DIRECTORY / (RUN+'_summary.json')
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k != 'per_turn'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
