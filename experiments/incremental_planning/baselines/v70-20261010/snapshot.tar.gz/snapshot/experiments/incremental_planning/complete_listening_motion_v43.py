"""Finish v43 text/audio from four saved speeches; no ASR/playback benchmark.

Preparation is offline. Only --execute dispatches paid requests, once, under
the approved shared ledger and an additional USD5 durable continuation guard.
"""
import argparse
import copy
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import sqlite3
import sys

import benchmark_listening_motion_live as live
from streaming.experiment_accounting import reconcile_success, exposure_query
from streaming.listening_prefix import material, speak_with_listening_prefix

D, ROOT = live.D, live.ROOT
SOURCE = D / 'run/listening-motion-live-v43'
RUN = 'listening-motion-live-v43-completion-v1'
OUT = D / 'run' / RUN
LOCAL_CAP = 5.


def configure():
    live.RUN, live.OUT = RUN, OUT
    assert live.CAP == 320 and live.STUDY_CAP == 230


def original_audio(index, speech):
    if index == 3:
        return SOURCE / 'generated_rebuttal_against_complete.mp3'
    return SOURCE / f"{index:02}_{speech['stage']}_{speech['side']}" / f"default_{speech['stage']}_{speech['side']}.mp3"


def build_manifest():
    configure()
    history = json.loads((SOURCE / 'generated_speeches.json').read_text())
    assert [(h['stage'], h['side']) for h in history] == [(s, side) for s, side, _ in live.TURNS[:4]]
    sources = {str(SOURCE / 'generated_speeches.json'): live.digest(SOURCE / 'generated_speeches.json')}
    for i, speech in enumerate(history):
        audio = original_audio(i, speech)
        sources[str(audio)] = live.digest(audio)
    prior = json.loads((D / 'manifest_listening-motion-live-v43.json').read_text())
    for path, digest in prior['input_sources'].items():
        assert live.digest(ROOT / path) == digest
        sources[str(ROOT / path)] = digest
    budget = live.ledger_summary()
    assert budget['pending_calls'] == 0
    return dict(status='approved', run=RUN, source_run=SOURCE.name, motion=prior['motion'],
        approval='增加20刀预算', created_utc=datetime.now(timezone.utc).isoformat(),
        scope='Reuse four full generated speeches and audio; generate FOR then AGAINST closing, 120 seconds each. Complete artifacts only; original live ASR benchmark remains interrupted.',
        restoration='Seed each fresh debater conversation with all preceding full generated speeches. Seed latest opponent text in planner chunks; leave derived planner/tree state empty. No recovered live state or new planner run is claimed.',
        pipeline='Current native listening-prefix authoring, compact Audience feedback, at most one body revision, serial advisory final body review, bounded adaptive TTS. No new ASR, judge, retrieval, or pool generation.',
        global_cap_usd=320, study_cap_usd=230, continuation_cap_usd=LOCAL_CAP,
        expected_additional_usd=[.2,.8], starting_ledger=budget,
        guard='SQLite pre-dispatch reservations and study/local triggers. Text uses conservative 4x reservation; TTS has USD1 per speech, at most128 requests, with4x per-request bounds. No automatic run retry.',
        pricing=dict(verified_utc=datetime.now(timezone.utc).isoformat(),
            gemma_input_usd_per_million=.13, gemma_output_usd_per_million=.40,
            tts_usd_per_million_characters=15,
            sources=['https://aws.amazon.com/bedrock/pricing/', 'https://developers.openai.com/api/docs/models/tts-1']),
        source_digest=live.code_digest(), harness_sha256=live.digest(__file__),
        live_harness_sha256=live.digest(live.__file__), audio_guard_sha256=live.digest(D/'audio_probe.py'),
        sources=sources, output_config=asdict(live.CONFIG), writer_temperature=.3,
        review_temperature=0, native_audience_temperature=1)


def seed_player(side, history, motion, meter):
    player = live.new_player(side, motion, meter)
    player.status = 'closing'
    # No streaming listener or synthesized tree state is restored. Full prior
    # generated speeches are authoritative, including v43's unplayed remainder.
    for speech in history:
        if speech['side'] == side:
            player._add_message('assistant', speech['content'])
        else:
            player._add_message('user', f"**Opponent's {speech['stage'].title()} Statement**\n" + speech['content'])
    player.planner.turn = f"{history[-1]['side']}:{history[-1]['stage']}"
    player.planner.chunks = [history[-1]['content']]
    player.use_debate_flow_tree = False
    return player


def execute():
    configure()
    manifest = json.loads((OUT / 'manifest.json').read_text())
    assert manifest['status'] == 'approved'
    assert manifest['harness_sha256'] == live.digest(__file__)
    assert manifest['source_digest'] == live.code_digest()
    assert manifest['live_harness_sha256'] == live.digest(live.__file__)
    assert manifest['audio_guard_sha256'] == live.digest(D/'audio_probe.py')
    for path, digest in manifest['sources'].items():
        assert live.digest(path) == digest
    for key, value in json.loads((ROOT/'src/configs/api_key.json').read_text()).items():
        os.environ.setdefault(key, value)
    os.environ['DEBATE_LLM_API_BASE'] = 'http://127.0.0.1:4000/v1'
    os.environ['DEBATE_LOG_PROMPTS'] = '0'
    import httpx
    import openai
    import litellm
    import tts_streaming
    from pydub import AudioSegment
    from debate_tree import Tree
    from utils.tool import logger
    logger.setLevel(logging.WARNING)
    def blocked(*args, **kwargs):
        raise RuntimeError('Unmetered request blocked')
    litellm.completion = blocked
    Tree.get_most_similar_node = lambda *args, **kwargs: (None, 0.)
    client = live.BudgetedClient(live.LEDGER, cap=320)
    live.arm_study_guard(client.db)
    manifest['continuation_trigger'] = live.arm_study_guard(client.db, RUN+'/', LOCAL_CAP)
    client.db.close()
    manifest.update(status='running', launched_utc=datetime.now(timezone.utc).isoformat())
    live.atomic_json(OUT/'manifest.json', manifest)
    meter = live.Meter()
    tts_streaming._text_request = live.metered_tts_text_request(meter)
    history = json.loads((SOURCE/'generated_speeches.json').read_text())
    results = [dict(h, audio=str(original_audio(i,h)), reused=True) for i,h in enumerate(history)]
    try:
        for index, side in ((4,'for'), (5,'against')):
            player = seed_player(side, history, manifest['motion'], meter)
            folder = OUT/f'{index:02}_closing_{side}'
            folder.mkdir(exist_ok=False)
            player.audio_output_dir = str(folder)
            live.atomic_json(folder/'input.json', material(player, 'closing', history))
            guard = live.AudioGuard(live.LEDGER, RUN+f'/turn_{index}/tts', allowance=1., approved_cap=320, max_requests=128)
            clients = []
            def factory(**kwargs):
                c = openai.OpenAI(http_client=httpx.Client(transport=guard, timeout=60), max_retries=0,
                                  base_url='https://api.openai.com/v1', timeout=60)
                clients.append(c)
                return c
            tts_streaming.OpenAI = factory
            player.tts_chunk_callback = lambda i,path,text,duration: print(json.dumps(
                dict(event='audio_ready',turn=index,chunk=i,audio_seconds=duration)), flush=True)
            print(json.dumps(dict(event='turn_start',turn=index,side=side)), flush=True)
            try:
                text = speak_with_listening_prefix(player, 120, copy.deepcopy(history), player.streaming_output_config, {}, stage='closing')
            finally:
                guard.finish()
                reconcile_success(guard.db, guard.request_id, guard.path)
                for c in clients:
                    c.close()
                guard.db.close()
            speech = dict(stage='closing',side=side,content=text,pipeline_status='completed')
            history.append(speech)
            audio = Path(player._speech_audio_file(stage='closing'))
            result = dict(speech,audio=str(audio),reused=False,audio_seconds=len(AudioSegment.from_file(audio))/1000)
            results.append(result)
            live.atomic_json(folder/'result.json', result)
            live.atomic_json(OUT/'speeches.json', results)
            print(json.dumps(dict(event='turn_complete',turn=index,audio_seconds=result['audio_seconds'])), flush=True)
        combined = AudioSegment.silent(duration=0)
        for result in results:
            audio = AudioSegment.from_file(result['audio'])
            result['audio_seconds'] = len(audio)/1000
            result['start_seconds'] = len(combined)/1000
            result['audio_sha256'] = live.digest(result['audio'])
            combined += audio
        combined.export(OUT/'complete_motion.mp3',format='mp3')
        live.atomic_json(OUT/'speeches.json', results)
        (OUT/'conversation.txt').write_text(manifest['motion']+'\n\n'+
            '\n\n'.join(f"{i+1}. {r['side'].upper()} {r['stage'].upper()}\n\n{r['content']}" for i,r in enumerate(results))+'\n')
        manifest.update(status='completed', total_audio_seconds=len(combined)/1000, speeches=len(results))
    except BaseException as exc:
        manifest.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        manifest.update(ending_ledger=live.ledger_summary(), finished_utc=datetime.now(timezone.utc).isoformat())
        live.atomic_json(OUT/'manifest.json', manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    args = parser.parse_args()
    if args.execute:
        execute()
    else:
        plan = build_manifest()
        OUT.mkdir(exist_ok=False)
        live.atomic_json(OUT/'manifest.json',plan)
        print(json.dumps({k:plan[k] for k in ('status','expected_additional_usd','continuation_cap_usd','global_cap_usd','scope')},indent=2))
