"""One additional motion using the current production streaming revision path."""
import argparse
from dataclasses import asdict
import json
import hashlib
import re
from pathlib import Path
import sqlite3
import sys

import benchmark_listening_motion_live as live
import compare_revision_pipelines_v56 as accounting

live.RUN = accounting.PARENT + '-streamed-motion02-v63'
live.OUT = live.LEDGER / live.RUN
live.MANIFEST = live.D / ('manifest_' + live.RUN + '.json')
live.MOTION_NUMBER = 2
live.RUN_CAP = 8.
live.CONFIG.first_chunk_seconds = 18.
live.CONFIG.first_body_chunk_seconds = 26.
live.CONFIG.listening_prefix_min_words = 42
live.CONFIG.min_chunk_words = 30
live.VALIDATION_RUNS = tuple(dict.fromkeys((*live.VALIDATION_RUNS, live.RUN)))
RECORD = live.D / 'prepared_streamed_motion_v63.json'
original_player = live.new_player
original_combined_guard = live.arm_combined_guard


def arm(db):
    accounting.arm(db, accounting.PARENT, 50.)
    # Both attempts belong to the same USD8 combination test budget.
    prefixes = [accounting.PARENT + '-streamed-motion02-v62/', live.RUN + '/']
    def group(column):
        return '(' + ' OR '.join(f"instr({column},'{prefix}')=1" for prefix in prefixes) + ')'
    combined = live.exposure_query(' WHERE ' + group('c.label'))
    sql = ("CREATE TRIGGER combination_v62_v63 BEFORE INSERT ON calls "
        f"WHEN {group('NEW.label')} AND NEW.reserved + ({combined}) > 8.0 "
        "BEGIN SELECT RAISE(ABORT, 'Combination test USD8 exceeded; no dispatch'); END")
    old = db.execute("select sql from sqlite_master where type='trigger' and name='combination_v62_v63'").fetchone()
    if old and old[0] != sql:
        raise ValueError('Existing combination stop differs')
    if not old:
        db.execute(sql); db.commit()
    name = 'validation_v63_' + hashlib.sha256(live.RUN.encode()).hexdigest()[:12]
    exposure = live.exposure_query(' WHERE ' + live.combined_filter('c.label'))
    sql = (f'CREATE TRIGGER {name} BEFORE INSERT ON calls '
        f'WHEN {live.combined_filter("NEW.label")} AND NEW.reserved + ({exposure}) > {live.COMBINED_CAP!r} '
        "BEGIN SELECT RAISE(ABORT, 'Combined validation budget exceeded; no dispatch'); END")
    old = db.execute("select sql from sqlite_master where type='trigger' and name=?", (name,)).fetchone()
    if old and old[0] != sql:
        raise ValueError('Existing combined guard differs')
    if not old:
        db.execute(sql); db.commit()
    return name


def new_player(side, motion, meter, players=None):
    player = original_player(side, motion, meter, players)
    original_helper = player.helper_client

    def helper(prompt, sys=None, response_model=None, max_tokens=4096,
               json_mode=None, history_messages=None, **kwargs):
        on_text = kwargs.get('on_text')
        writing = on_text is not None or any(tag in prompt for tag in (
            'LISTENING PREFIX DRAFT', 'LISTENING PREFIX REPAIR', 'LISTENING BODY DRAFT'))
        if writing:
            if 'LISTENING PREFIX' in prompt:
                prompt = re.sub(r'The first paragraph should be about \d+ words, maximum \d+;',
                    'The first paragraph must contain 42–46 English words, aiming for 44;', prompt)
                opening_rule = ('The text field must contain 42–46 English words, aiming for 44, '
                    'developing one substantive point in complete sentences. Do not use filler. ')
            else:
                opening_rule = ''
            rule = ('\nDELIVERY LENGTH FOR THIS EXPERIMENT: ' + opening_rule +
                'The FIRST paragraph of the remaining BODY (the draft field for a whole speech) '
                'must contain 50–70 English words, aiming for 60. End it with a blank line so it '
                'can be synthesized immediately. This first-body exception overrides the general '
                '80–120-word paragraph preference. Keep one complete reasoning step together; '
                'do not split a finding from its necessary qualification. Later paragraphs keep '
                'their normal length. Use the existing total speech word budget; these targets '
                'redistribute words and do not add time. Preserve the stage rules, including '
                'no new evidence in closing.\n')
            head, separator, data = prompt.rpartition('\n')
            prompt = head + rule + data if separator else rule + prompt
        if on_text is None:
            return original_helper(prompt, sys=sys, response_model=response_model,
                max_tokens=max_tokens, json_mode=json_mode,
                history_messages=history_messages, **kwargs)
        if response_model is not None or json_mode or kwargs.get('model', live.MODEL) != live.MODEL:
            raise ValueError('Streamed revision must be plain text on the approved model')
        if meter.stopped.is_set():
            raise live.BudgetExceeded('Stopped before streamed revision')
        from utils.model import helper_messages
        label = live.RUN + f'/{side}/{player.status}/whole_revision_stream'
        client = live.BudgetedClient(live.LEDGER, cap=live.CAP, label=label)
        try:
            text, _, _ = accounting.stream_complete(client,
                helper_messages(prompt, sys=sys, history_messages=history_messages),
                on_text, max_tokens=min(max_tokens, 4096),
                temperature=kwargs.get('temperature', 0))
            return [text]
        except (live.BudgetExceeded, sqlite3.IntegrityError) as exc:
            meter.stop_for_budget(label, exc)
            raise
        finally:
            client.db.close()

    player.helper_client = helper
    return player


def prepare():
    if RECORD.exists() or live.OUT.exists():
        raise ValueError('Artifacts already exist; no automatic restart')
    manifest = live.manifest()
    manifest.update(authorization='User requested 组合一下测一下: longer opening plus shorter first body, one six-turn same-motion test within previously approved cumulative USD50 cap. No cap increase.',
        parent_cap_usd=50, run_cap_usd=8, combination_attempts_cap_usd=8,
        combination=dict(prefix_words=[42,46], prefix_word_target=44, prefix_audio_target_seconds=[16,18],
            first_body_words=[50,70], first_body_word_target=60, first_body_duration_target_ceiling=26,
            local_prefix_min_words=42, paragraph_merge_min_words=30,
            prior_attempt="v62 stopped after observed prefix underlength and merged first body; all charges retained",
            baseline='listening-motion-live-v52-refactor-streamed-motion02-v61',
            comparison_limit='Fresh conversation, not frozen-input paired ablation. Includes the separately requested closing-evidence prompt correction.'),
        prior_costs_retained=True, automatic_retries=False,
        method='Fresh six-turn motion02 debate through current production listening-prefix and streamed whole-body revision, native adaptive TTS, wall-clock playback and Whisper ASR. Saved motion02 evidence pools; no new retrieval. Streaming helper calls use the existing metered SSE adapter.',
        guard='Durable SQLite guards enforce USD50 cumulative parent, USD8 run, existing global/study/combined caps. Failed and in-flight reservations retained. No automatic rerun.',
        launch_wrapper_sha256=live.digest(__file__))
    manifest['estimate_usd'].update(expected=[1,3], run_stop=8,
        parent_cumulative_stop=50, conservative_incremental=8)
    manifest['first_paragraph']['semantic_review'] = live.CONFIG.listening_prefix_review_enabled
    live.atomic_json(RECORD, manifest)
    live.atomic_json(live.MANIFEST, manifest)
    print(json.dumps(dict(motion=manifest['motion'], turns=len(live.TURNS),
        stream_revision=live.CONFIG.listening_stream_body_revision,
        estimate_usd=[1,3], run_cap=8, parent_cap=50), indent=2))


def main():
    p = argparse.ArgumentParser(); p.add_argument('--execute', action='store_true')
    args = p.parse_args()
    if not args.execute:
        prepare(); return
    record = json.loads(RECORD.read_text())
    assert record['launch_wrapper_sha256'] == live.digest(__file__)
    assert record['output_config'] == asdict(live.CONFIG)
    assert record['status'] == 'approved' and not live.OUT.exists()
    live.new_player, live.arm_combined_guard = new_player, arm
    sys.argv = [str(Path(live.__file__)), '--execute']
    try:
        live.main()
    finally:
        if live.OUT.exists():
            (live.OUT / 'launch_wrapper.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
