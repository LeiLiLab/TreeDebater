"""Replay six saved first-paragraph inputs. Default prepares only; --execute bills six drafts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(D))
from benchmark_listening_motion_live import arm_study_guard, ledger_summary
from scripts.benchmark_incremental_planning import atomic_json, code_digest
from streaming.config import OutputConfig, from_mapping
from streaming.experiment_client import BudgetedClient, MODEL
from streaming.flat_speaking import _json_object
from streaming.listening_prefix import prepare, _valid_candidate
from streaming.overview_planning import parse_overview

BASE = 'listening-motion-live-v42'
RUN = BASE + '-first-paragraph-v1'
OUT = D / 'run' / RUN
CAP = 1.0


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_plan():
    baseline = json.loads((D / f'manifest_{BASE}.json').read_text())
    audit = json.loads((D / 'run' / BASE / 'overview_content_audit.json').read_text())
    config = from_mapping(OutputConfig, baseline['output_config'])
    requests = []
    for entry in audit['drafts']:
        source = D / 'run' / f"call_{entry['call_id']:06}.json"
        old = json.loads(source.read_text())
        messages = old['request']['messages']
        payload = json.loads(messages[-1]['content'].rsplit('\n', 1)[-1])
        class Captured(Exception):
            pass
        captured = []
        def capture(**kwargs):
            captured.append(kwargs)
            raise Captured()
        try:
            prepare(payload['context'], capture, config, endpoint=payload['endpoint'],
                    system_prompt=messages[0]['content'],
                    writing_options={'model': MODEL, 'temperature': baseline['main_temperature']})
        except Captured:
            pass
        assert len(captured) == 1
        call = captured[0]
        request = dict(model=call['model'], temperature=call['temperature'],
                       max_tokens=call['max_tokens'], num_retries=0,
                       messages=[{'role':'system','content':call['sys']},
                                 {'role':'user','content':call['prompt']}],
                       response_format={'type':'json_object'})
        assert json.loads(call['prompt'].rsplit('\n', 1)[-1]) == payload
        size = len(json.dumps(request, ensure_ascii=False).encode())
        # Escaped JSON conservatively bounds the UTF-8 serialization used at dispatch.
        wire_size = len(json.dumps(request).encode())
        reserve = 4 * (wire_size + 8192 + request['max_tokens']) / 1_000_000
        usage = old['response']['usage']
        old_size = len(json.dumps(old['request'], ensure_ascii=False).encode())
        expected_input = usage['prompt_tokens'] * size / old_size
        expected = (expected_input * .13 + request['max_tokens'] * .40) / 1_000_000
        requests.append(dict(index=len(requests), stage=entry['stage'], side=entry['side'],
                             source_call=entry['call_id'], source_sha256=sha(source),
                             context=payload['context'], baseline_text=entry['text'],
                             request=request, reservation_usd=reserve, expected_usd=expected))
    assert len(requests) == 6
    start = ledger_summary()
    return dict(run=RUN, baseline=BASE, status='approved', created_utc=datetime.now(timezone.utc).isoformat(),
                authorization='Existing user-approved cumulative USD300 global/USD210 listening study budget; user now explicitly requests testing only first-paragraph generation from existing material. Six draft calls, no automatic rerun or cap increase.',
                scope='Six independent first drafts on the original saved partial-input snapshots; original history and opponent input unchanged. No reviews, repairs, body generation, TTS, ASR or new planning.',
                source_digest=code_digest(), harness_sha256=sha(Path(__file__)),
                global_cap_usd=300, study_cap_usd=210, local_cap_usd=CAP, starting_ledger=start,
                prices=dict(input_per_million=.13, output_per_million=.40,
                            source='https://aws.amazon.com/bedrock/pricing/', checked_utc='2026-10-08'),
                expected_usd=sum(r['expected_usd'] for r in requests),
                sum_initial_reservations_usd=sum(r['reservation_usd'] for r in requests),
                guard='Atomic global/study/local SQLite reservation checks before dispatch; serial calls; no retries. Stop on any error or budget rejection. Unknown usage retains its full reservation.',
                output_config=baseline['output_config'], requests=requests,
                limitations=['Only first drafts; no publication-review decision or audio timing measured.',
                             'Prompt and temperature changed together, so their separate effects are not identified.',
                             'One sample per saved context; not a statistical diversity evaluation.'])


def execute(plan, output_dir=None):
    out = Path(output_dir) if output_dir is not None else OUT
    run = plan['run']
    assert plan['status'] == 'approved'
    assert plan['source_digest'] == code_digest()
    assert plan['harness_sha256'] == sha(Path(__file__))
    if 'source_files' in plan:
        for path, digest in plan['source_files'].items():
            assert sha(ROOT / path) == digest
    else:
        for r in plan['requests']:
            assert r['source_sha256'] == sha(D / 'run' / f"call_{r['source_call']:06}.json")
    for key, value in json.loads((ROOT / 'src/configs/api_key.json').read_text()).items():
        os.environ.setdefault(key, value)
    client = BudgetedClient(D / 'run', cap=300, label=run)
    rows = []
    error = None
    try:
        assert not client.db.execute('select 1 from calls where instr(label,?)=1', (run + '/',)).fetchone()
        arm_study_guard(client.db)
        arm_study_guard(client.db, run + '/', plan['local_cap_usd'])
        plan['status'] = 'running'
        atomic_json(out / 'manifest.json', plan)
        for item in plan['requests']:
            client.label = run + '/' + str(item['index'])
            request = item['request']
            raw = client.complete(request['messages'], model=request['model'],
                                  temperature=request['temperature'], max_tokens=request['max_tokens'],
                                  json_mode=True, request_timeout=60)
            candidate = _json_object(raw)
            parse_overview(candidate.get('framework'))
            row = dict(index=item['index'], stage=item['stage'], side=item['side'],
                       source_call=item.get('source_call'), baseline_text=item.get('baseline_text'),
                       candidate=candidate, local_format_ok=_valid_candidate(candidate, item['context'],
                           from_mapping(OutputConfig, plan['output_config'])),
                       published=False, semantic_review_performed=False)
            rows.append(row)
            atomic_json(out / 'results.json', rows)
            print(json.dumps(row, ensure_ascii=False), flush=True)
    except Exception as exc:
        error = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        cost = client.db.execute('select coalesce(sum(estimated_usd),0) from calls where instr(label,?)=1', (run + '/',)).fetchone()[0]
        from streaming.experiment_accounting import exposure_query
        exposure = client.db.execute(exposure_query(' WHERE instr(c.label,?)=1'), (run + '/',)).fetchone()[0]
        pending = client.db.execute("select count(*) from calls where instr(label,?)=1 and state='pending'", (run + '/',)).fetchone()[0]
        client.db.close()
        plan.update(status='completed' if len(rows)==6 and not error else 'stopped', error=error,
                    completed_drafts=len(rows), known_usage_usd=cost, conservative_exposure_usd=exposure,
                    pending=pending, ending_ledger=ledger_summary(), settled_invoice=False)
        atomic_json(out / 'manifest.json', plan)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if args.execute:
        execute(json.loads((OUT / 'manifest.json').read_text()))
    else:
        OUT.mkdir(exist_ok=False)
        plan = build_plan()
        atomic_json(OUT / 'manifest.json', plan)
        print(json.dumps({k:plan[k] for k in ('run','expected_usd','sum_initial_reservations_usd','local_cap_usd')},indent=2))
