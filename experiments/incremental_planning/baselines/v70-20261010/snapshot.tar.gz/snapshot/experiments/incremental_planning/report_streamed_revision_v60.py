"""Report the explicit v60 real retest without issuing more requests."""
import report_streamed_revision_v58 as report

report.RUN='listening-motion-live-v52-refactor-streamed-revision-v60'
report.OUT=report.D/'run'/report.RUN
report.VERSION='v60'

if __name__=='__main__':
    report.main()
