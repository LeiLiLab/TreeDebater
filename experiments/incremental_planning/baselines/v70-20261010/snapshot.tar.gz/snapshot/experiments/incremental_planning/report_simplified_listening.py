import json, sys, hashlib, sqlite3
from pathlib import Path
from pydub import AudioSegment
R=Path('/mnt/data4/danqingwang/workspace/clone/TreeDebater')
D=R/'experiments/incremental_planning'
sys.path.insert(0,str(D))
from benchmark_listening_motion_live import ledger_summary
run=sys.argv[1] if len(sys.argv)>1 else 'listening-motion-live-v46'
out=D/'run'/run
manifest=json.loads((D/f'manifest_{run}.json').read_text())
assert manifest['status'] in ('completed','stopped')
hashes=json.loads((out/'source_snapshot/files.json').read_text())
assert all(hashlib.sha256((out/'source_snapshot'/p).read_bytes()).hexdigest()==v for p,v in hashes.items())
changed_since_trial=[p for p,v in hashes.items() if hashlib.sha256((R/p).read_bytes()).hexdigest()!=v]
assert changed_since_trial in ([], ['src/streaming/listening_prefix.py'])
rows=[]
views={'for':[],'against':[]}
for path in sorted(out.glob('[0-9][0-9]_*/result.json')):
 r=json.loads(path.read_text()); folder=path.parent
 assert r['history']==views[r['side']]
 tfiles=list(folder.glob('*_chunks/listening_prefix.json'))
 t=json.loads(tfiles[0].read_text()) if tfiles else {}
 for c in r['chunks']:
  assert abs(len(AudioSegment.from_file(R/c['path']))/1000-c['duration_seconds'])<.002
 first=r.get('endpoint_to_first_audio_seconds') if r['index'] else r.get('generation_to_first_audio_seconds')
 gap=max((p['gap_seconds'] for p in r['playback']),default=0)
 decoded_gaps=[max(0, r['playback'][i]['start_monotonic']-r['playback'][i-1]['start_monotonic']-r['chunks'][i-1]['duration_seconds']) for i in range(1,len(r['playback']))]
 gap=max(gap,max(decoded_gaps,default=0))
 error=(r['audio_seconds']/r['target_seconds']-1)*100
 row=dict(index=r['index'],stage=r['stage'],side=r['side'],status=r['status'],first_audio_seconds=first,
  max_gap_seconds=gap,audio_seconds=r['audio_seconds'],duration_error_percent=error,
  target_seconds=r['target_seconds'],generation_to_first_audio_seconds=r.get('generation_to_first_audio_seconds'),
  generation_start_delay_seconds=r.get('generation_start_delay_seconds'),
  listener_backlog_seconds=r.get('listener_backlog_seconds'),gate_ready_seconds=t.get('gate_ready_seconds'),
  reused_overview=t.get('cold_prefix') is False,reused_body=bool(t.get('body_preparation')),
  speculative_calls=t.get('speculative_calls'),tail_work=t.get('tail_work'),error=r.get('error'))
 row['completed_playback_seconds']=sum(r['chunks'][p['index']]['duration_seconds'] for p in r['playback'])
 row['timing_pass']=r['status']=='completed' and first<=10 and gap<=2 and abs(error)<=15
 if r['status']=='completed':
  assert abs(sum(c['duration_seconds'] for c in r['chunks'])-r['audio_seconds'])<.002
  heard_duration=0
  for h in r['heard']:
   assert h['worker_start_monotonic']>=h['heard_end_monotonic']
   n=len(AudioSegment.from_file(R/h['audio']))/1000
   assert 0<n<=(15 if 'slice_seconds' in manifest['asr'] else 120)
   heard_duration+=n
  assert abs(heard_duration-r['audio_seconds'])<.01
  assert r['listener_transcript']==' '.join(h['text'] for h in r['heard'])
  assert r['answer']=='\n\n'.join(c['text'] for c in r['chunks'])
  views[r['side']].append(dict(stage=r['stage'],side=r['side'],content=r['answer']))
  other='against' if r['side']=='for' else 'for'
  views[other].append(dict(stage=r['stage'],side=r['side'],content=r['listener_transcript'],tree_via_streaming=True))
 rows.append(row)
ledger=ledger_summary()
assert ledger['pending_calls']==0
con=sqlite3.connect(D/'run/cost.sqlite')
con.row_factory=sqlite3.Row
cost=con.execute('select coalesce(sum(estimated_usd),0) from calls where instr(label,?)=1',(run+'/',)).fetchone()[0]
report=dict(run=run,status=manifest['status'],completed_turns=manifest['completed_turns'],
 timing_pass=len(rows)==6 and all(r['timing_pass'] for r in rows),turns=rows,
 artifact_checks='Source hashes, decoded callback durations, ASR audio coverage and causality, exact spoken/ASR-only history checked.',
 quality_review='Pending manual review of complete conversation; model gates are not independent quality evidence.',
 estimated_new_usage_usd=cost,ledger=ledger)
from collections import Counter
from streaming.experiment_accounting import exposure_query
calls=[dict(c) for c in con.execute('select * from calls where instr(label,?)=1',(run+'/',))]
phases=Counter(c['label'].rsplit('/',1)[-1] for c in calls if c['label'].rsplit('/',1)[-1] not in ('tts','asr'))
removed=['listening_prefix_review','endpoint_gate','listening_body_feedback','listening_final_body_gate','meaning_review']
assert all(phases[x]==0 for x in removed), phases
report['text_call_counts_by_phase']=dict(phases)
report['removed_phase_call_counts']={x:phases[x] for x in removed}
report['new_conservative_exposure_usd']=con.execute(exposure_query(' WHERE instr(c.label,?)=1'),(run+'/',)).fetchone()[0]
report['rollback_snapshot']=manifest['rollback_snapshot']
report['preflight_tests_passed']=109
report['final_offline_tests_passed']=319
traces=[json.loads(next(path.parent.glob('*_chunks/listening_prefix.json')).read_text()) for path in sorted(out.glob('[0-9][0-9]_*/result.json'))]
report['overlap_audit']=dict(prepared_prefixes=sum(not t['cold_prefix'] for t in traces),
    reused_feedback=sum(bool(t.get('parallel_body_feedback',{}).get('reused')) for t in traces),
    reused_revision=sum(bool(t.get('parallel_body_revision',{}).get('reused')) for t in traces),
    final_body_reviews=sum(len(t['body_reviews']) for t in traces),
    final_body_repairs=sum(t.get('final_body_repairs',0) for t in traces))
assert report['overlap_audit']['final_body_reviews']==report['overlap_audit']['final_body_repairs']==0
report['changed_after_live_trial']=changed_since_trial
report['format_fix_after_trial']='Explicit local repair output schema; prompted by continuation call22271 copying the input envelope and truncating.58 targeted tests passed.'
report['scope_note']='Fresh generated match; comparison with v45 is descriptive, not causal or paired.'
conversation=[]
for path in sorted(out.glob('[0-9][0-9]_*/result.json')):
 r=json.loads(path.read_text())
 speech=r.get('answer') or '\n\n'.join(c['text'] for c in r['chunks'])
 conversation.append(f"{r['index']+1}. {r['stage']} {r['side']} ({r['status']})\n\n{speech}")
(out/'conversation.txt').write_text('\n\n'.join(conversation),encoding='utf-8')
(out/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
