"""Offline planning-request and handoff comparison for the6-second live trial."""
import argparse
import json
from pathlib import Path
import sqlite3
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.overview_planning import parse_overview

D = Path(__file__).resolve().parent
LEDGER = D / 'run'


def inspect(run):
    requests = []
    with sqlite3.connect(f'file:{LEDGER}/cost.sqlite?mode=ro', uri=True) as db:
        rows = db.execute('SELECT id,label,state,seconds FROM calls WHERE instr(label,?)=1 '
                          "AND label LIKE '%/prepare_compact_json_rebuttal_choices' ORDER BY id", (run + '/',)).fetchall()
    for call_id, label, state, seconds in rows:
        artifact = json.loads((LEDGER / f'call_{call_id:06}.json').read_text())
        messages = artifact['request']['messages']
        row = dict(call_id=call_id, label=label, state=state, seconds=seconds,
                   timeout_seconds=artifact.get('request_timeout_seconds'),
                   input_characters=sum(len(m['content']) for m in messages),
                   readable_projection=any('READABLE EXCHANGES:' in m['content'] for m in messages),
                   overview_valid=False, overview_ready=False, error=artifact.get('error'))
        if state == 'ok':
            response = artifact['response']
            row['usage'] = response.get('usage')
            try:
                data = json.loads(response['choices'][0]['message']['content'])
                row['list_counts'] = {k: len(data[k]) for k in ('claims', 'limits', 'rebuttals')}
                row['exceeds_parser_list_cap'] = any(row['list_counts'][k] > n for k, n in
                                                       (('claims', 3), ('limits', 6), ('rebuttals', 2)))
                overview = parse_overview(data['overview'])
                row.update(overview_valid=True, overview_ready=overview['ready'])
            except (KeyError, TypeError, ValueError) as exc:
                row['output_error'] = str(exc)
        requests.append(row)
    successful = [r['seconds'] for r in requests if r['state'] == 'ok']
    turns = []
    for path in sorted((LEDGER / run).glob('[0-9][0-9]_*/result.json')):
        result = json.loads(path.read_text())
        trace = result.get('delivery_trace', {})
        turns.append(dict(index=result['index'], stage=result['stage'], side=result['side'],
            status=result['status'], first_audio_seconds=result.get('endpoint_to_first_audio_seconds')
                if result['index'] else result.get('generation_to_first_audio_seconds'),
            listener_backlog_seconds=result.get('listener_backlog_seconds'),
            cold_prefix=trace.get('cold_prefix'),
            candidate_ready_before_opponent_endpoint=result.get('candidate_ready_before_opponent_endpoint'),
            preparation_waiting_for_framework=sum(e.get('status') == 'waiting_for_framework'
                for e in trace.get('preparation_events', [])),
            max_analysis_queue_seconds=max((b['analysis_start_monotonic'] - b['queued_monotonic']
                for b in result.get('analysis_batches', [])), default=0)))
    return dict(run=run, requests=requests, turns=turns, totals=dict(
        requests=len(requests), completed=sum(r['state'] == 'ok' for r in requests),
        timeouts=sum('Timeout' in (r['error'] or '') for r in requests),
        other_errors=sum(r['state'] == 'error' and 'Timeout' not in (r['error'] or '') for r in requests),
        ready_overviews=sum(r['overview_ready'] for r in requests),
        successful_over_3_seconds=sum(r['state'] == 'ok' and r['seconds'] > 3 for r in requests),
        successful_median_seconds=statistics.median(successful) if successful else None,
        successful_max_seconds=max(successful) if successful else None,
        readable_requests=sum(r['readable_projection'] for r in requests),
        responses_exceeding_list_caps=sum(r.get('exceeds_parser_list_cap', False) for r in requests)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', default='listening-motion-live-v37')
    parser.add_argument('--baseline', default='listening-motion-live-v36')
    args = parser.parse_args()
    current, baseline = inspect(args.run), inspect(args.baseline)
    assert all(r['timeout_seconds'] == 6 for r in current['requests'])
    report = dict(current=current, baseline=baseline,
        limitations=['Fresh conversations differ; both timeout and readable input changed since v36.',
                     'Timed-out durations are censored; successful-only medians exclude them.',
                     'Ready overview and list-count checks do not establish full plan or semantic validity.'])
    output = LEDGER / args.run / 'planning_timeout_audit.json'
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(current=current['totals'], baseline=baseline['totals'], turns=current['turns']), indent=2))


if __name__ == '__main__':
    main()
