"""Offline provenance, transcript, MP3 and budget audit after the 36-turn run."""
import hashlib
import json
from pathlib import Path
import sqlite3
from pydub import AudioSegment
ROOT=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    manifest=json.loads((D/'manifest_motion_overlap_v2.json').read_text())
    base=D/'run'/manifest['run_id']
    assert manifest['status']=='completed'
    paths=sorted(base.glob('*/*/*/result.json'))
    assert len(paths)==manifest['answers']==36
    identities=set();chunks=0;changed=[];combined_deltas=[]
    for p in paths:
        r=json.loads(p.read_text());ident=(r['case'],r['arm']);assert ident not in identities;identities.add(ident)
        assert r['answer']=='\n\n'.join(e['text'] for e in r['events'])
        assert r['returned_text']==r['answer']
        assert len(r['events'])==r['chunks']
        assert abs(r['audio_seconds']-sum(e['audio_seconds'] for e in r['events']))<.001
        assert (p.parent/'judgment.json').exists()
        assert r['status']=='returned'
        assert r['output_config']['max_refinements']==r['output_config']['early_max_refinements']==0
        assert r['output_config']['first_chunk_local_tempo'] is False
        assert r['output_config']['speed_adjust_min']==r['output_config']['speed_adjust_max']==1
        for i,e in enumerate(r['events']):
            assert e['index']==i
            path=ROOT/e['path'];assert path.with_suffix('.txt').read_text().strip()==e['text'].strip()
            assert abs(len(AudioSegment.from_file(path))/1000-e['audio_seconds'])<.001
            chunks+=1
        for profile in r.get('chunk_profiles',[]):
            assert float(profile['local_tempo_speed'])==1
            assert profile['local_tempo_status']=='disabled'
            assert int(profile['chosen_intra_iter'])==0
        for call in r['audio_calls']:assert call['state']=='ok'
        combined=list(p.parent.glob('*.mp3'));assert len(combined)==1
        delta=len(AudioSegment.from_file(combined[0]))/1000-r['audio_seconds']
        assert abs(delta)<.15;combined_deltas.append(delta)
        trace=r['fixed_prefix_trace']
        if trace['status']=='completed':
            assert trace['chunks'][0]['text']==trace['fixed_prefix']
            assert trace['whole_feedback_passes']==2
            expected=' '.join((trace['fixed_prefix']+' '+trace['revised_tail']).split())
            assert expected==' '.join(r['answer'].split()), (r['case'],r['arm'],'Published text differs from final prefix/tail')
    planned=json.loads((D/'cases_motion_overlap_v1.json').read_text())
    assert identities=={(c['id'],arm) for c in planned for arm in manifest['arms']}
    files=json.loads((base/'source_snapshot/files.json').read_text());source=hashlib.sha256()
    for rel,digest in sorted(files.items()):
        p=base/'source_snapshot'/rel;assert sha(p)==digest
        source.update(rel.encode());source.update(p.read_bytes())
        if sha(ROOT/rel)!=digest:changed.append(rel)
    assert source.hexdigest()==manifest['source_digest']
    assert sha(base/'source_snapshot/harness.py')==manifest['harness_sha256']
    assert sha(D/'cases_motion_overlap_v1.json')==manifest['cases_sha256']
    for path,digest in manifest['input_sources'].items():assert sha(ROOT/path)==digest
    db=sqlite3.connect(f'file:{D/"run/cost.sqlite"}?mode=ro',uri=True)
    states=dict(db.execute('select state,count(*) from calls where instr(label,?)=1 group by state',('flat-motion-overlap-',)))
    assert not states.get('pending',0)
    result=dict(attempts_v2=len(paths),unique_attempts=True,decoded_chunks=chunks,exact_published_transcripts=True,
        audio_sidecars_and_durations_match=True,no_local_or_provider_speed_change=True,no_tts_text_rewrite=True,
        source_snapshot_harness_inputs_verified=True,working_source_changed_since_launch=changed,
        working_source_added_since_launch=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'src').rglob('*.py') if str(p.relative_to(ROOT)) not in files),
        execution_source_note=json.loads((base/'execution_audit_notes.json').read_text()),
        combined_duration_max_abs_difference_s=max(map(abs,combined_deltas)),study_cost_states=states,
        preserved_failed_v1_attempts=4,limitations=['No ASR or listening fidelity audit.','First audio is server readiness; gaps are simulated queue estimates.'])
    (D/'motion_overlap_artifact_audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
