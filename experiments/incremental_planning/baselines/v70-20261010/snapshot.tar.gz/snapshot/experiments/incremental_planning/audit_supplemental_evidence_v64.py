"""Offline provenance audit of the three v64 endpoint evidence supplements.

Reads saved requests and delivered text. Replays only the deterministic material
formatter; does not generate counterfactual speeches or call any provider.
"""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from utils.evidence_material import EvidenceSelection, writing_evidence

D = ROOT / 'experiments/incremental_planning'
LEDGER = D / 'run'
RUN = 'listening-motion-live-v52-refactor-streamed-motion02-v64'
CASES = [('01_opening_against', 23436, 'against', '反方开篇'),
         ('02_rebuttal_for', 23464, 'for', '正方反驳'),
         ('03_rebuttal_against', 23491, 'against', '反方反驳')]

# Manual assessments concern the source excerpts actually supplied to the writer.
# Paragraph numbers count body paragraphs only, excluding the fixed opening.
REVIEWS = {
    ('01_opening_against', '2_9'): dict(
        use='explicit_attribution', body_paragraph=4, marker='The Brennan Center for Justice notes',
        effect='redundant_support',
        assessment='有明确引用，但草稿已提出骗子红利；已有材料2_7已支持公众怀疑被利用。新增材料提供同方向解释，未填补“强制标签会导致该效应”的因果缺口。',
        caveat='正文将对深度伪造的认知推广为标签政策必然产生骗子红利；摘录并未证明这一步。'),
    ('02_rebuttal_for', '5_6'): dict(
        use='explicit_attribution', body_paragraph=2, marker='According to the AI Content Labels report from the IAB',
        effect='limited_positive',
        assessment='草稿已主张材料性标准并排除常规任务；新增摘录为该主张补上具体框架及排除后台工具的细节，提供了可辨认的依据。',
        caveat='材料实际是介绍IAB框架的二手平台规则文章，正文说成IAB报告；框架存在不能证明普遍可执行或强制政策净收益。'),
    ('02_rebuttal_for', '1_5'): dict(
        use='explicit_attribution', body_paragraph=3, marker='The NIM study on consumer attitudes toward AI-generated marketing content',
        effect='weak_support_with_overgeneralization',
        assessment='“透明度提醒受众注意真实性问题”有摘录依据，但研究语境是AI营销内容；正文随后推广为对虚假信息的认知防御和韧性。',
        caveat='摘录强调透明度本身不能解决信任缺口，最终正文没有保留该关键限制；不能据此认定改善了防御效果论证。'),
    ('03_rebuttal_against', '0_38'): dict(
        use='explicit_attribution', body_paragraph=3, marker='As noted in "Towards a global approach to digital platform regulation,"',
        effect='unsupported_attribution',
        assessment='正文将“材料性标准含糊导致负担、抑制竞争”归于该文，但实际提供摘录未建立此联系。草稿原有负担论点仅换了来源名称。',
        caveat='摘录反而明确该类独立监管并未走到要求某些高成本合规措施的程度；不能把该段当作此项政策抑制竞争的证据。'),
    ('03_rebuttal_against', '2_3'): dict(
        use='explicit_attribution', body_paragraph=4, marker='As defined by Wikipedia',
        effect='redundant_definition',
        assessment='准确补入骗子红利的概念定义；草稿和上一轮发言已有同一机制，并未提供新机制或效果证据。',
        caveat='定义不能证明强制标签会让该现象更严重，正文新增的强因果表述仍没有获得支持。'),
    ('03_rebuttal_against', '2_26'): dict(
        use='no_observable_incremental_use', body_paragraph=None, marker=None,
        effect='unattributable',
        assessment='进入材料包但没有点名引用；摘录特有的“公开检测工具利于绕过、保密工具降低实用性”权衡未出现在正文。技术脆弱性及重编码论点在草稿中已经存在。',
        caveat='不能排除隐含影响，但没有可归因于本次补选的新增内容。'),
}


def read(path):
    return json.loads(path.read_text())


def collect():
    pools, selections = {'for': {}, 'against': {}}, []
    with sqlite3.connect(f'file:{LEDGER / "cost.sqlite"}?mode=ro', uri=True) as db:
        records = db.execute('SELECT id,label FROM calls WHERE label LIKE ? ORDER BY id',
                             (RUN + '/%',)).fetchall()
    for number, label in records:
        path = LEDGER / f'call_{number:06}.json'
        if not path.exists():
            continue
        receipt = read(path)
        prompt = (receipt.get('request', {}).get('messages') or [{}])[-1].get('content', '')
        if not prompt.startswith('From the provided list of evidence dictionaries'):
            continue
        sources = json.JSONDecoder().raw_decode(prompt.split('Evidence list:\n', 1)[1].lstrip())[0]
        side = label.split('/')[1]
        for source in sources:
            previous = pools[side].get(source['id'])
            assert previous is None or previous == source, 'Source mutated within saved selection requests'
            pools[side][source['id']] = source
        result = json.loads(receipt['response']['choices'][0]['message']['content'])
        selections.append(dict(call_id=number, side=side, candidate_ids=[e['id'] for e in sources],
                               analysis=result.get('analysis', {})))
    return pools, selections


def card_ids(cards):
    return {str(i) for card in cards for i in [card['id'], *card.get('also_selected_ids', [])]}


def main():
    pools, selections = collect()
    cases = []
    for turn, number, side, name in CASES:
        request_path = LEDGER / f'call_{number:06}.json'
        request = read(request_path)
        data = json.loads(request['request']['messages'][-1]['content'].splitlines()[-1])
        trace_path = next((LEDGER / RUN / turn).glob('*_chunks/listening_prefix.json'))
        trace = read(trace_path)
        spoken = read(LEDGER / RUN / turn / 'result.json')['answer']
        paragraphs = spoken.split('\n\n')[1:]
        events = trace['prepared_evidence']['events']
        reasons, call_ids = {}, []
        for event in events:
            matches = [c for c in selections if c['side'] == side and c['call_id'] < number
                       and c['candidate_ids'] == event['candidate_ids']]
            assert len(matches) == 1, 'Ambiguous selection provenance'
            selection = matches[0]
            call_ids.append(selection['call_id'])
            for eid in event['new_ids']:
                if eid in selection['analysis']:
                    reasons[eid] = selection['analysis'][eid]
        ids = trace['prepared_evidence']['selected_ids']
        evidence = EvidenceSelection([pools[side][i] for i in ids], reasons)
        options = dict(statement=data['unpublished_draft'], feedback=data['feedback'],
                       n_words=data['remaining_word_target'])
        packed = writing_evidence(evidence, **options)
        assert packed == data['evidence'], 'Formatter replay differs from actual paid request'
        prior_ids = events[-1]['reused_ids']
        prior = writing_evidence(EvidenceSelection([pools[side][i] for i in prior_ids], reasons), **options)
        actual_ids, prior_pack_ids = card_ids(packed), card_ids(prior)
        items = []
        for eid in events[-1]['new_ids']:
            source = pools[side][eid]
            assessment = REVIEWS.get((turn, eid))
            if eid in actual_ids:
                assert assessment, 'Missing manual assessment for an admitted addition'
            else:
                assert assessment is None
                assessment = dict(use='not_in_revision_material', effect='no_direct_material_path',
                    assessment='本次补选后未进入实际正文修订材料包；不能将最终正文相似论点归因于该次补选。',
                    caveat='来源可能早已出现在其他上下文；此结论仅针对本次补选通路。')
            paragraph = assessment.get('body_paragraph')
            if paragraph is not None:
                assert assessment['marker'] in paragraphs[paragraph - 1]
            items.append(dict(id=eid, title=source.get('title'), source_content=source.get('content'),
                selection_reason=reasons.get(eid), entered_actual_revision_material=eid in actual_ids,
                supplied_cards=[c for c in packed if eid in card_ids([c])],
                delivered_body_paragraph=paragraphs[paragraph - 1] if paragraph else None,
                review=assessment))
        cases.append(dict(turn=turn, name=name, revision_call_id=number,
            endpoint_selection_call_id=call_ids[-1], prior_selection_call_ids=call_ids[:-1],
            revision_request_sha256=hashlib.sha256(request_path.read_bytes()).hexdigest(),
            draft=data['unpublished_draft'], feedback=data['feedback'], delivered_text=spoken,
            added_count=len(items), admitted_added_count=sum(i['entered_actual_revision_material'] for i in items),
            explicitly_used_added_count=sum(i['review']['use'] == 'explicit_attribution' for i in items),
            exact_actual_material_replay=True, actual_material=packed,
            material_without_endpoint_additions=prior,
            displaced_prior_ids=sorted(prior_pack_ids - actual_ids),
            manual_item_reviews=items,
            endpoint_selection_seconds=trace['parallel_evidence_selection']['end_seconds']
                - trace['parallel_evidence_selection']['start_seconds']))
    all_items = [item for case in cases for item in case['manual_item_reviews']]
    report = dict(run=RUN, method='Saved request/source/draft/delivered-text audit plus exact local formatter replay.',
        new_provider_calls=0, cases=cases,
        totals=dict(added=len(all_items), admitted=sum(i['entered_actual_revision_material'] for i in all_items),
            explicit_use=sum(i['review']['use']=='explicit_attribution' for i in all_items),
            limited_positive=sum(i['review']['effect']=='limited_positive' for i in all_items)),
        limitations=[
            'Manual qualitative assessment, not a causal model ablation or benchmark score.',
            'The no-additions replay reconstructs input material only, not what the model would have written.',
            'Source support is assessed against the stored excerpts actually supplied; external source truth was not independently verified.',
            'Absence from the revision material does not prove absence from all earlier history or model knowledge.',
            'Explicit citations show use, not necessarily correct support or improvement.',
        ])
    out = D / 'supplemental_evidence_audit_v64.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    lines = ['v64 最终补充选材审计（仅离线读取，无新增模型调用）',
        '共新增23条：6条进入正文修订材料包，5条有明确引用；1条可见有限正收益。',
        '此处“有限正收益”是人工对照草稿后的判断，不是删除补选后重新生成的因果实验。', '']
    for case in cases:
        lines += [f'{case["name"]}: 新增{case["added_count"]} → 进入材料包{case["admitted_added_count"]} → 明确引用{case["explicitly_used_added_count"]}',
                  f'最终选材调用{case["endpoint_selection_call_id"]}；正文修订调用{case["revision_call_id"]}；选材耗时{case["endpoint_selection_seconds"]:.2f}秒。',
                  '使用实际选材与分析，已逐字重建实际材料包。仅移除最终新增材料后重新打包，原有但被挤出的ID：' + ', '.join(case['displaced_prior_ids'])]
        for item in case['manual_item_reviews']:
            review = item['review']
            lines += [f'  {item["id"]} | {item["title"]} | {review["use"]}',
                      '    ' + review['assessment']]
            if item['entered_actual_revision_material']:
                lines += ['    限制：' + review['caveat']]
        lines.append('')
    lines += ['结构性发现：选择器保留的材料数量远多于写作材料预算能容纳的数量。补选会重排并挤出既有材料；不能用新增来源数衡量价值。',
              '正方反驳反馈新增的两个任务是回应骗子红利与用户疲劳；明确引用的两条新增来源分别用于既有材料性标准和营销内容信任论点，未直接填补标签抵御骗子红利的证据缺口。',
              '建议：围绕明确、未覆盖的论证需求判断是否补选，并在实际写作材料预算内评价增益。保留必要补选，不把补选默认设为每轮必经串行调用。']
    (D / 'supplemental_evidence_audit_v64.txt').write_text('\n'.join(lines) + '\n')
    print(json.dumps(report['totals']))
    print(out)


if __name__ == '__main__':
    main()
