"""Summarize real request timings and replayed playback, without new API calls."""
import csv
import json
from pathlib import Path
import re
import sqlite3
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'src'))
from streaming.experiment_accounting import exposure_query
D=ROOT/'experiments/incremental_planning'
RUN='listening-motion-live-v52-refactor-revision-pipelines-v56'
OUT=D/'run'/RUN


def repeated_spans(chunks,n=8):
    seen={}; repeated=[]
    for i,chunk in enumerate(chunks):
        words=re.findall(r"[a-z0-9]+",chunk.lower())
        for j in range(len(words)-n+1):
            span=' '.join(words[j:j+n])
            if span in seen and seen[span]!=i:
                repeated.append(dict(first_paragraph=seen[span]+1,later_paragraph=i+1,span=span))
            seen.setdefault(span,i)
    return repeated


def main():
    manifest=json.loads((OUT/'manifest.json').read_text())
    results=[json.loads(p.read_text()) for p in sorted(OUT.glob('*/result.json'))]
    rows=[]
    for r in results:
        if r['status']!='completed':continue
        m=r['metrics']
        chunks=sorted(r['chunks'],key=lambda c:c['index'])
        row=dict(policy=r['policy'],case=r['case'],repeat=r['repeat'],**{k:v for k,v in m.items() if k!='playback_model'},
            text_calls=len(r['text_calls']),tts_calls=len(chunks),text_complete_seconds=r['text_calls'][-1]['done_seconds'],
            cross_chunk_repeated_8grams=len(repeated_spans([r['original_prefix']]+[c['text'] for c in chunks])))
        if r['policy']=='whole_stream':
            row['first_token_seconds']=r['text_calls'][0]['first_token_seconds']
            row['streaming_advance_seconds']=row['text_complete_seconds']-row['first_body_text_seconds']
        else:row.update(first_token_seconds=None,streaming_advance_seconds=None)
        rows.append(row)
    by_policy={}
    for policy in ('whole_stream','paragraph_calls'):
        rs=[r for r in rows if r['policy']==policy]
        if not rs:continue
        fields=['first_body_text_seconds','first_body_audio_seconds','max_playback_gap_seconds','total_playback_gap_seconds',
                'final_audio_ready_seconds','text_complete_seconds','duration_error_pct','body_words']
        by_policy[policy]=dict(runs=len(rs),runs_with_gap_gt_1s=sum(r['max_playback_gap_seconds']>1 for r in rs),
            runs_with_duration_within_5pct=sum(abs(r['duration_error_pct'])<=5 for r in rs),
            median_absolute_duration_error_pct=statistics.median(abs(r['duration_error_pct']) for r in rs),
            totals=dict(text_calls=sum(r['text_calls'] for r in rs),tts_calls=sum(r['tts_calls'] for r in rs)),
            measurements={k:dict(median=statistics.median(r[k] for r in rs),min=min(r[k] for r in rs),max=max(r[k] for r in rs)) for k in fields})
    db=sqlite3.connect('file:'+str(D/'run/cost.sqlite')+'?mode=ro',uri=True)
    cost={}
    for name,prefix,cap in [('experiment',RUN+'/',10),('whole_stream',RUN+'/whole_stream/',5),('paragraph_calls',RUN+'/paragraph_calls/',5),('parent','listening-motion-live-v52-refactor',50)]:
        groups=db.execute('select state,count(*),coalesce(sum(estimated_usd),0) from calls where instr(label,?)=1 group by state',(prefix,)).fetchall()
        exposure=db.execute(exposure_query(' WHERE instr(c.label,?)=1'),(prefix,)).fetchone()[0]
        cost[name]=dict(known_usage_estimate_usd=sum(x[2] for x in groups),states={x[0]:x[1] for x in groups},
            conservative_exposure_usd=exposure,cap_usd=cap,remaining_conservative_usd=cap-exposure)
    summary=dict(status=json.loads((OUT/'progress.json').read_text())['status'],planned_runs=len(manifest['schedule']),
        completed_runs=len(rows),by_policy=by_policy,cost=cost,rows=rows,
        limitations=[manifest['boundaries'],'Two repeats of three fixed cases, not six independent debate samples.',
            'Exact repeated n-grams are a diagnostic, not semantic repetition or factual accuracy scores.',
            'Only the body-generation pipeline is timed; prefix/retrieval/feedback are frozen, not newly generated.',
            'Time budgets refer to decoded audio duration, excluding silence; gaps are reported separately.'])
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    if rows:
        with (OUT/'timing.csv').open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    text=['Paired revision pipelines v56 — full generated outputs',manifest['boundaries']]
    for r in sorted(results,key=lambda r:(r['case'],r['repeat'],r['policy'])):
        text.extend(['\n'+'='*70,f"{r['policy']} | case {r['case']} | repeat {r['repeat']} | {r['status']}",
            json.dumps(r.get('metrics',{}),ensure_ascii=False),r.get('text',r.get('error',''))])
    (OUT/'comparison.txt').write_text('\n\n'.join(text)+'\n')
    print(json.dumps(dict(status=summary['status'],completed_runs=len(rows),by_policy=by_policy,cost=cost),indent=2))


if __name__=='__main__':main()
