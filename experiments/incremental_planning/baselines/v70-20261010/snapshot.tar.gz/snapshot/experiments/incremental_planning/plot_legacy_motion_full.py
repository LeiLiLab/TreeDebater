"""Standalone timing/duration figure for the three matched-context recipes."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from summarize_legacy_motion_full import load_rows, RUN, D

def main():
    summary=json.loads((D/f'{RUN}_summary.json').read_text())
    assert summary['status']=='completed' and summary['recorded']==18
    old=load_rows('flat-motion-overlap-v2')
    legacy=[r for r in load_rows('legacy-motion-full-v2') if r['status']=='returned']+load_rows(RUN)
    arms=[('natural_prefix','Flat: natural opening','#5172a4'),('short_prefix','Flat: short opening','#dd8452'),('legacy','Legacy + TTS rewrite','#4b9670')]
    stages=['opening','rebuttal','closing']
    fig,axes=plt.subplots(1,2,figsize=(12,4.7))
    rng=np.random.default_rng(0)
    for j,(arm,label,color) in enumerate(arms):
        rows=legacy if arm=='legacy' else [r for r in old if r['arm']==arm]
        for i,stage in enumerate(stages):
            group=[r for r in rows if r['stage']==stage];assert len(group)==6
            x=i+(j-1)*.24
            for k,key in enumerate(['generation_to_first_audio_seconds','audio_seconds']):
                y=np.array([r[key]/r['budget'] if k else r[key] for r in group])
                axes[k].scatter(x+rng.uniform(-.045,.045,len(y)),y,s=23,color=color,alpha=.65,zorder=3)
                axes[k].plot([x-.08,x+.08],[y.mean()]*2,color=color,lw=3,label=label if i==0 else None,zorder=4)
    axes[0].set_ylabel('Seconds to first playable audio')
    axes[0].set_title('First-audio wait (lower is better)')
    axes[1].axhspan(.9,1.1,color='#e8edf0',alpha=.7,zorder=0)
    axes[1].axhline(1,color='#555',lw=1,ls='--')
    axes[1].set_ylabel('Actual audio / target duration')
    axes[1].yaxis.set_major_formatter(PercentFormatter(1))
    axes[1].set_title('Full audio duration (target = 100%)')
    for ax in axes:
        ax.set_xticks(range(3),['Opening\n240 s','Rebuttal\n240 s','Closing\n120 s'])
        ax.grid(axis='y',alpha=.2)
        ax.spines[['top','right']].set_visible(False)
        ax.set_xlim(-.55,2.55)
    axes[0].set_ylim(bottom=0)
    axes[1].set_ylim(0,1.15)
    fig.legend(*axes[0].get_legend_handles_labels(),loc='upper center',ncol=3,bbox_to_anchor=(.5,1.01),frameon=False)
    fig.text(.5,.015,'Dots: 6 speeches per stage and method. Lines: means. Legacy includes one explicitly retried harness-limited failure; earlier arms had rewriting off.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.07,1,.91))
    for suffix in ['png','pdf']:fig.savefig(D/f'{RUN}_comparison.{suffix}',dpi=170,bbox_inches='tight')

if __name__=='__main__':main()
