"""Read-only artifact verification for the two whole-speech experiments."""
import hashlib
import json
from pathlib import Path
import sqlite3

from pydub import AudioSegment

ROOT = Path(__file__).resolve().parents[2]
DIRECTORY = Path(__file__).resolve().parent


def main():
    audits, audio_count = [], 0
    for version in (1, 2):
        run = f'flat-full-adaptive-v{version}'
        manifest = json.loads((DIRECTORY / f'manifest_adaptive_speech_v{version}.json').read_text())
        base = DIRECTORY / 'run' / run
        rows = [json.loads(p.read_text()) for p in base.glob('*/*/*/result.json')]
        assert manifest['status'] == 'completed'
        assert len(rows) == manifest['answers']
        assert len({(r['case'], r['repeat'], r['arm']) for r in rows}) == len(rows)
        for row in rows:
            assert row['answer'] == '\n\n'.join(e['text'] for e in row['events'])
            assert abs(row['audio_seconds']-sum(e['audio_seconds'] for e in row['events'])) < .001
            for event in row['events']:
                path = ROOT / event['path']
                assert path.with_suffix('.txt').read_text().strip() == event['text'].strip()
                assert abs(len(AudioSegment.from_file(path))/1000-event['audio_seconds']) < .001
                audio_count += 1
            turn_dir = base / row['case'] / str(row['repeat']) / row['arm']
            assert not row['events'] or (turn_dir / 'judgment.json').exists()
        source_digest = hashlib.sha256()
        files = json.loads((base / 'source_snapshot/files.json').read_text())
        for relative, digest in sorted(files.items()):
            content = (base / 'source_snapshot' / relative).read_bytes()
            assert hashlib.sha256(content).hexdigest() == digest
            source_digest.update(relative.encode())
            source_digest.update(content)
        assert source_digest.hexdigest() == manifest['source_digest']
        assert hashlib.sha256((base / 'source_snapshot/harness.py').read_bytes()).hexdigest() == manifest['harness_sha256']
        assert hashlib.sha256((DIRECTORY / 'cases_focus_v1.json').read_bytes()).hexdigest() == manifest['cases_file_sha256']
        db = sqlite3.connect(f'file:{DIRECTORY / "run/cost.sqlite"}?mode=ro', uri=True)
        states = db.execute('SELECT state,count(*) FROM calls WHERE instr(label,?)=1 GROUP BY state', (run+'/',)).fetchall()
        assert not any(state == 'pending' for state, _ in states)
        db.close()
        audits.append({'run_id': run, 'attempts': len(rows), 'unique_attempts': True,
            'exact_published_transcripts': True, 'all_chunk_audio_decoded': True,
            'duration_and_text_sidecars_match': True, 'no_missing_audio_judgments': True,
            'frozen_source_and_harness_verified': True, 'cost_states': dict(states)})
    base = DIRECTORY / 'run/flat-compression-probe-v1'
    manifest = json.loads((DIRECTORY / 'manifest_compression_probe_v1.json').read_text())
    assert manifest['status'] == 'completed' and manifest['attempts_recorded'] == 4
    assert hashlib.sha256((base / 'harness.py').read_bytes()).hexdigest() == manifest['harness_sha256']
    rows = [json.loads(path.read_text()) for path in base.glob('*/*/result.json')]
    assert len({(r['case'], r['arm']) for r in rows}) == 4
    for row in rows:
        assert row['answer'] == '\n\n'.join(e['text'] for e in row['events'])
        for event in row['events']:
            path = ROOT / event['path']
            assert path.with_suffix('.txt').read_text().strip() == event['text'].strip()
            assert abs(len(AudioSegment.from_file(path))/1000-event['audio_seconds']) < .001
            audio_count += 1
        assert (base / row['case'] / row['arm'] / 'judgment.json').exists()
        assert (base / row['case'] / 'original_judgment.json').exists()
    for record in manifest['inputs']:
        assert hashlib.sha256((ROOT / record['source_path']).read_bytes()).hexdigest() == record['sha256']
    db = sqlite3.connect(f'file:{DIRECTORY / "run/cost.sqlite"}?mode=ro', uri=True)
    pending = db.execute("SELECT count(*) FROM calls WHERE state='pending'").fetchone()[0]
    assert pending == 0
    states = dict(db.execute('SELECT state,count(*) FROM calls WHERE instr(label,?)=1 GROUP BY state',
                            ('flat-compression-probe-v1/',)))
    db.close()
    audits.append({'run_id': 'flat-compression-probe-v1', 'attempts': 4, 'unique_attempts': True,
        'exact_published_transcripts': True, 'all_chunk_audio_decoded': True,
        'duration_and_text_sidecars_match': True, 'no_missing_audio_judgments': True,
        'original_judgments': 2, 'harness_and_input_hashes_verified': True, 'cost_states': states})
    result = {'runs': audits, 'mp3_chunks_verified': audio_count,
        'limitations': ['No ASR or listening audit; text sidecars do not prove spoken-word fidelity.',
                        'First audio is server readiness; gaps simulate queued playback.']}
    result['global_pending_calls'] = pending
    result['baseline_returned_text_note'] = ('The 32 baseline full-script results append an empty unspoken '
        '**Reference** heading; judgments use exact emitted text.')
    result['v1_source_drift_note'] = ('Only unused analyze_streaming_performance.py changed externally during v1; '
        'original snapshot preserved. All other files matched at completion. V2 and probe source matched at completion.')
    (DIRECTORY / 'adaptive_speech_artifact_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
