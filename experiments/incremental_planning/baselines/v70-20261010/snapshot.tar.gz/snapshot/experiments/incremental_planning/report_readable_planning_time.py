"""Offline comparison of the original and readable three-request timing probes."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.branch_planning import parse_branch_state
from streaming.overview_planning import parse_overview

LEDGER = Path(__file__).resolve().parent / 'run'
OUT = LEDGER / 'listening-motion-live-v36-planning-readable-latency-v1'


def main():
    previous = json.loads((LEDGER / 'listening-motion-live-v36-planning-latency-v1/report.json').read_text())
    results = json.loads((OUT / 'results.json').read_text())
    manifest = json.loads((OUT / 'manifest.json').read_text())
    comparisons = []
    for result in results:
        before = next(r for r in previous['samples'] if r['source_call_id'] == result['source_call_id'])
        source = json.loads((LEDGER / f"call_{result['source_call_id']:06}.json").read_text())
        message = next(m['content'] for m in source['request']['messages'] if '{"context":' in m['content'])
        payload, _ = json.JSONDecoder().raw_decode(message[message.index('{"context":'):])
        parsed = json.loads(result['output'])
        for label, validate in (
            ('overview', lambda: parse_overview(parsed['overview'])),
            ('planning', lambda: parse_branch_state(result['output'], ' '.join(payload['heard_prefix']), payload['context'])),
        ):
            try:
                validate()
                result[label + '_schema_valid'] = True
            except (ValueError, KeyError, TypeError, IndexError) as exc:
                result[label + '_schema_valid'] = False
                result[label + '_schema_error'] = str(exc)
        comparisons.append(dict(source_call_id=result['source_call_id'],
            before_seconds=before['http_return_seconds'], after_seconds=result['http_return_seconds'],
            difference_seconds=result['http_return_seconds'] - before['http_return_seconds'],
            before_input_tokens=before['usage']['prompt_tokens'], after_input_tokens=result['usage']['prompt_tokens'],
            before_output_tokens=before['usage']['completion_tokens'], after_output_tokens=result['usage']['completion_tokens'],
            cached_tokens=result['usage'].get('prompt_tokens_details', {}).get('cached_tokens'),
            planning_schema_valid=result['planning_schema_valid'], overview_schema_valid=result['overview_schema_valid']))
    report = dict(run=manifest['run'], status=manifest['status'], samples=results, comparisons=comparisons,
        timing=dict(before_mean_seconds=sum(r['before_seconds'] for r in comparisons)/len(comparisons),
                    after_mean_seconds=sum(r['after_seconds'] for r in comparisons)/len(comparisons),
                    exceeded_3_seconds=sum(r['after_seconds'] > 3 for r in comparisons)),
        parameters=dict(model=source['request']['model'], temperature=source['request']['temperature'],
                        max_tokens=source['request']['max_tokens'], calls=3, repetitions_per_input=1,
                        timeout_seconds=60, retries=0, sequential=True),
        conclusion='All three completed; two still exceeded3s. No consistent latency reduction in this sample.',
        limitations=['Original and readable runs occurred at different times; service load was not controlled.',
                     'One sample per input is not a latency distribution or causal ablation.',
                     'Generated output lengths differ. Schema checks do not establish semantic quality.'],
        cost=dict(known_usage_estimate_usd=manifest['known_usage_usd'],
                  conservative_new_exposure_usd=manifest['conservative_exposure_usd'],
                  local_cap_usd=manifest['local_cap_usd'], global_cap_usd=manifest['global_cap_usd'],
                  cumulative_conservative_exposure_usd=manifest['ending_ledger']['accounted_exposure_usd'],
                  remaining_global_usd=manifest['global_cap_usd'] - manifest['ending_ledger']['accounted_exposure_usd'],
                  pending_requests=manifest['pending_calls'], settled_invoice=False))
    (OUT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'samples'}, indent=2))


if __name__ == '__main__':
    main()
