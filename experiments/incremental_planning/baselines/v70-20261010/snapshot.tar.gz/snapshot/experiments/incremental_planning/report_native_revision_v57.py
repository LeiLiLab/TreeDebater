"""Offline report for the corrected native-pipeline experiment."""
import csv
import json
import sqlite3
import statistics
from pathlib import Path

from report_revision_pipelines_v56 import exposure_query, repeated_spans

D = Path(__file__).resolve().parent
RUN = 'listening-motion-live-v52-refactor-native-revision-v57'
OUT = D / 'run' / RUN


def main():
    manifest = json.loads((OUT / 'manifest.json').read_text())
    rows, results = [], []
    for path in sorted(OUT.glob('*/result.json')):
        r = json.loads(path.read_text())
        results.append(r)
        if r['status'] != 'completed':
            continue
        profile = list(csv.DictReader((path.parent / 'speech_chunks/chunk_profile.csv').open()))[1:]
        audit = json.loads((path.parent / 'speech_chunks/rewrite_audit.json').read_text())
        published = [c for a in audit for c in a['candidates'] if c['published']]
        row = dict(policy=r['policy'], case=r['case'], repeat=r['repeat'], **r['metrics'])
        row.update(native_rewritten_chunks=sum(int(p['used_candidate_iter']) > 0 for p in profile),
                   raw_selected_chunks=sum(int(p['used_candidate_iter']) == 0 for p in profile),
                   audited_published_rewrites=sum(not p['source_unchanged'] for p in published),
                   speculative_tts=sum(e['kind'] == 'stream_audio_ready' for e in r['speculative_audio']),
                   reused_speculative_tts=sum(e['kind'] == 'reused_stream_audio' for e in r['speculative_audio']),
                   first_buffer_margin_seconds=r['chunks'][0]['audio_seconds']-r['metrics']['first_body_audio_seconds'],
                   repeated_8grams=len(repeated_spans([c['text'] for c in r['chunks']])))
        rows.append(row)
    policies = {}
    for policy in manifest['policy_caps_usd']:
        subset = [r for r in rows if r['policy'] == policy]
        if not subset:
            continue
        fields = ['first_body_audio_seconds', 'first_body_after_feedback_seconds', 'final_audio_ready_seconds',
                  'total_playback_gap_seconds', 'first_buffer_margin_seconds']
        policies[policy] = dict(runs=len(subset),
            runs_with_gap=sum(r['max_playback_gap_seconds'] > .01 for r in subset),
            duration_within_5pct=sum(abs(r['duration_error_pct']) <= 5 for r in subset),
            median_abs_error_seconds=statistics.median(abs(r['signed_duration_error_seconds']) for r in subset),
            median_abs_error_pct=statistics.median(abs(r['duration_error_pct']) for r in subset),
            measurements={k: dict(median=statistics.median(r[k] for r in subset), min=min(r[k] for r in subset), max=max(r[k] for r in subset)) for k in fields},
            totals={k: sum(r[k] for r in subset) for k in ['text_calls', 'chunks', 'native_rewritten_chunks', 'raw_selected_chunks', 'speculative_tts', 'reused_speculative_tts']})
    db = sqlite3.connect('file:' + str(D / 'run/cost.sqlite') + '?mode=ro', uri=True)
    costs = {}
    scopes = [('experiment', RUN+'/', 12), ('parent', 'listening-motion-live-v52-refactor', 50)]
    scopes += [(p, RUN+'/'+p+'/', 6) for p in policies]
    for name, prefix, cap in scopes:
        groups = db.execute('select state,count(*),coalesce(sum(estimated_usd),0) from calls where instr(label,?)=1 group by state', (prefix,)).fetchall()
        exposure = db.execute(exposure_query(' WHERE instr(c.label,?)=1'), (prefix,)).fetchone()[0]
        audio_calls = 0
        for ident, in db.execute("select id from calls where instr(label,?)=1 and label like '%/tts'", (prefix,)):
            artifact = json.loads((D / 'run' / f'call_{ident:06}.json').read_text())
            audio_calls += len(artifact.get('external_calls', []))
        costs[name] = dict(known_usage_estimate_usd=sum(g[2] for g in groups),
            states={g[0]: g[1] for g in groups}, conservative_exposure_usd=exposure,
            cap_usd=cap, remaining_conservative_usd=cap-exposure, tts_requests=audio_calls)
    db.close()
    common = set.intersection(*[{(r['case'],r['repeat']) for r in rows if r['policy']==p} for p in policies])
    paired = {}
    for p in policies:
        rs = [r for r in rows if r['policy']==p and (r['case'],r['repeat']) in common]
        if rs:
            paired[p] = dict(runs=len(rs), first_body_audio_median=statistics.median(r['first_body_audio_seconds'] for r in rs),
                median_abs_duration_error_seconds=statistics.median(abs(r['signed_duration_error_seconds']) for r in rs),
                within_5pct=sum(abs(r['duration_error_pct'])<=5 for r in rs), runs_with_gap=sum(r['max_playback_gap_seconds']>.01 for r in rs))
    failures = [dict(policy=r['policy'],case=r['case'],repeat=r['repeat'],error=r.get('error')) for r in results if r['status']!='completed']
    summary = dict(status=json.loads((OUT/'progress.json').read_text())['status'], completed_runs=len(rows), failed_runs=failures, paired_comparison=paired,
        policies=policies, costs=costs, rows=rows, limitations=[manifest['boundaries'],
        'Three frozen cases from one motion, two repeats each; no fresh retrieval, feedback, ASR or live browser playback.',
        'Gaps are simulated from real completion timestamps and decoded audio duration. Prefix starts the timing clock.',
        'Scheme 1 speculatively synthesizes streamed paragraphs, but native publication waits for the complete draft.',
        'Scheme 2 preserves the optional native rewrite trigger; a raw paragraph can be selected without evidence editing.',
        'Costs are usage/rate estimates, not settled invoices; parent exposure retains earlier uncertain charges.'])
    (OUT/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    if rows:
        with (OUT/'timing.csv').open('w') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    texts = ['v57 corrected comparison: final published speech text', manifest['boundaries']]
    for r in sorted(results, key=lambda r: (r['case'],r['repeat'],r['policy'])):
        texts += ['='*70, f"{r['policy']} | {r['case']} | repeat {r['repeat']} | {r['status']}",
                  json.dumps(r.get('metrics', {})), r.get('text', r.get('error', ''))]
    (OUT/'comparison.txt').write_text('\n\n'.join(texts)+'\n')
    review = dict(method='Manual reading of final published text against frozen supplied excerpts; no external truth verification or paid judge.',
        findings=[
            'Both policies retain the original speaker position and use supplied evidence, but neither establishes a general content-quality win on these three cases.',
            'Both opening repeats in both policies reuse the unsupported cognitive-load-theory claim supplied by feedback. The feedback sentence is not source evidence.',
            'Whole-stream opening outputs extrapolate the editing-time survey into proof that manual composition has diminishing value; the excerpt does not establish that conclusion.',
            'Paragraph opening outputs cite Frontiers and Insights KSA, but broaden a comparison with assessment item writing into a comparison with traditional writing in general.',
            'Paragraph case22963_r1 adds Brennan Center evidence; its repeat drops that reference. The r1 epistemic-vigilance attribution comes from selection_reason, not the supplied source excerpt.',
            'Whole-stream case22963 repeats keep the Digital Future Center reference, with unsupported inevitability/necessity claims surrounding it. The r2 epistemic-vigilance phrase likewise lacks support in the source excerpt.',
            'Paragraph case22990 repeats duplicate the linguistic-nuance/factual-accuracy sentence across adjacent chunks, despite preceding-text context. Both repeat the domain-expertise point too.',
            'Paragraph raw-candidate retention can discard already-generated evidence-bearing proposals. Final published text, rather than candidate drafts, is the comparison basis.',
            'Whole-stream native length edits can restructure and expand evidence-bearing prose; speculative audio not exactly matching native chunks is unused.'
        ])
    (OUT/'quality_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
    lines = ['v57：保留原有自适应时长处理后的两方案对照',
             '本轮替代 v56 的比较结论；v56 误移除了原有时长调整，不能代表用户要求的方案。',
             '范围：同一辩题的 3 个冻结案例，每方案重复 2 次，目标均为 240 秒。真实 LLM/TTS 请求；使用实际音频长度与完成时间模拟播放，未跑完整新辩论。',
             '共同保留：原始候选、时长估计、多轮长度改写、候选选择、播放截止时间、尾段预启动、原有并发和回退机制。',
             '方案一：B 整篇流式证据改写，段落结束即预合成 TTS，之后由原流水线执行长度处理；原流水线仍等全文到齐才发布正文。',
             '方案二：直接将未改写全文交给原流水线；在原有分段长度改写调用中加入全局反馈、证据、全文、已提交段和下一段。长度合适或回退时可能直接保留原段。',
             f"运行状态：{summary['status']}；完成 {len(rows)}/12。失败结果排除在下列成功样本性能统计之外，费用仍计入。",
             '最后一个方案一样本的一次 TTS 请求发生错误，具体 HTTP 状态未保存在旧 transport 日志；保护机制停止后续派发，无自动重试。预算未触顶，所有请求已结束。' if failures else '', '',
             '指标（时间为中位数；首段音频从开头预制段开始播放计时，包含冻结的反馈等待）：',
             '方案 | 首段音频可用 | 反馈后等待 | 全部音频可用 | 绝对时长误差 | ±5%内 | 有断档样本']
    for p, label in [('whole_stream_native','一'),('paragraph_evidence_native','二')]:
        if p not in policies:
            continue
        s=policies[p]; m=s['measurements']
        lines.append(f"{label} | {m['first_body_audio_seconds']['median']:.2f}s | {m['first_body_after_feedback_seconds']['median']:.2f}s | {m['final_audio_ready_seconds']['median']:.2f}s | {s['median_abs_error_seconds']:.2f}s ({s['median_abs_error_pct']:.2f}%) | {s['duration_within_5pct']}/{s['runs']} | {s['runs_with_gap']}/{s['runs']}")
        lines.append(f"  正文块 {s['totals']['chunks']}；原长度流程采用改写 {s['totals']['native_rewritten_chunks']}；采用原候选 {s['totals']['raw_selected_chunks']}；文本调用 {s['totals']['text_calls']}；TTS 请求 {costs[p]['tts_requests']}；估算费用 ${costs[p]['known_usage_estimate_usd']:.6f}。")
    lines += ['', '完整配对样本比较：', json.dumps(paired,ensure_ascii=False), '', '逐例时长与断档：']
    for r in sorted(rows,key=lambda r:(r['case'],r['repeat'],r['policy'])):
        lines.append(f"{r['case']} r{r['repeat']} {r['policy']}: {r['audio_seconds']:.3f}s, gap={r['total_playback_gap_seconds']:.3f}s, repeated_8grams={r['repeated_8grams']}")
    lines += ['', '人工内容复核：']+review['findings']
    lines += ['', '局限：']+summary['limitations']
    lines += ['', f"本轮使用量估算 ${costs['experiment']['known_usage_estimate_usd']:.6f}，本轮上限 $12。累计使用量估算 ${costs['parent']['known_usage_estimate_usd']:.6f}；按含旧异常请求和保守系数的占用计算，$50 总预算剩余 ${costs['parent']['remaining_conservative_usd']:.6f}。费用未与账单结算。"]
    (OUT/'report.txt').write_text('\n\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k != 'rows'},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
