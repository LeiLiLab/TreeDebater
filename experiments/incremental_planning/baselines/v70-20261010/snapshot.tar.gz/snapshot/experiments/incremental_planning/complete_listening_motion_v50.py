"""Replay v50's truncated closing through bounded repair; preserve live failure."""
import argparse
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path

import benchmark_listening_motion_live as live
from streaming.experiment_accounting import reconcile_success

SOURCE = live.LEDGER / 'listening-motion-live-v50-retrieval'
RUN = 'listening-motion-live-v50-retrieval/completion-v1'
OUT = SOURCE / 'completion-v1'
LOCAL_CAP = 1.5


def plan():
    original = json.loads((live.D/'manifest_listening-motion-live-v50-retrieval.json').read_text())
    assert original['status'] == 'stopped' and original['completed_turns'] == 5
    assert original['budget_stop'] is None
    budget = live.ledger_summary()
    assert budget['pending_calls'] == 0
    paths = [SOURCE/'history.json', SOURCE/'listener_views.json',
             SOURCE/'05_closing_against/result.json', live.LEDGER/'call_022628.json']
    views = json.loads(paths[1].read_text())['against']
    assert views == json.loads(paths[2].read_text())['history'] and len(views) == 5
    return dict(status='approved', run_id=RUN, motion=original['motion'],
        authorization='User authorized one motion with retrieval, cumulative USD60, then requested native evidence selection reuse and testing/analysis. Finish only the failed closing within the same cumulative cap; no full match rerun.',
        scope='Reuse five completed speeches and exact saved final listener history. Seed the recorded malformed draft locally, then execute the production single repair, semantic publication review and real TTS.',
        restoration='Fresh AGAINST player uses native saved claim/evidence preparation and the complete five-turn listener history. Derived trees and speculative audio are not restored. This is closing artifact completion, not continuous live timing validation.',
        expected_additional_usd=[.05, .30], local_cap_usd=LOCAL_CAP, cumulative_validation_cap_usd=60,
        global_cap_usd=live.CAP, study_cap_usd=live.STUDY_CAP,
        prices=dict(gemma_input_per_million=.13, gemma_output_per_million=.40, tts_per_million_characters=15),
        prices_checked_utc='2026-10-08', price_sources=['https://aws.amazon.com/bedrock/pricing/', 'https://developers.openai.com/api/docs/models/tts-1'],
        guard='Nested SQLite USD1.50 reservation cap plus existing v50, combined USD60, study and global guards. One USD1 TTS bundle. No SDK retries, no automatic restart; stop on error.',
        source_digest=live.code_digest(), harness_sha256=live.digest(__file__),
        live_harness_sha256=live.digest(live.__file__),
        sources={str(p):live.digest(p) for p in paths}, starting_ledger=budget)


def execute():
    m = json.loads((OUT/'manifest.json').read_text())
    assert m['status'] == 'approved'
    assert m['source_digest'] == live.code_digest() and m['harness_sha256'] == live.digest(__file__)
    assert m['live_harness_sha256'] == live.digest(live.__file__)
    for path, sha in m['sources'].items():
        assert live.digest(path) == sha
    snapshot = OUT/'source_snapshot'
    hashes = {}
    for path in sorted((live.ROOT/'src').rglob('*.py')):
        dest = snapshot/path.relative_to(live.ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(path.read_bytes())
        hashes[str(path.relative_to(live.ROOT))] = live.digest(path)
    live.atomic_json(snapshot/'files.json', hashes)
    (snapshot/'harness.py').write_bytes(Path(__file__).read_bytes())
    live.RUN, live.OUT = RUN, OUT
    budget = live.BudgetedClient(live.LEDGER, cap=live.CAP)
    live.arm_study_guard(budget.db)
    live.arm_study_guard(budget.db, 'listening-motion-live-v50-retrieval/', 60.)
    m['guard_trigger'] = live.arm_study_guard(budget.db, RUN+'/', LOCAL_CAP)
    budget.db.close()
    for key, value in json.loads((live.ROOT/'src/configs/api_key.json').read_text()).items():
        os.environ.setdefault(key, value)
    os.environ['DEBATE_LLM_API_BASE'] = 'http://127.0.0.1:4000/v1'
    import httpx
    import litellm
    import openai
    from pydub import AudioSegment
    import tts_streaming
    from debate_tree import Tree
    from streaming.listening_prefix import material, speak_with_listening_prefix
    def blocked(*args, **kwargs):
        raise RuntimeError('Unmetered request blocked')
    litellm.completion = blocked
    Tree.get_most_similar_node = lambda *args, **kwargs: (None, 0.)
    meter, guards, clients = live.Meter(), [], []
    original_factory, original_request = tts_streaming.OpenAI, tts_streaming._text_request
    m.update(status='running', launched_utc=datetime.now(timezone.utc).isoformat())
    live.atomic_json(OUT/'manifest.json', m)
    try:
        history = json.loads((SOURCE/'listener_views.json').read_text())['against']
        live.atomic_json(OUT/'listener_history.json', history)
        player = live.new_player('against', m['motion'], meter)
        player.status = 'closing'
        for entry in history:
            player._add_message('assistant' if entry['side']=='against' else 'user', entry['content'])
        player.planner.turn = 'for:closing'
        player.planner.chunks = [history[-1]['content']]
        player.use_debate_flow_tree = False
        folder = OUT/'05_closing_against'
        folder.mkdir()
        player.audio_output_dir = str(folder)
        cached = [json.loads((live.LEDGER/'call_022628.json').read_text())['response']['choices'][0]['message']['content']]
        real_helper = player.helper_client
        def helper(*, prompt, **kwargs):
            if prompt.startswith('LISTENING PREFIX DRAFT:') and cached:
                m['cached_malformed_response_reused'] = True
                return [cached.pop()]
            return real_helper(prompt=prompt, **kwargs)
        player.helper_client = helper
        live.atomic_json(folder/'input.json', material(player, 'closing', history))
        guard = live.AudioGuard(live.LEDGER, RUN+'/turn_5/tts', allowance=1., approved_cap=live.CAP, max_requests=128)
        guards.append(guard)
        def factory(**kwargs):
            client = openai.OpenAI(http_client=httpx.Client(transport=guard, timeout=60),
                max_retries=0, base_url='https://api.openai.com/v1', timeout=60)
            clients.append(client)
            return client
        tts_streaming.OpenAI = factory
        tts_streaming._text_request = live.metered_tts_text_request(meter)
        player.tts_chunk_callback = lambda i,p,t,d: print(json.dumps(dict(event='audio_ready', chunk=i, seconds=d)), flush=True)
        content = speak_with_listening_prefix(player, 120, copy.deepcopy(history), player.streaming_output_config, {}, stage='closing')
        guard.finish()
        reconcile_success(guard.db, guard.request_id, guard.path)
        audio = Path(player._speech_audio_file(stage='closing'))
        result = dict(status='completed', stage='closing', side='against', content=content,
            audio=str(audio), audio_seconds=len(AudioSegment.from_file(audio))/1000,
            live_timing_comparable=False, original_live_status='stopped')
        live.atomic_json(folder/'result.json', result)
        full_history = json.loads((SOURCE/'history.json').read_text())+[dict(stage='closing', side='against', content=content)]
        live.atomic_json(OUT/'completed_history.json', full_history)
        m.update(status='completed', completed_speeches=6, original_live_status='stopped',
                 closing_audio_seconds=result['audio_seconds'])
    except BaseException as exc:
        meter.stopped.set()
        m.update(status='failed', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        meter.stopped.set()
        for guard in guards:
            guard.finish()
        for client in clients:
            client.close()
        tts_streaming.OpenAI, tts_streaming._text_request = original_factory, original_request
        m.update(finished_utc=datetime.now(timezone.utc).isoformat(), ending_ledger=live.ledger_summary())
        live.atomic_json(OUT/'manifest.json', m)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    if parser.parse_args().execute:
        execute()
    else:
        metadata = plan()
        OUT.mkdir(exist_ok=False)
        live.atomic_json(OUT/'manifest.json', metadata)
        print(json.dumps({key:metadata[key] for key in ('scope','expected_additional_usd','local_cap_usd')}, indent=2))
