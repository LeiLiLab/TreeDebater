"""Offline paired report and decoded-audio verification for scheme 1 v58."""
import csv
import json
from pathlib import Path
import sqlite3
import statistics

from report_revision_pipelines_v56 import exposure_query, repeated_spans

D=Path(__file__).resolve().parent
RUN='listening-motion-live-v52-refactor-streamed-revision-v58'
OUT=D/'run'/RUN
PRIOR=D/'run/listening-motion-live-v52-refactor-native-revision-v57'
VERSION='v58'


def aggregate(rows):
    if not rows:return dict(runs=0)
    return dict(runs=len(rows),first_body_audio_median=statistics.median(r['first_body_audio_seconds'] for r in rows),
        all_audio_ready_median=statistics.median(r['final_audio_ready_seconds'] for r in rows),
        abs_duration_error_median=statistics.median(abs(r['signed_duration_error_seconds']) for r in rows),
        abs_duration_error_pct_median=statistics.median(abs(r['duration_error_pct']) for r in rows),
        within_5pct=sum(abs(r['duration_error_pct'])<=5 for r in rows),
        runs_with_gap=sum(r['max_playback_gap_seconds']>.01 for r in rows),
        worst_gap=max(r['max_playback_gap_seconds'] for r in rows))


def main():
    from pydub import AudioSegment
    results=[json.loads(p.read_text()) for p in sorted(OUT.glob('*/result.json'))]
    rows=[]
    for r in results:
        if r['status']!='completed':continue
        decoded=sum(len(AudioSegment.from_file(c['path']))/1000 for c in r['chunks'])
        assert abs(decoded-r['metrics']['audio_seconds'])<.02
        cursor=r['chunks'][0]['ready_seconds'];gap_sum=0
        for c in r['chunks']:
            gap=max(0,c['ready_seconds']-cursor);gap_sum+=gap
            cursor=max(cursor,c['ready_seconds'])+c['audio_seconds']
        assert abs(gap_sum-r['metrics']['total_playback_gap_seconds'])<.003
        rows.append(dict(case=r['case'],repeat=r['repeat'],attempt=r.get('attempt',1),**r['metrics'],
            repeated_8grams=len(repeated_spans([c['text'] for c in r['chunks']]))))
    baseline=[]
    for p in PRIOR.glob('whole_stream_native*/result.json'):
        r=json.loads(p.read_text())
        if r['status']=='completed':baseline.append(dict(case=r['case'],repeat=r['repeat'],**r['metrics']))
    common={(r['case'],r['repeat']) for r in rows}&{(r['case'],r['repeat']) for r in baseline}
    paired={label:aggregate([r for r in values if (r['case'],r['repeat']) in common])
            for label,values in [('v57',baseline),(VERSION,rows)]}
    db=sqlite3.connect('file:'+str(D/'run/cost.sqlite')+'?mode=ro',uri=True)
    costs={}
    for label,prefix,cap in [('experiment',RUN+'/',8),('parent','listening-motion-live-v52-refactor',50)]:
        groups=db.execute('select state,count(*),coalesce(sum(estimated_usd),0) from calls where instr(label,?)=1 group by state',(prefix,)).fetchall()
        exposure=db.execute(exposure_query(' WHERE instr(c.label,?)=1'),(prefix,)).fetchone()[0]
        costs[label]=dict(known_usage_estimate_usd=sum(g[2] for g in groups),states={g[0]:g[1] for g in groups},
            conservative_exposure_usd=exposure,cap_usd=cap,remaining_conservative_usd=cap-exposure)
    pending=db.execute("select count(*) from calls where instr(label,?)=1 and state='pending'",(RUN+'/',)).fetchone()[0]
    errors=[]
    for ident, in db.execute("select id from calls where instr(label,?)=1 and state='error'",(RUN+'/',)):
        artifact=json.loads((D/'run'/f'call_{ident:06}.json').read_text())
        errors.append(dict(ledger_id=ident,error=artifact.get('error'),
            audio_errors=[e for e in artifact.get('external_calls',[]) if e['state']!='ok']))
    db.close()
    summary=dict(status=json.loads((OUT/'progress.json').read_text())['status'],
        completed_runs=len(rows),failed_attempts=sum(r['status']!='completed' for r in results),
        first_body_before_revision_complete=sum(r['first_body_before_revision_complete'] for r in rows),
        all_successful=aggregate(rows),paired=paired,rows=rows,costs=costs,errors=errors,pending_requests=pending,
        validation=dict(decoded_audio_runs=len(rows),related_offline_tests=271,audio_guard_tests=15),
        limitations=['Historical v57 comparison on fixed material from one motion; no fresh retrieval, ASR, feedback or full debate.',
            'Both prompt and streaming handoff changed; this does not isolate their individual effects.',
            'Playback gaps are simulated from real request timestamps and decoded audio.',
            'Failed attempts stay in cost accounting but are excluded from successful timing statistics.'])
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    if rows:
        with (OUT/'timing.csv').open('w') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    text=[VERSION+' actual final speech outputs; failed attempts are retained separately.']
    for r in sorted(results,key=lambda r:(r['case'],r['repeat'],r.get('attempt',1))):
        text += ['='*70,f"case {r['case']} repeat {r['repeat']} attempt {r.get('attempt',1)} {r['status']}",
                 json.dumps(r.get('metrics',{})),r.get('text',r.get('error',''))]
    (OUT/'comparison.txt').write_text('\n\n'.join(text)+'\n')
    lines=['方案一改进验证 '+VERSION,
        '改动：完整段落按固定边界送入原生控时/TTS，正文无需等全文；后文未到齐时保留估算预算，全文到齐后按实际剩余文本分配。保留原候选、长度改写、截止时间和回退。反馈与选材理由不作事实来源，来源结论与发言推论分开。',
        f"状态：{summary['status']}，完成 {len(rows)}/6，失败尝试 {summary['failed_attempts']}，待结束请求 {pending}。",
        f"正文首段在全文完成前发布：{summary['first_body_before_revision_complete']}/{len(rows)}。",'同案例配对比较（中位数）：']
    for label,s in paired.items():
        if not s['runs']:continue
        lines.append(f"{label}: {s['runs']}例；首段音频 {s['first_body_audio_median']:.2f}s；全部音频 {s['all_audio_ready_median']:.2f}s；总时长绝对误差 {s['abs_duration_error_median']:.2f}s；±5%内 {s['within_5pct']}/{s['runs']}；有断档 {s['runs_with_gap']}/{s['runs']}，最大 {s['worst_gap']:.2f}s。")
    lines+=['逐例：',json.dumps(rows,ensure_ascii=False,indent=2),'费用（使用量估算，未结算）：',json.dumps(costs,indent=2),
            '请求错误：',json.dumps(errors,indent=2),'局限：']+summary['limitations']
    (OUT/'report.txt').write_text('\n\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('rows','errors')},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
