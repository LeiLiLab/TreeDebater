"""Evidence-preparation validation, sharing the existing cumulative USD20 guard."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys

import run_refactor_debate_v52 as guarded

live = guarded.live
RECORD = live.D / 'prepared_full_debate_v53_evidence.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    record = json.loads(RECORD.read_text())
    if record['source_digest'] != live.code_digest():
        raise ValueError('Prepared source has changed')
    if record['output_config'] != asdict(live.CONFIG):
        raise ValueError('Prepared output configuration has changed')
    if record['input_config'] != asdict(live.INPUT_CONFIG):
        raise ValueError('Prepared input configuration has changed')
    if record['audio_guard_sha256'] != live.digest(live.D/'audio_probe.py'):
        raise ValueError('Prepared audio guard has changed')
    if record['harness_sha256'] != live.digest(live.__file__):
        raise ValueError('Prepared harness has changed')
    for path, digest in record['input_sources'].items():
        if live.digest(path) != digest:
            raise ValueError('Prepared input pool has changed')
    if Path(record['output_directory']).exists():
        raise ValueError('Run directory already exists; no automatic restart')
    if not args.execute:
        print(json.dumps(dict(status=record['status'], run_id=record['run_id'],
            motion=record['motion'], estimate_usd=record['estimate_usd'],
            config_verified=True, billable_requests=0), indent=2))
        return
    if record['status'] != 'approved' or not record.get('authorization'):
        raise ValueError('This new validation requires recorded budget approval')
    manifest = guarded.configure(RECORD)
    manifest.update(authorization=record['authorization'],
        launch_wrapper=str(Path(__file__).resolve()), launch_wrapper_sha256=live.digest(__file__),
        evidence_preparation=dict(enabled=True, max_selection_rounds=3,
            supplement_candidate_limit=20, duplicate_ids_excluded=True),
        comparison_baseline='listening-motion-live-v52-refactor-recovery1')
    manifest['retrieval']['selected_evidence'] = 'Native selection while listening; cached IDs reused and excluded from incremental supplements'
    manifest['metrics'] += ['evidence selection timing, retained/additional IDs and requests',
                            'body revision and first body TTS timing']
    live.atomic_json(live.MANIFEST, manifest)
    sys.argv = [str(Path(live.__file__)), '--execute']
    try:
        live.main()
    finally:
        if live.OUT.exists():
            (live.OUT/'launch_wrapper.py').write_bytes(Path(__file__).read_bytes())
            (live.OUT/'guard_wrapper.py').write_bytes(Path(guarded.__file__).read_bytes())


if __name__ == '__main__':
    main()
