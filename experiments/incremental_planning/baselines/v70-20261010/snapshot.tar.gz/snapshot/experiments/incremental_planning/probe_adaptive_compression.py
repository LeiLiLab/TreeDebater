"""Fixed-text 30s compression stress test, separate from full-speech comparisons."""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace
import time

import httpx
from pydub import AudioSegment

import benchmark_adaptive_speech_v2 as budget
from streaming.config import OutputConfig

RUN = 'flat-compression-probe-v1'
LIMIT = 6.0
DIRECTORY = budget.DIRECTORY
OUTPUT = budget.LEDGER / RUN
MANIFEST = DIRECTORY / 'manifest_compression_probe_v1.json'
CASE_IDS = ['focus_lecture_recordings', 'focus_riverside_stall']
# Reuse the tested thread-owned ledger client, with this probe's independent cap.
budget.RUN = RUN
budget.LIMIT = LIMIT


def inputs():
    records = []
    for case_id in CASE_IDS:
        path = budget.LEDGER / 'flat-full-adaptive-v1' / case_id / '0/fixed_prefix8/result.json'
        source = json.loads(path.read_text())
        trace = source['fixed_prefix_trace']
        records.append({'case': case_id, 'prefix': trace['fixed_prefix'], 'tail': trace['revised_tail'],
                        'source_path': str(path.relative_to(budget.ROOT)), 'sha256': budget.digest(path)})
    return records


def config(verified):
    raise RuntimeError("Retired comparison: verify_rewrites no longer controls a semantic review. Use the historical source snapshot to reproduce it.")
    # Saved text is supplied directly to TTS; no speech-generation mode is used.
    return OutputConfig(budget_mode='audio_duration', adaptive_delivery=True,
        first_chunk_seconds=8, later_chunk_seconds=30, max_refinements=2, early_max_refinements=1,
        max_parallel_tts=1, refinement_model=budget.MODEL, allow_expansion=False)


def prepare():
    manifest = {'run_id': RUN, 'status': 'prepared', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'source_digest': budget.code_digest(), 'harness_sha256': budget.digest(Path(__file__)),
        'shared_harness_sha256': budget.digest(Path(budget.__file__)), 'inputs': inputs(),
        'cases_file_sha256': budget.digest(DIRECTORY / 'cases_focus_v1.json'),
        'authorization': 'Existing user-approved cumulative USD200 task budget, no increase.',
        'configuration': {'attempts': 4, 'budget_seconds': 30, 'arms': ['unchecked', 'checked'],
                          'configs': {name: asdict(config(name=='checked')) for name in ['unchecked', 'checked']},
                          'source': 'Exact saved pre-TTS fixed-prefix drafts from v1; no new full-text generation.',
                          'models': {'rewrite_and_check': budget.MODEL, 'judge': 'gpt-5.6-sol', 'tts': 'tts-1 echo'},
                          'judgments': 'Two originals plus four exact delivered transcripts; same frozen case rubric.'},
        'estimate_usd': {'expected': [.1, .4], 'conservative_usage_planning': 2, 'run_exposure_stop': LIMIT,
                         'cumulative_cap': 200, 'tts_bundles': 4, 'tts_bundle_reservation': 1,
                         'max_audio_http_calls_per_bundle': 24, 'max_judgments': 6},
        'rates': {**budget.MODEL_RATES, 'tts-1_per_million_characters': 15},
        'price_sources': ['https://aws.amazon.com/bedrock/pricing/',
                         'https://developers.openai.com/api/docs/models/tts-1'],
        'guard': 'Shared persistent SQLite bounds before every dispatch; run USD6 and cumulative USD200; '
                 'all workers settle before bundle finish; no automatic restart or answer retries.',
        'limitations': ['Two selected diagnostic cases and one TTS/model draw per arm, not a quality benchmark.',
                        'Shorter budget deliberately triggers compression; timing does not measure whole-speech generation.',
                        'Automatic meaning checker and judges remain fallible; rejected edits preserve original audio even if over budget.',
                        'Exact text sidecars and MP3 decode, no ASR or browser listening.']}
    budget.atomic_json(MANIFEST, manifest)
    return manifest


def synthesize(record, verified, client):
    import openai
    import tts_streaming as tts
    arm = 'checked' if verified else 'unchecked'
    directory = OUTPUT / record['case'] / arm
    directory.mkdir(parents=True, exist_ok=False)
    cfg = config(verified)
    budget.require_room(client, 1)
    audio_label = f'{RUN}/{record["case"]}/{arm}/audio'
    refinement_label = f'{RUN}/{record["case"]}/{arm}/refinement'
    guard = budget.AudioGuard(budget.LEDGER, audio_label, allowance=1)
    clients = []
    real_openai = openai.OpenAI
    def factory(**kwargs):
        sdk = real_openai(http_client=httpx.Client(transport=guard, timeout=60), max_retries=0,
                          base_url='https://api.openai.com/v1', timeout=60)
        def rewrite(**request):
            if request['model'] != budget.MODEL:
                raise ValueError('Unpriced refinement model blocked')
            content = client.complete_at(refinement_label, request['messages'], temperature=0,
                max_tokens=min(1600, request.get('max_completion_tokens', 1600)), model=budget.MODEL,
                json_mode=request.get('response_format', {}).get('type') == 'json_object')
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=content))])
        sdk.chat.completions.create = rewrite
        clients.append(sdk)
        return sdk
    old_factory = tts.OpenAI
    tts.OpenAI = factory
    started, events, error = time.perf_counter(), [], None
    def emit(index, path, text, duration):
        decoded = len(AudioSegment.from_file(path))/1000
        assert decoded > 0 and abs(decoded-duration) < .1
        events.append({'index': index, 'path': str(Path(path).relative_to(budget.ROOT)),
                       'text': text, 'audio_seconds': decoded, 'ready_seconds': time.perf_counter()-started})
        budget.atomic_json(directory / 'events.json', events)
    def validate(index, text):
        if index == 0 and text != record['prefix']:
            raise ValueError('Fixed opening changed')
    case = next(c for c in budget.cases() if c['id']==record['case'])
    try:
        tts.convert_text_to_speech_streaming(record['prefix'], str(directory / 'speech.mp3'), 30,
            config=cfg, on_chunk=emit, tail_supplier=lambda: record['tail'], validate_chunk=validate,
            motion=case['motion'], side=case['side'])
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        for sdk in clients:
            sdk.close()
        guard.finish()
        tts.OpenAI = old_factory
    import csv
    profiles = directory / 'speech_chunks/chunk_profile.csv'
    audit = directory / 'speech_chunks/rewrite_audit.json'
    result = {'case': record['case'], 'arm': arm, 'source_text': record['prefix']+'\n\n'+record['tail'],
        'answer': '\n\n'.join(e['text'] for e in events), 'events': events,
        'audio_seconds': sum(e['audio_seconds'] for e in events), 'error': error,
        'status': 'failed_partial' if error and events else 'failed_silent' if error else 'returned',
        'chunk_profiles': list(csv.DictReader(profiles.open())) if profiles.exists() else [],
        'rewrite_audit': json.loads(audit.read_text()) if audit.exists() else [],
        'audio_usage': client.summary(audio_label), 'refinement_usage': client.summary(refinement_label)}
    budget.atomic_json(directory / 'result.json', result)
    print(json.dumps({'event': 'probe_done', 'case': record['case'], 'arm': arm,
                      'audio_seconds': result['audio_seconds'], 'status': result['status']}), flush=True)
    if error and error['type']=='BudgetExceeded':
        raise budget.BudgetExceeded(error['message'])
    if result['answer']:
        client.label = f'{RUN}/{record["case"]}/{arm}/judge'
        try:
            verdict = budget.judge(case, result['answer'], client, model='gpt-5.6-sol', max_tokens=1600)
            budget.atomic_json(directory / 'judgment.json', verdict)
        except budget.BudgetExceeded:
            raise
        except Exception as exc:
            budget.atomic_json(directory / 'judge_error.json', {'type': type(exc).__name__, 'message': str(exc)})
    return result


def main():
    raise SystemExit("Retired: checked/unchecked rewrite comparison is no longer supported; use the historical snapshot.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    if not parser.parse_args().execute:
        print(json.dumps(prepare(), indent=2))
        return
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['source_digest'] == budget.code_digest()
    assert manifest['harness_sha256'] == budget.digest(Path(__file__))
    assert manifest['shared_harness_sha256'] == budget.digest(Path(budget.__file__))
    assert manifest['cases_file_sha256'] == budget.digest(DIRECTORY / 'cases_focus_v1.json')
    assert manifest['inputs'] == inputs()
    OUTPUT.mkdir(exist_ok=False)
    for name in ('OPENAI_API_KEY', 'DEBATE_LLM_API_KEY'):
        keys = json.loads((budget.ROOT / 'src/configs/api_key.json').read_text())
        if name in keys:
            os.environ.setdefault(name, keys[name])
    os.environ['DEBATE_LLM_API_BASE'] = 'http://127.0.0.1:4000/v1'
    (OUTPUT / 'harness.py').write_bytes(Path(__file__).read_bytes())
    # Same source as the completed safety retest; retain its independent snapshot reference.
    v2 = json.loads((DIRECTORY / 'manifest_adaptive_speech_v2.json').read_text())
    assert v2['status']=='completed' and v2['source_digest']==manifest['source_digest']
    manifest['source_snapshot'] = 'run/flat-full-adaptive-v2/source_snapshot'
    client = budget.ThreadedClient(budget.LEDGER, label=RUN+'/initialization')
    manifest.update(status='running', launched_utc=datetime.now(timezone.utc).isoformat())
    budget.atomic_json(MANIFEST, manifest)
    results = []
    try:
        for index, record in enumerate(inputs()):
            case = next(c for c in budget.cases() if c['id']==record['case'])
            client.label = f'{RUN}/{record["case"]}/original/judge'
            verdict = budget.judge(case, record['prefix']+'\n\n'+record['tail'], client,
                                   model='gpt-5.6-sol', max_tokens=1600)
            budget.atomic_json(OUTPUT / record['case'] / 'original_judgment.json', verdict)
            for verified in ([False, True] if index==0 else [True, False]):
                results.append(synthesize(record, verified, client))
        manifest['status']='completed'
    except BaseException as exc:
        manifest.update(status='stopped', stop_error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        manifest.update(finished_utc=datetime.now(timezone.utc).isoformat(), attempts_recorded=len(results),
                        run_exposure_usd=budget.run_exposure(client), ending_ledger=client.summary())
        budget.atomic_json(MANIFEST, manifest)
        client.db.close()


if __name__ == '__main__':
    main()
