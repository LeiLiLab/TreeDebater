"""Offline source/ownership audit of saved v36 planning requests. No API calls."""
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from streaming.branch_planning import branch_prompt
from streaming.planning_view import readable_planning_context

LEDGER = Path(__file__).resolve().parent / 'run'
ANNOTATIONS = {'boundary_indexes', 'boundary_options', 'also_selected_target',
               'also_our_prior_position'}


def objects(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from objects(child)


def plain(value):
    if isinstance(value, dict):
        return {k: plain(v) for k, v in value.items() if k not in ANNOTATIONS}
    if isinstance(value, list):
        return [plain(v) for v in value]
    return value


def sources(record):
    return [x for x in objects(record.get('response_chains', []))
            if 'node_id' in x and 'quote' in x]


def audit(context, view):
    changed = {'clash_records', 'tree_targets', 'constraints', 'position_limits'}
    for key in context.keys() - changed:
        assert context[key] == view[key], key
    assert len(context['clash_records']) == len(view['clash_records'])
    all_sources = [s for r in view['clash_records'] for s in sources(r)]
    for before, after in zip(context['clash_records'], view['clash_records']):
        for key in before.keys() - {'response_chains', 'entries'}:
            assert before[key] == after[key], key
        assert len(before['response_chains']) == len(after['response_chains'])
        for old_chain, new_chain in zip(before['response_chains'], after['response_chains']):
            for key, value in old_chain.items():
                replacement, flag = {
                    'target': ('latest_opponent_reply', 'also_selected_target'),
                    'our_prior_position': ('our_objection', 'also_our_prior_position'),
                }.get(key, (key, None))
                if key in new_chain:
                    assert plain(new_chain[key]) == value, key
                else:
                    assert new_chain[replacement][flag]
                    assert plain(new_chain[replacement]) == value, key
        for entry in before.get('entries', []):
            assert entry in after['entries'] or any(
                all(entry.get(k) == s.get(k) for k in
                    ('node_id', 'side', 'relation', 'responds_to', 'status'))
                and (entry.get('excerpt') == s['quote'] or
                     (entry.get('excerpt_truncated') and s['quote'].startswith(
                         entry['excerpt'].removesuffix('…')))) for s in all_sources)
    opponent = 'against' if context['our_side'] == 'for' else 'for'
    assert len(context['tree_targets']) == len(view['tree_targets'])
    for old, new in zip(context['tree_targets'], view['tree_targets']):
        for key in old.keys() - {'sources', 'arguments', 'constraints'}:
            assert old[key] == new[key], key
        matching = [s for s in all_sources if s['node_id'] == old['node_id']
                    and s.get('side') == old.get('side', opponent)
                    and s.get('status') == 'current']
        quotes = new.get('sources', []) + [s['quote'] for s in matching]
        assert all(q in quotes for q in old.get('sources', []))
        assert all(a in new.get('arguments', []) or any(a in q for q in quotes)
                   for a in old.get('arguments', []))
        conditions = plain(new.get('constraints', [])) + [plain(c) for s in matching
                                                        for c in s.get('constraints', [])]
        assert all(c in conditions for c in old.get('constraints', []))
    for condition in context.get('constraints', []):
        if condition in plain(view['constraints']):
            continue
        target = next(t for t in view['tree_targets'] if t['node_id'] == condition['node_id']
                      and t['claim'] == condition['claim'])
        attached = plain(target.get('constraints', [])) + [plain(c) for s in all_sources
            if s['node_id'] == target['node_id'] and s.get('side') == target.get('side', opponent)
            and s.get('status') == 'current' for c in s.get('constraints', [])]
        assert {k: v for k, v in condition.items() if k not in ('node_id', 'claim')} in attached
    boundaries = []
    for obj in objects(view):
        boundaries.extend((i, obj['quote']) for i in obj.get('boundary_indexes', []))
        boundaries.extend((b['index'], b['quote']) for b in obj.get('boundary_options', []))
    boundaries.extend((b['index'], b['quote']) for b in view['additional_boundaries'])
    assert sorted(boundaries) == list(enumerate(context['position_limits']))


def main():
    with sqlite3.connect(f'file:{LEDGER}/cost.sqlite?mode=ro', uri=True) as db:
        ids = db.execute("SELECT id FROM calls WHERE label LIKE "
                         "'listening-motion-live-v36/%prepare_compact_json_rebuttal_choices' ORDER BY id").fetchall()
    rows = []
    for (call_id,) in ids:
        path = LEDGER / f'call_{call_id:06}.json'
        raw = path.read_bytes()
        request = json.loads(raw)['request']
        messages = copy.deepcopy(request['messages'])
        message = next(m for m in messages if '{"context":' in m['content'])
        old_prompt = message['content']
        offset = old_prompt.index('{"context":')
        payload, length = json.JSONDecoder().raw_decode(old_prompt[offset:])
        context = payload['context']
        frozen = copy.deepcopy(context)
        applied = bool(context.get('clash_records') and context.get('overview_preparation') is not None)
        view = readable_planning_context(context) if applied else copy.deepcopy(context)
        if applied:
            audit(context, view)
        new_prompt = branch_prompt(context, payload['heard_prefix'], payload['previous_state'])
        projected = json.loads(new_prompt[new_prompt.index('{"context":'):])
        assert projected['context'] == view
        assert projected['heard_prefix'] == payload['heard_prefix']
        assert projected['previous_state'] == payload['previous_state']
        assert context == frozen
        message['content'] = new_prompt + old_prompt[offset + length:]
        before = sum(len(m['content']) for m in request['messages'])
        after = sum(len(m['content']) for m in messages)
        rows.append(dict(call_id=call_id, projection_applied=applied,
                         source_sha256=hashlib.sha256(raw).hexdigest(),
                         before_characters=before, after_characters=after,
                         reduction_percent=100 * (before - after) / before,
                         preservation_passed=True))
    before = sum(r['before_characters'] for r in rows)
    after = sum(r['after_characters'] for r in rows)
    report = dict(mode='offline; no API requests', requests=len(rows), all_passed=True,
                  projected_requests=sum(r['projection_applied'] for r in rows),
                  before_characters=before, after_characters=after,
                  total_reduction_percent=100 * (before - after) / before,
                  reduction_range_percent=[min(r['reduction_percent'] for r in rows),
                                           max(r['reduction_percent'] for r in rows)],
                  checks=['source text and qualifications with identical owner/status',
                          'exchange order, source metadata, and historical entries',
                          'target selection order, IDs and versions',
                          'every boundary option verbatim with its original index',
                          'prior debate, heard prefix, and previous state unchanged',
                          'canonical context not mutated; response schema unchanged'],
                  limitations='Character counts are not token counts. No latency or model quality measured.',
                  rows=rows)
    out = LEDGER / 'readable-planning-context-offline-v1'
    out.mkdir(exist_ok=True)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, indent=2))


if __name__ == '__main__':
    main()
