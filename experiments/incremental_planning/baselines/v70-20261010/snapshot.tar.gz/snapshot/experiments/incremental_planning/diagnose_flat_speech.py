"""Inspect frozen paragraph requests and review traces without making API calls."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sqlite3


DIRECTORY = Path(__file__).resolve().parent


def diagnose(run):
    database = sqlite3.connect(f'file:{DIRECTORY / "run/cost.sqlite"}?mode=ro', uri=True)
    drafts = []
    for request_id, label in database.execute(
            'SELECT id,label FROM calls WHERE instr(label,?)=1 ORDER BY id', (run+'/',)):
        path = DIRECTORY / 'run' / f'call_{request_id:06}.json'
        if not path.exists():
            continue  # An in-flight request has no receipt yet.
        artifact = json.loads(path.read_text())
        messages = artifact['request'].get('messages', [])
        if not messages or not messages[-1]['content'].startswith('Deliver our debate speech'):
            continue
        prompt = messages[-1]['content']
        context = json.loads(prompt.split('\n', 1)[1])
        choice = artifact.get('response', {}).get('choices', [{}])[0]
        raw = choice.get('message', {}).get('content') or ''
        candidate = None
        strict_json = True
        try:
            candidate = json.loads(raw.strip().removeprefix('```json').removesuffix('```').strip())
        except ValueError:
            strict_json = False
        start = raw.find('{')
        if candidate is None and start >= 0:
            try:
                candidate, _ = json.JSONDecoder().raw_decode(raw[start:])
            except ValueError:
                pass
        candidate = candidate if isinstance(candidate, dict) else {}
        targets = {item['node_id'] for item in context['current_targets']}
        ids = candidate.get('target_ids')
        valid_ids = (isinstance(ids, list) and all(isinstance(i, str) and i in targets for i in ids)
                     and len(ids) == len(set(ids)) and (not targets or bool(ids)))
        drafts.append({
            'request_id': request_id, 'label': label, 'finish_reason': choice.get('finish_reason'),
            'message_count': len(messages),
            'response_format': artifact['request'].get('response_format'),
            'whole_speech_format_instruction_present': any(
                'Rebuttal Plan' in message['content'] for message in messages[:-1]),
            'strict_json': strict_json,
            'prefix_before_json': raw[:start] if start >= 0 else raw,
            'target_words': context['target_words'],
            'candidate_words': len(candidate.get('text', '').split()),
            'target_ids_valid': bool(valid_ids), 'done': candidate.get('done'),
            'published_prefix_words': len(context['published_prefix'].split())})
    database.close()
    reviews = []
    for path in sorted((DIRECTORY / 'run' / run).glob('*/*/*/result.json')):
        row = json.loads(path.read_text())
        for thought in row.get('thoughts', []):
            if thought.get('mode') != 'flat_streaming_review':
                continue
            audit = thought['audit']
            reviews.append({
                'case': row['case'], 'repeat': row['repeat'], 'arm': row['arm'],
                'chunk_index': thought['chunk_index'], 'draft': thought['draft'],
                'audit': audit,
                'candidate_was_published': any(event['index'] == thought['chunk_index']
                                              and event['text'] == thought['draft']
                                              for event in row['events']),
                'repeats_previously_published_text': any(event['index'] < thought['chunk_index']
                                                       and event['text'] == thought['draft']
                                                       for event in row['events'])})
    result = {
        'run_id': run, 'draft_count': len(drafts),
        'strict_json_count': sum(row['strict_json'] for row in drafts),
        'valid_target_ids_count': sum(row['target_ids_valid'] for row in drafts),
        'finish_reasons': dict(Counter(row['finish_reason'] for row in drafts)),
        'review_count': len(reviews),
        'accepted_review_count': sum(row['audit']['accepted'] for row in reviews),
        'drafts': drafts, 'reviews': reviews,
        'note': 'All recorded drafts/reviews, including rejected and unspoken text. '
                'This is protocol diagnosis, not independent quality grading.'}
    destination = DIRECTORY / f'{run}_format_diagnostics.json'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('drafts', 'reviews')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-id', choices=('flat-speech-real-v1', 'flat-speech-real-v2'), required=True)
    diagnose(parser.parse_args().run_id)
