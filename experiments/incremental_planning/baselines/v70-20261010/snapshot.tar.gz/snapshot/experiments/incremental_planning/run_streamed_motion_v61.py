"""One additional motion using the current production streaming revision path."""
import argparse
from dataclasses import asdict
import json
import hashlib
from pathlib import Path
import sqlite3
import sys

import benchmark_listening_motion_live as live
import compare_revision_pipelines_v56 as accounting

live.RUN = accounting.PARENT + '-streamed-motion02-v61'
live.OUT = live.LEDGER / live.RUN
live.MANIFEST = live.D / ('manifest_' + live.RUN + '.json')
live.MOTION_NUMBER = 2
live.RUN_CAP = 8.
live.VALIDATION_RUNS = tuple(dict.fromkeys((*live.VALIDATION_RUNS, live.RUN)))
RECORD = live.D / 'prepared_streamed_motion_v61.json'
original_player = live.new_player
original_combined_guard = live.arm_combined_guard


def arm(db):
    accounting.arm(db, accounting.PARENT, 50.)
    name = 'validation_v61_' + hashlib.sha256(live.RUN.encode()).hexdigest()[:12]
    exposure = live.exposure_query(' WHERE ' + live.combined_filter('c.label'))
    sql = (f'CREATE TRIGGER {name} BEFORE INSERT ON calls '
        f'WHEN {live.combined_filter("NEW.label")} AND NEW.reserved + ({exposure}) > {live.COMBINED_CAP!r} '
        "BEGIN SELECT RAISE(ABORT, 'Combined validation budget exceeded; no dispatch'); END")
    old = db.execute("select sql from sqlite_master where type='trigger' and name=?", (name,)).fetchone()
    if old and old[0] != sql:
        raise ValueError('Existing combined guard differs')
    if not old:
        db.execute(sql); db.commit()
    return name


def new_player(side, motion, meter, players=None):
    player = original_player(side, motion, meter, players)
    original_helper = player.helper_client

    def helper(prompt, sys=None, response_model=None, max_tokens=4096,
               json_mode=None, history_messages=None, **kwargs):
        on_text = kwargs.get('on_text')
        if on_text is None:
            return original_helper(prompt, sys=sys, response_model=response_model,
                max_tokens=max_tokens, json_mode=json_mode,
                history_messages=history_messages, **kwargs)
        if response_model is not None or json_mode or kwargs.get('model', live.MODEL) != live.MODEL:
            raise ValueError('Streamed revision must be plain text on the approved model')
        if meter.stopped.is_set():
            raise live.BudgetExceeded('Stopped before streamed revision')
        from utils.model import helper_messages
        label = live.RUN + f'/{side}/{player.status}/whole_revision_stream'
        client = live.BudgetedClient(live.LEDGER, cap=live.CAP, label=label)
        try:
            text, _, _ = accounting.stream_complete(client,
                helper_messages(prompt, sys=sys, history_messages=history_messages),
                on_text, max_tokens=min(max_tokens, 4096),
                temperature=kwargs.get('temperature', 0))
            return [text]
        except (live.BudgetExceeded, sqlite3.IntegrityError) as exc:
            meter.stop_for_budget(label, exc)
            raise
        finally:
            client.db.close()

    player.helper_client = helper
    return player


def prepare():
    if RECORD.exists() or live.OUT.exists():
        raise ValueError('Artifacts already exist; no automatic restart')
    manifest = live.manifest()
    manifest.update(authorization='User requested 再试一个motion after v60; continuation of scheme-one testing within the previously approved cumulative USD50 budget. No cap increase.',
        parent_cap_usd=50, run_cap_usd=8,
        prior_costs_retained=True, automatic_retries=False,
        method='Fresh six-turn motion02 debate through current production listening-prefix and streamed whole-body revision, native adaptive TTS, wall-clock playback and Whisper ASR. Saved motion02 evidence pools; no new retrieval. Streaming helper calls use the existing metered SSE adapter.',
        guard='Durable SQLite guards enforce USD50 cumulative parent, USD8 run, existing global/study/combined caps. Failed and in-flight reservations retained. No automatic rerun.',
        launch_wrapper_sha256=live.digest(__file__))
    manifest['estimate_usd'].update(expected=[1,3], run_stop=8,
        parent_cumulative_stop=50, conservative_incremental=8)
    manifest['first_paragraph']['semantic_review'] = live.CONFIG.listening_prefix_review_enabled
    live.atomic_json(RECORD, manifest)
    live.atomic_json(live.MANIFEST, manifest)
    print(json.dumps(dict(motion=manifest['motion'], turns=len(live.TURNS),
        stream_revision=live.CONFIG.listening_stream_body_revision,
        estimate_usd=[1,3], run_cap=8, parent_cap=50), indent=2))


def main():
    p = argparse.ArgumentParser(); p.add_argument('--execute', action='store_true')
    args = p.parse_args()
    if not args.execute:
        prepare(); return
    record = json.loads(RECORD.read_text())
    assert record['launch_wrapper_sha256'] == live.digest(__file__)
    assert record['output_config'] == asdict(live.CONFIG)
    assert record['status'] == 'approved' and not live.OUT.exists()
    live.new_player, live.arm_combined_guard = new_player, arm
    sys.argv = [str(Path(live.__file__)), '--execute']
    try:
        live.main()
    finally:
        if live.OUT.exists():
            (live.OUT / 'launch_wrapper.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
