"""User-requested fresh live retest; preserves all prior charges and artifacts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import validate_streamed_revision_v58 as run

run.RUN=run.base.PARENT+'-streamed-revision-v59'
run.OUT=run.LEDGER/run.RUN
run.RECORD=run.D/'prepared_streamed_revision_v59.json'
run.SOURCES=run.SOURCES+[Path(__file__)]


def prepare():
    if run.RECORD.exists():raise ValueError('Retest already prepared')
    original=json.loads((run.D/'prepared_streamed_revision_v58_resume.json').read_text())
    record=dict(original,run_id=run.RUN,created_utc=datetime.now(timezone.utc).isoformat(),
        authorization='User explicitly requested a real retest after v58 HTTP429 stop; same six cases under previously approved USD50 cumulative cap.',
        source_digests=run.digests(),manual_resume=False,
        schedule=[dict(case=c['original_call_id'],repeat=r) for r in (1,2) for c in original['cases']],
        prior_costs_retained=True,automatic_retries=False,run_cap_usd=8,estimate_new_usd=[1,2])
    meter=run.BudgetedClient(run.LEDGER,cap=run.base.GLOBAL_CAP)
    run.base.arm(meter.db,run.base.PARENT,50)
    run.base.arm(meter.db,run.RUN+'/',8)
    meter.db.close()
    run.base.save(run.RECORD,record)
    print('Prepared six real speeches, USD8 retest cap within USD50 cumulative cap.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');args=p.parse_args()
    run.execute() if args.execute else prepare()
