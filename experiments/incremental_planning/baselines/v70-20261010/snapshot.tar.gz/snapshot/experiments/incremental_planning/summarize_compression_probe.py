"""Report all fixed-text compression probes, including rejected and unused edits."""
import json
from pathlib import Path
import sqlite3
import sys

DIRECTORY = Path(__file__).resolve().parent
sys.path.insert(0, str(DIRECTORY.parents[1] / 'src'))
from streaming.experiment_accounting import exposure_query

RUN = 'flat-compression-probe-v1'


def main():
    base = DIRECTORY / 'run' / RUN
    rows = []
    for path in sorted(base.glob('*/*/result.json')):
        row = json.loads(path.read_text())
        row['judgment'] = json.loads(path.with_name('judgment.json').read_text())
        row['original_judgment'] = json.loads(path.parent.parent.joinpath('original_judgment.json').read_text())
        row['delivered_rewritten_chunks'] = sum(int(p['chosen_intra_iter']) > 0 for p in row['chunk_profiles'])
        row['checks'] = [c for context in row['rewrite_audit'] for c in context['checks']]
        rows.append(row)
    db = sqlite3.connect(f'file:{DIRECTORY / "run/cost.sqlite"}?mode=ro', uri=True)
    db.execute('BEGIN')
    calls = db.execute('SELECT label,estimated_usd,state FROM calls WHERE instr(label,?)=1', (RUN+'/',)).fetchall()
    result = {'run_id': RUN, 'manifest': json.loads((DIRECTORY / 'manifest_compression_probe_v1.json').read_text()),
        'attempts': len(rows), 'returned': sum(r['status']=='returned' for r in rows),
        'over_30_seconds': sum(r['audio_seconds'] > 30 for r in rows),
        'delivered_rewritten_chunks': sum(r['delivered_rewritten_chunks'] for r in rows),
        'meaning_checks': sum(len(r['checks']) for r in rows),
        'meaning_checks_rejected': sum(not c['accepted'] for r in rows for c in r['checks']),
        'cost': {'known_usage_estimate_usd': sum(c or 0 for _,c,_ in calls), 'entries': len(calls),
                 'pending': sum(state=='pending' for _,_,state in calls),
                 'run_exposure_usd': db.execute(exposure_query(' WHERE instr(c.label,?)=1'),(RUN+'/',)).fetchone()[0],
                 'limit_usd': 6, 'cumulative_limit_usd': 200},
        'observations': [
            'All four attempts returned. Deadline fallback can select original audio even after a rewrite passes its check.',
            'The river checker rejected changing a conditional litter risk into inevitable escalation.',
            'The same checker accepted a compression omitting the two-metre clear-path and flood-warning shutdown conditions; this candidate was delivered.',
            'The independent river condition score fell from 2/3 in the source and unrewritten control to 1/3 in the checked compressed output.',
            'Meaning checks do not guarantee qualification preservation. The ready-to-use preset therefore disables TTS text rewrites; experimental flags remain available.',
            'These selected diagnostic probes do not establish a general effect of the checker; no full-speech generation occurs here.'],
        'per_attempt': rows}
    db.close()
    (DIRECTORY / 'flat-compression-probe-v1_summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['attempts','returned','over_30_seconds','delivered_rewritten_chunks','meaning_checks','meaning_checks_rejected','cost']},indent=2))


if __name__ == '__main__':
    main()
