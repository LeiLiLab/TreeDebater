"""Prepare or run six first-paragraph drafts using motion02's saved prior speeches."""
import argparse
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace

import probe_first_paragraph as probe
from streaming.rehearsal_selection import select_saved_claims
from utils.prompts.authoring import DEFAULT_DEBATER_SYSTEM

D, ROOT = probe.D, probe.ROOT
RUN = 'listening-motion-live-motion02-first-paragraph-v1'
OUT = D / 'run' / RUN
SOURCE = ROOT / 'experiments/treedebater_batch_gemma4/motion_02_tree_for/result.json'


def build_plan():
    record = json.loads(SOURCE.read_text())
    assert record['status'] == 'complete' and len(record['history']) == 6
    motion = record['config']['env']['motion']
    previous = json.loads((D / 'run/listening-motion-live-v42-first-paragraph-v1/manifest.json').read_text())
    config = probe.from_mapping(probe.OutputConfig, previous['output_config'])
    history = [dict(h, content=h['content'].replace('\\n', '\n')) for h in record['history']]
    sources = {str(SOURCE.relative_to(ROOT)): probe.sha(SOURCE)}
    preparations = {}
    for side in ('for','against'):
        path = ROOT / 'results/gemma-4-26b-a4b' / f"{motion.replace(' ', '_').lower()}_pool_{side}.json"
        pool = json.loads(path.read_text())
        p = SimpleNamespace(rehearsal_claim_pool=pool, definition=pool[0][0].get('definition',''))
        preparations[side] = select_saved_claims(p)
        sources[str(path.relative_to(ROOT))] = probe.sha(path)
    requests = []
    for i, h in enumerate(history):
        stage, side = h['stage'], h['side']
        prior = copy.deepcopy(history[:i])
        heard = prior[-1]['content'] if prior else ''
        prep = preparations[side]
        data = dict(motion=motion, our_side=side, stage=stage,
                    our_definition=prep['definition'],
                    our_main_claims=[x['claim'] for x in prep['claims']],
                    our_previous_speeches=[x['content'] for x in prior if x['side']==side],
                    private_claim_options=[x['claim'] for x in prep['candidates']],
                    private_claim_candidates=prep['candidates'], debate_history=prior,
                    framework=None, current_targets=[], condition_candidates=[], clash_records=[],
                    body_plan=[], current_plan='', opponent_sources=[x['content'] for x in prior if x['side']!=side],
                    supplied_evidence=[], final_transcript=heard, heard_transcript=heard,
                    turn=f"{prior[-1]['side']}:{prior[-1]['stage']}" if prior else None,
                    prefix_handoff=True)
        class Captured(Exception):
            pass
        captured = []
        def capture(**kwargs):
            captured.append(kwargs)
            raise Captured()
        try:
            probe.prepare(data, capture, config, endpoint=True, system_prompt=DEFAULT_DEBATER_SYSTEM,
                          writing_options={'model':probe.MODEL, 'temperature':.3})
        except Captured:
            pass
        assert len(captured)==1
        call=captured[0]
        request=dict(model=call['model'], temperature=call['temperature'],max_tokens=call['max_tokens'],
                     num_retries=0, messages=[{'role':'system','content':call['sys']},
                                             {'role':'user','content':call['prompt']}],
                     response_format={'type':'json_object'})
        assert json.loads(call['prompt'].rsplit('\n',1)[-1])==dict(context=data,endpoint=True)
        # No target-turn text or future speech is included in the authoring context.
        assert data['debate_history']==history[:i]
        old=previous['requests'][i]
        size=len(json.dumps(request).encode())
        expected=old['expected_usd']*size/len(json.dumps(old['request']).encode())
        reserve=4*(size+8192+700)/1e6
        requests.append(dict(index=i,stage=stage,side=side,context=data,request=request,
                             reservation_usd=reserve,expected_usd=expected,prior_turns=i))
    return dict(run=RUN, motion=motion,motion_number=2,status='approved',
        created_utc=datetime.now(timezone.utc).isoformat(),
        authorization='Existing approved USD300 global/USD210 study budget; user requested 换一个motion生成 after a first-paragraph-only test. One six-draft motion02 test, no automatic rerun or budget increase.',
        scope='Six independent first-paragraph drafts from complete preceding historical speeches and saved private claim pools. No target or future speech, result judgment, live tree/planner, reviews, repairs, body, TTS or ASR.',
        source_digest=probe.code_digest(),harness_sha256=probe.sha(Path(probe.__file__)),
        preparer_sha256=probe.sha(Path(__file__)),source_files=sources,
        global_cap_usd=300,study_cap_usd=210,local_cap_usd=1.,starting_ledger=probe.ledger_summary(),
        prices=previous['prices'],expected_usd=sum(r['expected_usd'] for r in requests),
        sum_initial_reservations_usd=sum(r['reservation_usd'] for r in requests),
        guard=previous['guard'],output_config=previous['output_config'],requests=requests,
        limitations=['One draft per stage, with no semantic publication review or audio measurement.',
        'Contexts use complete prior historical text, unlike the previous motion01 partial-input replay. Not a controlled motion-only comparison.',
        'Tree/framework/planning fields are empty, not regenerated or borrowed from another motion.',
        'Historical debate was TreeDebater FOR versus BaselineDebater AGAINST; both new drafts use current TreeDebater authoring rules.',
        'Each context retains the historical prior speeches rather than these newly generated paragraphs.'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    if args.execute:
        plan=json.loads((OUT/'manifest.json').read_text())
        assert plan['preparer_sha256']==probe.sha(Path(__file__))
        probe.execute(plan,output_dir=OUT)
    else:
        OUT.mkdir(exist_ok=False)
        plan=build_plan();probe.atomic_json(OUT/'manifest.json',plan)
        print(json.dumps({k:plan[k] for k in ['motion','expected_usd','sum_initial_reservations_usd','local_cap_usd']},indent=2))
