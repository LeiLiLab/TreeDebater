"""Keep every pre-TTS / delivered-text pair for semantic and rewrite inspection."""
import json
from pathlib import Path
import re

DIRECTORY = Path(__file__).resolve().parent
RUN = 'flat-full-adaptive-v2'


def main():
    cases = {case['id']: case for case in json.loads((DIRECTORY / 'cases_focus_v1.json').read_text())}
    rows = []
    for path in sorted((DIRECTORY / 'run' / RUN).glob('*/*/*/result.json')):
        record = json.loads(path.read_text())
        revisions = [thought for thought in record['thoughts'] if thought.get('mode') == 'length_adjust']
        pre_tts = revisions[-1]['final_response'] if revisions else ''
        trace = record.get('fixed_prefix_trace', {})
        if trace and 'fallback_reason' not in trace:
            pre_tts = trace['fixed_prefix']+'\n\n'+trace.get('revised_tail', pre_tts)
        judgment_path = path.with_name('judgment.json')
        case = cases[record['case']]
        rows.append({
            'case': record['case'], 'arm': record['arm'], 'status': record['status'],
            'opponent_source': ' '.join(case['chunks']), 'our_opening': case['own_opening'],
            'pre_tts_text': pre_tts, 'delivered_text': record['answer'],
            'pre_tts_words': len(pre_tts.split()), 'delivered_words': record['answer_words'],
            'text_differs_ignoring_whitespace': re.sub(r'\s+', ' ', pre_tts).strip()
                != re.sub(r'\s+', ' ', record['answer']).strip(),
            'rewritten_chunks_delivered': sum(int(profile['chosen_intra_iter']) > 0
                for profile in record.get('chunk_profiles', [])),
            'judge_on_delivered_text': json.loads(judgment_path.read_text()) if judgment_path.exists() else None,
            'fixed_prefix_fallback': trace.get('fallback_reason'),
            'note': 'Text difference does not itself imply an error; judgments concern delivered text only.'})
    output = DIRECTORY / (RUN+'_text_pairs.json')
    output.write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'pairs_recorded': len(rows), 'output': str(output)}))


if __name__ == '__main__':
    main()
