"""Run the approved refactor validation with the existing six-turn harness."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import benchmark_listening_motion_live as live


def configure(approval_path=None):
    approval_path = Path(approval_path) if approval_path else live.D / 'prepared_full_debate_v52.json'
    approval = json.loads(approval_path.read_text())
    if approval['status'] != 'approved' or approval.get('approved_cap_usd') != 20:
        raise ValueError('This run requires the recorded USD20 user approval')
    if approval['source_digest'] != live.code_digest():
        raise ValueError('Source changed after the approved configuration was prepared')
    if approval['harness_sha256'] != live.digest(live.__file__):
        raise ValueError('Six-turn harness changed after preparation')
    for path, digest in approval['input_sources'].items():
        if live.digest(path) != digest:
            raise ValueError('Saved rehearsal input changed: ' + path)
    live.RUN = approval['run_id']
    live.OUT = Path(approval['output_directory'])
    live.MANIFEST = live.D / ('manifest_' + live.RUN + '.json')
    live.RUN_CAP = approval['approved_cap_usd']
    live.VALIDATION_RUNS = tuple(dict.fromkeys((*live.VALIDATION_RUNS,
        *approval.get('prior_attempts', []), live.RUN)))

    def arm_combined_guard(db):
        name = 'validation_v52_' + hashlib.sha256(live.RUN.encode()).hexdigest()[:12]
        exposure = live.exposure_query(' WHERE ' + live.combined_filter('c.label'))
        sql = (f'CREATE TRIGGER {name} BEFORE INSERT ON calls '
            f'WHEN {live.combined_filter("NEW.label")} AND NEW.reserved + ({exposure}) > {live.COMBINED_CAP!r} '
            "BEGIN SELECT RAISE(ABORT, 'Combined validation USD60 exceeded; no dispatch'); END")
        old = db.execute("select sql from sqlite_master where type='trigger' and name=?", (name,)).fetchone()
        if old and old[0] != sql:
            raise ValueError('Existing combined guard differs')
        if not old:
            db.execute(sql)
            db.commit()
        live.arm_study_guard(db, approval.get('budget_group_prefix', live.RUN + '/'), live.RUN_CAP)
        return name

    live.arm_combined_guard = arm_combined_guard
    if live.OUT.exists():
        raise ValueError('Existing run artifacts must not be overwritten or automatically resumed')
    manifest = live.manifest()
    manifest.update(authorization='User requested one full debate, then explicitly approved: 20 刀预算',
        approval_record=str(approval_path), approved_cap_usd=20, currency='USD',
        launch_wrapper=str(Path(__file__).resolve()), launch_wrapper_sha256=live.digest(__file__),
        guard=approval['guard_plan'], claim_selection_strategy=approval['claim_selection_strategy'])
    manifest['retrieval']['shared_budget_record'] = str(approval_path)
    live.atomic_json(live.MANIFEST, manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--approval')
    args = parser.parse_args()
    manifest = configure(args.approval)
    if not args.execute:
        print(json.dumps(dict(run_id=live.RUN, cap_usd=live.RUN_CAP,
            starting_ledger=manifest['starting_ledger'], manifest=str(live.MANIFEST)), indent=2))
        return
    sys.argv = [str(Path(live.__file__)), '--execute']
    try:
        live.main()
    finally:
        if live.OUT.exists():
            (live.OUT / 'launch_wrapper.py').write_bytes(Path(__file__).read_bytes())


if __name__ == '__main__':
    main()
