"""One authorized TTS retry using the saved 241-character candidate; no debate run."""
import argparse
from datetime import datetime, timezone
from io import BytesIO
import json
import os
from pathlib import Path
import sys
import time

import httpx
from pydub import AudioSegment

D = Path(__file__).resolve().parent
R = D.parents[1]
sys.path.insert(0, str(R / 'src'))
from audio_probe import AudioGuard
from benchmark_listening_motion_live import arm_study_guard, ledger_summary
from streaming.experiment_accounting import reconcile_success
from streaming.experiment_client import BudgetedClient
from scripts.benchmark_incremental_planning import atomic_json

RUN = 'listening-motion-live-v38-tts-retry-1'
OUT = D / 'run' / RUN


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    source = D / 'run/listening-motion-live-v38/02_rebuttal_for/default_rebuttal_for_chunks/rewrite_audit.json'
    candidates = {check['candidate'] for group in json.loads(source.read_text())
                  for check in group['checks'] if check.get('accepted') and len(check['candidate']) == 241}
    assert len(candidates) == 1
    text = candidates.pop()
    starting = ledger_summary()
    plan = dict(run_id=RUN, status='prepared', currency='USD',
        authorization='User explicitly requested 再试一下这个tts under the existing USD300 global/USD210 study budgets.',
        text_source=str(source.relative_to(R)),
        text_provenance='Unique accepted 241-character candidate corresponding to chunk13 failed refinement; original audio ledger retained length rather than request text.',
        request=dict(model='tts-1', voice='echo', input=text, speed=1.0, response_format='mp3'),
        requests=1, concurrency=1, retries=0, timeout_seconds=60,
        expected_usage_usd=len(text)*15/1e6, conservative_request_usd=len(text.encode())*15/1e6*4,
        probe_cap_usd=.02, global_cap_usd=300, study_cap_usd=210,
        price_checked_utc='2026-10-07', price_usd_per_million_characters=15,
        price_source='https://developers.openai.com/api/docs/models/tts-1',
        starting_ledger=starting,
        guard='One-request AudioGuard reserves USD.02 before dispatch, retains failed charges, and shares atomic global/study enforcement. No model/ASR/rewrite calls or rented compute.')
    if not args.execute:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    OUT.mkdir(exist_ok=False)
    atomic_json(OUT / 'manifest.json', plan)
    (OUT / 'input.txt').write_text(text)
    (OUT / 'probe_source.py').write_bytes(Path(__file__).read_bytes())
    check = BudgetedClient(D / 'run', cap=300)
    plan['guard_trigger'] = arm_study_guard(check.db)
    check.db.close()
    for key, value in json.loads((R / 'src/configs/api_key.json').read_text()).items():
        os.environ.setdefault(key, value)
    import openai

    timing = {}
    class ObservedTransport(httpx.HTTPTransport):
        def handle_request(self, request):
            began = time.perf_counter()
            response = super().handle_request(request)
            timing.update(response_headers_seconds=time.perf_counter()-began,
                          http_status=response.status_code,
                          provider_request_id=response.headers.get('x-request-id'))
            return response

    guard = AudioGuard(D / 'run', RUN + '/tts', allowance=.02, approved_cap=300,
                       max_requests=1, inner=ObservedTransport(retries=0))
    client = openai.OpenAI(base_url='https://api.openai.com/v1', max_retries=0, timeout=60,
                          http_client=httpx.Client(transport=guard, timeout=60))
    result = dict(run_id=RUN, started_utc=datetime.now(timezone.utc).isoformat())
    began = time.perf_counter()
    try:
        plan.update(status='running', request_id=guard.request_id)
        atomic_json(OUT / 'manifest.json', plan)
        response = client.audio.speech.create(**plan['request'])
        result['tts_request_seconds'] = time.perf_counter()-began
        data = response.content
        (OUT / 'retry.mp3').write_bytes(data)
        decoded = AudioSegment.from_file(BytesIO(data), format='mp3')
        result.update(status='completed', audio_seconds=len(decoded)/1000,
                      audio_bytes=len(data), audio_path=str((OUT / 'retry.mp3').relative_to(R)))
    except Exception as exc:
        result.update(status='failed', error=f'{type(exc).__name__}: {exc}',
                      elapsed_seconds=time.perf_counter()-began)
    finally:
        client.close()
        guard.finish()
        if result.get('status') == 'completed':
            reconcile_success(guard.db, guard.request_id, guard.path)
        guard.db.close()
        result.update(timing=timing, request_id=guard.request_id,
            estimated_known_usage_usd=sum(x['estimated_usd'] for x in guard.artifact['external_calls'] if x['state']=='ok'),
            failed_requests=sum(x['state']!='ok' for x in guard.artifact['external_calls']),
            ending_ledger=ledger_summary(), finished_utc=datetime.now(timezone.utc).isoformat())
        result['new_conservative_exposure_usd'] = result['ending_ledger']['accounted_exposure_usd'] - starting['accounted_exposure_usd']
        atomic_json(OUT / 'result.json', result)
        plan.update(status=result['status'], finished_utc=result['finished_utc'])
        atomic_json(OUT / 'manifest.json', plan)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
