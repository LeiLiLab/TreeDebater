"""Complete the interrupted v46 artifacts; never relabel the live trial as passed."""
import argparse,copy,json,logging,os
from pathlib import Path
from datetime import datetime,timezone
import benchmark_listening_motion_live as live
from streaming.experiment_accounting import reconcile_success
from streaming.listening_prefix import material,speak_with_listening_prefix

ROOT,D=live.ROOT,live.D
SOURCE=D/'run/listening-motion-live-v46'
RUN='listening-motion-live-v46/completion-v1'
OUT=SOURCE/'completion-v1'
LOCAL_CAP=1.5


def plan():
    prior=json.loads((D/'manifest_listening-motion-live-v46.json').read_text())
    assert prior['status']=='stopped' and prior['completed_turns']==4
    assert prior['budget_stop'] is None
    paths=[SOURCE/'listener_views.json',SOURCE/'history.json',
        SOURCE/'04_closing_for/heard.json',SOURCE/'04_closing_for/heard_input_001.wav']
    paths+=list((SOURCE/'04_closing_for').glob('*_chunks/chunk_002.mp3'))
    paths+=list((SOURCE/'04_closing_for').glob('*_chunks/listening_prefix.json'))
    assert len(paths)==6
    budget=live.ledger_summary()
    assert budget['pending_calls']==0
    return dict(status='approved',run=RUN,motion=prior['motion'],source_run='listening-motion-live-v46',
        authorization='Existing authorization to finish this motion within approved global USD320/study USD230 budgets and the v46 USD10 run cap. Reuse generated speeches after an ASR timeout; no full-match regeneration.',
        scope='Reuse five generated speeches/audio. Retry the failed37.266s ASR once and transcribe the67.307s generated final chunk once. Generate only AGAINST closing,120s, using prior real ASR/own speech history and completed real ASR of FOR closing. Artifact completion only; original live trial stays interrupted.',
        restoration='Fresh AGAINST debater seeded with its saved four-turn listener view and real ASR of FOR closing. Derived tree/planner state and speculative audio are not reconstructed. No continuous handoff timing claim.',
        expected_additional_usd=[.05,.30],continuation_cap_usd=LOCAL_CAP,original_run_cap_usd=10,
        global_cap_usd=320,study_cap_usd=230,starting_ledger=budget,
        prices=dict(gemma_input_per_million=.13,gemma_output_per_million=.40,tts_per_million_characters=15,whisper_per_minute=.006),
        prices_verified_utc='2026-10-08',price_sources=['https://aws.amazon.com/bedrock/pricing/',
            'https://developers.openai.com/api/docs/models/tts-1','https://developers.openai.com/api/docs/models/whisper-1'],
        guard='Atomic nested continuation/original-run/study/global reservations; ASR allowance USD.15/max2 requests, TTS USD1/max128 requests, no SDK retries, text metered. Existing failed ASR exposure retained. Stop on any new error.',
        source_digest=live.code_digest(),harness_sha256=live.digest(__file__),
        live_harness_sha256=live.digest(live.__file__),sources={str(p):live.digest(p) for p in paths})


def execute():
    m=json.loads((OUT/'manifest.json').read_text());assert m['status']=='approved'
    assert m['source_digest']==live.code_digest() and m['harness_sha256']==live.digest(__file__)
    assert m['live_harness_sha256']==live.digest(live.__file__)
    for p,h in m['sources'].items():assert live.digest(p)==h
    live.RUN,live.OUT=RUN,OUT
    client=live.BudgetedClient(live.LEDGER,cap=live.CAP)
    live.arm_study_guard(client.db)
    live.arm_study_guard(client.db,'listening-motion-live-v46/',10.)
    m['continuation_guard']=live.arm_study_guard(client.db,RUN+'/',LOCAL_CAP)
    client.db.close()
    for key,value in json.loads((ROOT/'src/configs/api_key.json').read_text()).items():os.environ.setdefault(key,value)
    os.environ['DEBATE_LLM_API_BASE']='http://127.0.0.1:4000/v1'
    os.environ['DEBATE_LOG_PROMPTS']='0'
    import openai,httpx,litellm,tts_streaming
    from pydub import AudioSegment
    from debate_tree import Tree
    from utils.tool import logger
    logger.setLevel(logging.WARNING)
    def blocked(*a,**kw):raise RuntimeError('Unmetered request blocked')
    litellm.completion=blocked
    Tree.get_most_similar_node=lambda *a,**kw:(None,0.)
    meter=live.Meter();guards=[];clients=[]
    m.update(status='running',launched_utc=datetime.now(timezone.utc).isoformat());live.atomic_json(OUT/'manifest.json',m)
    try:
        if m.get('resume_from_asr'):
            heard=json.loads((OUT/'completed_asr.json').read_text())
            assert len(heard)==3 and all(h.get('text') for h in heard)
            print(json.dumps(dict(event='reuse_completed_asr',chunks=3)),flush=True)
        else:
            guard=live.AudioGuard(live.LEDGER,RUN+'/asr',allowance=.15,approved_cap=320,max_requests=2)
            guards.append(guard)
            asr=openai.OpenAI(http_client=httpx.Client(transport=guard,timeout=60),max_retries=0,base_url='https://api.openai.com/v1',timeout=60)
            clients.append(asr)
            first=json.loads((SOURCE/'04_closing_for/heard.json').read_text())[0]['text']
            heard=[dict(sequence=0,text=first,reused=True)]
            final_mp3=next((SOURCE/'04_closing_for').glob('*_chunks/chunk_002.mp3'))
            final_wav=OUT/'closing_for_remaining.wav'
            AudioSegment.from_file(final_mp3).export(final_wav,format='wav')
            for i,path in enumerate([SOURCE/'04_closing_for/heard_input_001.wav',final_wav],1):
                print(json.dumps(dict(event='asr_start',sequence=i)),flush=True)
                with path.open('rb') as f:response=asr.audio.transcriptions.create(model='whisper-1',file=f)
                heard.append(dict(sequence=i,text=response.text,audio=str(path),reused=False))
                live.atomic_json(OUT/'completed_asr.json',heard)
            guard.finish();reconcile_success(guard.db,guard.request_id,guard.path)
        view=json.loads((SOURCE/'listener_views.json').read_text())['against']
        assert len(view)==4
        final_text=' '.join(h['text'] for h in heard)
        history=view+[dict(stage='closing',side='for',content=final_text,tree_via_streaming=True)]
        live.atomic_json(OUT/'listener_history.json',history)
        player=live.new_player('against',m['motion'],meter)
        player.status='closing'
        for h in history:
            player._add_message('assistant' if h['side']=='against' else 'user',h['content'])
        player.planner.turn='for:closing';player.planner.chunks=[final_text]
        player.use_debate_flow_tree=False
        folder=OUT/'05_closing_against';folder.mkdir(exist_ok=bool(m.get('resume_from_asr')))
        player.audio_output_dir=str(folder)
        if m.get('cached_prefix_draft'):
            prior=json.loads(Path(m['cached_prefix_draft']).read_text())
            cached=[prior['response']['choices'][0]['message']['content']]
            original_helper=player.helper_client
            def resume_helper(*,prompt,**kwargs):
                if prompt.startswith('LISTENING PREFIX DRAFT:') and cached:
                    return [cached.pop()]
                return original_helper(prompt=prompt,**kwargs)
            player.helper_client=resume_helper
        live.atomic_json(folder/'input.json',material(player,'closing',history))
        tts_guard=live.AudioGuard(live.LEDGER,RUN+'/turn_5/tts',allowance=1.,approved_cap=320,max_requests=128)
        guards.append(tts_guard)
        def factory(**kwargs):
            c=openai.OpenAI(http_client=httpx.Client(transport=tts_guard,timeout=60),max_retries=0,base_url='https://api.openai.com/v1',timeout=60)
            clients.append(c);return c
        tts_streaming.OpenAI=factory;tts_streaming._text_request=live.metered_tts_text_request(meter)
        player.tts_chunk_callback=lambda i,p,t,d:print(json.dumps(dict(event='audio_ready',chunk=i,audio_seconds=d)),flush=True)
        text=speak_with_listening_prefix(player,120,copy.deepcopy(history),player.streaming_output_config,{},stage='closing')
        tts_guard.finish();reconcile_success(tts_guard.db,tts_guard.request_id,tts_guard.path)
        audio=Path(player._speech_audio_file(stage='closing'))
        result=dict(stage='closing',side='against',content=text,audio=str(audio),audio_seconds=len(AudioSegment.from_file(audio))/1000,status='completed',live_timing_comparable=False)
        live.atomic_json(folder/'result.json',result)
        m.update(status='completed',completed_speeches=6,original_live_status='interrupted',closing_audio_seconds=result['audio_seconds'])
    except BaseException as exc:
        meter.stopped.set();m.update(status='failed',error=f'{type(exc).__name__}: {exc}');raise
    finally:
        meter.stopped.set()
        for g in guards:g.finish()
        for c in clients:c.close()
        m.update(finished_utc=datetime.now(timezone.utc).isoformat(),ending_ledger=live.ledger_summary())
        live.atomic_json(OUT/'manifest.json',m)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    if args.execute:execute()
    else:
        m=plan();OUT.mkdir(exist_ok=False);live.atomic_json(OUT/'manifest.json',m)
        print(json.dumps({k:m[k] for k in ('scope','expected_additional_usd','continuation_cap_usd','starting_ledger')},indent=2))
